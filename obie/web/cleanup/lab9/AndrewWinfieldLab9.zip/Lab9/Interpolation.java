public class Interpolation {
   int[] list;
   int comparisons;

   public Interpolation(int[] values) {
      comparisons = 0;
      list = values;
   }

   // if key is found, returns the index of key, else returns -1
   public int search(int key) {
      comparisons = 0;
      int index = -1;

      if (list != null) {
         boolean done = false;
         int left = 0;
         int right = list.length - 1;


         while (left <= right && !done) {

            int a = list[left];
            int b = list[right];

            if (key < a || key > b) {
               done = true;
               comparisons += 2;   // cost of if test
            }
            else {
               comparisons +=2;   // cost of if test
               if (a == b) {
                  done = true;
                  index = left;
                  comparisons++;   // cost of if test
               }
               else  {
                  comparisons++;   // cost of if test

                  int n = right - left + 1;
                  int p = Math.round(left + (n -1) * ((float)(key-a) / (b - a)));

                  if (list[p] == key) {
                     comparisons+=1;
                     done = true;
                     index = p;
                  }
                  else if (list[p] < key) {
                     comparisons+=2;
                     left = p + 1;
                  }
                  else {
                     right = p - 1;
                     comparisons+=3;
                  }

               }
            }
         }
      }

      return index;
   }

   // returns true if index is a valid index, else returns false
   public boolean isValidIndex(int index) {
      return (index >= 0 && index < list.length);
   }

   // returns list value at index, if index is invalid returns -1
   // note: will not check that index is valid, must call isValidIndex
   public int getValue(int index) {
      return list[index];
   }

   // return the number of comparisons made in most previous search
   public int getComparisons() {
      return comparisons;
   }

   // return size of list
   public int getSize() {
      return list.length;
   }
}
