/*
 * Andrew Winfield
 * 3-20-06
 * lab 9
 * */
import java.io.*;
import java.util.*;

public class testSequential{
    public static void main(String[] agrs)throws IOException{
        File file = new File("unsorted1.txt");
        Scanner fileCnt = new Scanner(file);
        Scanner fileIn = new Scanner(file);
        int cnt = 0;
        
        while(fileCnt.hasNext()){
            cnt++;
        }
        System.out.println(cnt);
        int[] numbers = new int[cnt];
        
        cnt = 0;
        
        while(fileIn.hasNext()){
            numbers[cnt] = fileIn.nextInt();
            cnt++;
        }
        //Sequential asdf = new Sequential(numbers);
    }
}