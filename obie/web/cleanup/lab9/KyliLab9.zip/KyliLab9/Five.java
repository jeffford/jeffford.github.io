/**
 * Class Five allows the user to enter a list of numbers and prints the list.
 * 
 * @author Lab Specifications & Kyli Foltz
 * @version 3/20/2006
 */

import java.util.*;

public class Five
{
    final static int LIST_SIZE = 10;
    
    /**
     * Main Method
     * 
     */
    public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < LIST_SIZE; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      
      int min = numbers[0];
      for (int i = 0; i < LIST_SIZE; ++i) {
         if (numbers[i] < min)
            min = numbers[i];
        }
      System.out.println("");
      System.out.println("Minimum: " + min);
      
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < LIST_SIZE; ++i) {
         min = numbers[0];
         if (numbers[i] <= min) {
            System.out.print("numbers[" + i + "]: " + numbers[i]);
            System.out.println(" minimum");
        }
         else
            System.out.println("numbers[" + i + "]: " + numbers[i]);
      }
   }
}

