import java.util.*;
public class Five {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < 10; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      
      System.out.println();
      
      int minimum = numbers[0];
      for (int i = 1; i < LIST_SIZE; ++i) {
          if (numbers[i] < minimum) {
              minimum = numbers[i];
            }
      }
      System.out.println("The minimum value in the list is " + minimum + ".");
      
      int minimumSoFar = numbers[0];
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < 10; ++i) {
         System.out.print( "numbers[" + i + "]: " + numbers[i] + "" );
         if (numbers[i] <= minimumSoFar) {
             System.out.print(" ** minimum **");
             minimumSoFar = numbers[i];
         }
         System.out.println("");
      }
      System.out.println();
   }
}
