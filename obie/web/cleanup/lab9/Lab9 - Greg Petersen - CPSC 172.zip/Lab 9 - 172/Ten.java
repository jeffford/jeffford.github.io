import java.util.*;
public class Ten {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      String[] min = new String[LIST_SIZE];
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < LIST_SIZE; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      int n = 0;
      for (int i = 1; i < LIST_SIZE; ++i) {
          if(numbers[i]<numbers[n]) n=i;
      }
      for (int i = 0; i < LIST_SIZE; ++i) {
          if(numbers[i]==numbers[n]) min[i]="minimum";
          else min[i]="";
      }
      System.out.println("\n" + "The minimum value is: numbers[" + n + "]: " + numbers[n] );
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < LIST_SIZE; ++i) {
         System.out.println( "numbers[" + i + "]: " + numbers[i] + "    " + min[i] );
      }
   }
}