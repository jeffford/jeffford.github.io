import java.util.*;
public class Five {
   final static int LIST_SIZE = 5;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < 5; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < 5; ++i) {
         System.out.println( "numbers[" + i + "]: " + numbers[i] );
      }
   }
}