import java.util.*;
public class Five {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < 10; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
         
      }
      int[] temp=numbers.clone();
      Arrays.sort(temp);
      System.out.println("Minimum value: " + temp[0]);
      System.out.println( "\n" + "Entered list: " );
      for (int i = 0; i <10; ++i) {
          if (numbers[i]==temp[0])
         System.out.println( "numbers[" + i + "]: " + numbers[i] +" minimum");
         else
         System.out.println( "numbers[" + i + "]: " + numbers[i]);
      }
   }
}

