public class Sum {
   static final int LIST_SIZE = 9;
   public static void main(String[] args) {

      int a[] = { 30, 21,  19, 28, 29, 12,  54, 23,  24, 25 };
      int b[] = { 54, 54, 72, 15, 21, 28, 32, 56, 61,  33 };
      int c[] = new int[10];
      int i;
      for (i = 0; i <= LIST_SIZE; ++i) {
         c[i] = a[i] + b[i];
      }

      System.out.print( "    a: { ");
      for (i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( a[i] + " ");
      System.out.println( "}\n" );

      System.out.print( "    b: { ");
      for(i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( b[i] + " ");
      System.out.println( "}\n" );

      System.out.print( "a + b: { ");
      for (i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( c[i] + " ");
      System.out.println( "}\n" );
   }
}
