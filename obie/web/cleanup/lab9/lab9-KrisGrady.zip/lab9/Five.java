import java.util.*;
public class Five {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);
      int minimumSoFar = 0;
      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );
      
      for (int i = 0; i < 10; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
         int temp = numbers[i];
         if (i == 0){
            minimumSoFar = temp;
        }else{
            if (minimumSoFar > temp)    
                minimumSoFar = temp;}
                   }
                   
      System.out.println("the smallest number in the list is: " + minimumSoFar);
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < 10; ++i) {
          
          if (minimumSoFar == numbers[i]){
              System.out.println("numbers[" + i + "]: " + numbers[i] + "  :smallest number:");
          }
          else {
         System.out.println( "numbers[" + i + "]: " + numbers[i] );}
      }
   }
}
