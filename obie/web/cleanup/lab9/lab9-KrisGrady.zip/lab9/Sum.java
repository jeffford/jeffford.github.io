import java.io.*;
public class Sum {
   static final int LIST_SIZE = 10;
   public static void main(String[] args) throws IOException {
       
      int a[] = { 30, 21,  19, 28, 29, 12,  54, 23,  24, 25 };
      int b[] = { 54, 54, 72, 15, 21, 28, 32, 56, 61, 33 };
      int c[] = new int[LIST_SIZE];
      int i;
      
      try{
      for (i = 1; i <= LIST_SIZE; ++i) {
         c[i] = a[i] + b[i];
      }}
      catch (ArrayIndexOutOfBoundsException f){
           System.out.println("Caught Exception 'f'  :  " + f);
                            }
        
        
      System.out.print( "    a: { ");
       try{  for (i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( a[i] + " ");
      System.out.println( "}\n" );}
      catch (ArrayIndexOutOfBoundsException f){
          System.out.println("Caught Exception 'f'  :  " + f);
      }

      try{
      System.out.print( "    b: { ");
      for(i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( b[i] + " ");
      System.out.println( "}\n" );}
      
      catch (ArrayIndexOutOfBoundsException f){
          System.out.println("Caught Exception 'f'  :  " + f);}

        try{
      System.out.print( "a + b: { ");
      for (i = 0; i <= LIST_SIZE; ++i) 
         System.out.print( c[i] + " ");
      System.out.println( "}\n" );}
      
      catch (ArrayIndexOutOfBoundsException f){
          System.out.println("Caught Exception 'f'  :  " + f);}
   }
}
