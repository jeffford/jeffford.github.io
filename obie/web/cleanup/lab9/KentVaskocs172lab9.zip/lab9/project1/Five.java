import java.util.*;
public class Five {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
       int smallest = 0;
       int first = 0;
       
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );
      
      for (int i = 0; i < 10; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
         if (i == 0) {
            first = numbers[i];
            smallest = first;
        }
         else if (smallest > numbers[i])
            smallest = numbers[i];            
      }
      
      System.out.println("The value of the smallest number is " + smallest + ".");
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < 10; ++i) {
         if (numbers[i] == smallest)
          System.out.println( "numbers[" + i + "]: " + numbers[i] + "   MINIMUM" );
         else
          System.out.println("numbers[" + i + "]: " + numbers[i] );
      }
   }
}
