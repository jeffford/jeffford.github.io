public class Binary {
   int[] list;
   int comparisons;

   public Binary(int[] values) {
      comparisons = 0;
      list = values;
   }

   // use binary search to search list for key,
   // if found return index, else return -1
   public int search(int key) {
      comparisons = 0;
      int index = -1;

      if (list != null) {
         boolean done = false;
         int left = 0;
         int right = list.length - 1;

         while (left <= right && !done) {
            int p = (left + right) /2;
            if (list[p] == key) {
               comparisons+=1;
               done = true;
               index = p;
            }
            else if (list[p] < key) {
               left = p + 1;
               comparisons+=2;
            }
            else {
               right = p - 1;
               comparisons+=3;
            }
         }
      }

      return index;
   }

   // returns true if index is a valid index, else returns false
   public boolean isValidIndex(int index) {
      return (index >= 0 && index < list.length);
   }

   // returns list value at index, if index is invalid returns -1
   // note: will not check that index is valid, must call isValidIndex
   public int getValue(int index) {
      return list[index];
   }

   // return the number of comparisons made in most previous search
   public int getComparisons() {
      return comparisons;
   }

   // return size of list
   public int getSize() {
      return list.length;
   }
}
