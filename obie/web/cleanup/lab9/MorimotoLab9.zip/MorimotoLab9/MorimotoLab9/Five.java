import java.util.*;
public class Five {

    /**
     * class variable that determine the size of array
     * in 1.1, we change the value 5 to 10 to deal with 10 numbers  
     * After that, it is good way that use LIST_SIZE in each for loop that deal with array
     */ 

   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < LIST_SIZE; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      
      
    /**
     * for 1.2
     * below code calculate minimum number in the array and display it
     */ 
           
      int guess = numbers[0];
      for(int i = 1; i < numbers.length; i++){
          if(guess > numbers[i]) guess = numbers[i];
      }
      
      System.out.println("\nThe minimum value is " + guess);
      
      
      System.out.println( "\n" + "The entered list is: " );
      for (int i = 0; i < numbers.length; ++i) {
         System.out.print( "numbers[" + i + "]: " + numbers[i] );
         
         /**
          * for 1.3
          * this code display "mimimum" when the current value is equal to minimum value
          */ 
         
         if(numbers[i] == guess) System.out.println(" \"mimimum\"");
         else System.out.println();      }
   }
}
