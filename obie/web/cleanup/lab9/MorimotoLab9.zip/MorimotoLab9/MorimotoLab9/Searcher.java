import java.util.*;

/**
 * to deal with IO Exception
 */
import java.io.*;

public class Searcher {
   static final int MAX_LIST_SIZE = 1000;
   static final String FILE_NAME = "sorted.dat";

   // opens file named FILE_NAME,
   //loads the values of the file into an int array and returns the array
   public int[] loadFile(String fileName) throws IOException {
   File file = new File(fileName);
   Scanner fileIn = new Scanner(file);      
      int[] buffer = new int[MAX_LIST_SIZE];

      int counter = 0;
      boolean done = true;
      
      /**
       * to use while loop corectly, we need to change boolean expression
       */
      
      while (fileIn.hasNextInt() && done) {
         /**
          * to extract the value from file
          */
         buffer[counter++] = fileIn.nextInt();
         if (counter >= MAX_LIST_SIZE)
            done = false;
            }

      // transfer numbers to list so list is the exact size needed to hold the list.
      int[] list = new int[counter];
      for(int i = 0; i<counter; i++) {
         list[i] = buffer[i];
      }

      return list;
   }

   public static void main(String[] args) throws IOException {

      // load file, initialize search
      Searcher testSearch = new Searcher();
      int[] values = testSearch.loadFile(FILE_NAME);
      Sequential search = new Sequential(values);

      // prompt and search for key
      System.out.print("Enter key value: ");
      Scanner stdin = new Scanner(System.in);
   
      int key = stdin.nextInt();
      int index = search.search(key);

      // output results
      if (!search.isValidIndex(index)) {
         System.out.println("\n*** The value " + key + " was not found");
      }
      else {
         System.out.println("\n*** Found value " + search.getValue(index));
      }
      System.out.println("*** Number of comparisons required : " +
                           search.getComparisons());
      System.out.println("*** to process a list of size : " + search.getSize());
   }
}
