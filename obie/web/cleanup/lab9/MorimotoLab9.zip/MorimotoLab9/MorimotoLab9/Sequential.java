public class Sequential {
   int[] list;
   int comparisons;

   public Sequential(int[] values) {
      comparisons = 0;
      list = values;
   }

   // if key is found, returns the index of key, else returns -1
   public int search(int key) {
      comparisons = 0;
      int index = -1;

      if (list != null) {
         boolean done = false;
         for (int i=0; i<list.length && !done; i++) {
            if (list[i] == key) {
               done = true;
               index = i;
            }
            
            /**
             * Tos stop serch when the current value is greater than key value
             */ 
            
            else if (list[i] > key){
                done = true;   
            }
            
            comparisons++;
         }
      }

      return index;
   }

   // returns true if index is a valid index, else returns false
   public boolean isValidIndex(int index) {
      return (index >= 0 && index < list.length);
   }

   // returns list value at index, if index is invalid returns -1
   // note: will not check that index is valid, must call isValidIndex
   public int getValue(int index) {
      return list[index];
   }

   // return the number of comparisons made in most previous search
   public int getComparisons() {
      return comparisons;
   }

   // return size of list
   public int getSize() {
      return list.length;
   }
}
