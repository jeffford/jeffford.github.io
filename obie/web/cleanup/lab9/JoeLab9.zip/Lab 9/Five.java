import java.util.*;
public class Five {
   final static int LIST_SIZE = 10;
   public static void main(String[] args)  {
      int[] numbers = new int[LIST_SIZE];
      Scanner stdin = new Scanner(System.in);

      System.out.println( "Enter a list of " + LIST_SIZE + " elements" );

      for (int i = 0; i < 10; ++i) {
         System.out.print( "Number:  ");
         numbers[i] = stdin.nextInt();
      }
      int minimum = numbers[0];
      for (int i = 1; i < numbers.length; ++i){
        if (numbers[i] < minimum)
            minimum = numbers[i];
        }
      System.out.println("The minimum value in the list is: " + minimum);
      System.out.println( "\n" + "The entire entered list is: " );
      String equalToMinimum;
      for (int i = 0; i < 10; ++i) {
         if (numbers[i] == minimum) {
            equalToMinimum = "minimum";
            System.out.println( "numbers[" + i + "]: " + numbers[i] + " " + equalToMinimum);
     }
        else 
            System.out.println( "numbers[" + i + "]: " + numbers[i]);
      }
   }
}
