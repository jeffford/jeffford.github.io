import java.io.*;
import java.util.*;
public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int b = Integer.parseInt("1.34");
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
      
      try {
         // Enter your code here for the exercises that follow
         int[] array = new int[4];
         array[5] = 1;
      }
      catch (Exception k) {
         System.out.println("Caught Exception 'k'");
         System.out.println("--------------------");
         System.out.println(k);
      }
      
      try {
         // Enter your code here for the exercises that follow
         String string = "hoohaa";
         string.charAt(6);
      }
      catch (Exception a) {
         System.out.println("Caught Exception 'a'");
         System.out.println("--------------------");
         System.out.println(a);
      }
      
      try {
         // Enter your code here for the exercises that follow
         int[] narray = new int[-4];
         narray[-1] = 1;
      }
      catch (Exception v) {
         System.out.println("Caught Exception 'v'");
         System.out.println("--------------------");
         System.out.println(v);
      }
      
      try {
         // Enter your code here for the exercises that follow
         String blah = null;
         blah.charAt(0);
      }
      catch (Exception I) {
         System.out.println("Caught Exception 'I'");
         System.out.println("--------------------");
         System.out.println(I);
      }
      try {
         // Enter your code here for the exercises that follow
         int ha = 4/0;
      }
      catch (Exception I) {
         System.out.println("Caught Exception 'I'");
         System.out.println("--------------------");
         System.out.println(I);
      }
      
      try {
         // Enter your code here for the exercises that follow
         File file = new File("says.txt");
         Scanner FileIn = new Scanner(file);
      }
      catch (Exception z) {
         System.out.println("Caught Exception 'z'");
         System.out.println("--------------------");
         System.out.println(z);
      }
   }
}
