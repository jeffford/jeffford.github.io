public class ExceptionGenerator3 {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int[] b = new int[-5];
         b[-1] = 1;
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}