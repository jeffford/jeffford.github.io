public class Demo04 {
   public void a() {
      System.out.println("Entering a()");
      b();
      System.out.println("Exiting a()");
   }
   public void b() {
      System.out.println("Entering b()");
      try {
         c();
      }
      catch (TestException e) {
         System.out.println("\nCaught TestException!\n");
         return;
      }
      System.out.println("Exiting b()");
   }
   public void c() throws TestException {
      System.out.println("Entering c()");
      throw new TestException("thrown by c");
   }
   public static void main(String[] args) {
      Demo04 test = new Demo04();
      System.out.println("Entering main()");
      test.a();
      System.out.println("Exiting main()");
   }
}
