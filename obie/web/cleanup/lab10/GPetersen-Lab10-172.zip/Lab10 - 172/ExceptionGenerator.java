public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int b = Integer.parseInt("1.34");
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}
