public class ExceptionGenerator4 {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         String b = null;
         int a = b.length();
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}