public class ExceptionGenerator2 {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         String a = "hello";
         String b = a.substring(0,10);
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}