public class ExceptionGenerator5 {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int b = 7/0;
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}