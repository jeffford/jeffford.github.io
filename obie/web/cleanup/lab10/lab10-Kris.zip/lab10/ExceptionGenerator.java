import java.io.*;
import java.util.*;

public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int b = Integer.parseInt("1.34");
         
         }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
         System.out.println();
      }
      try{
         //Array index out of bounds exception
         int[] numbers = new int[5];
         numbers[6] = 1;
     }
     
     catch (Exception f){
         System.out.println("Caught Exception 'f'");
         System.out.println("--------------------");
         System.out.println(f);
          System.out.println();
     }
         //string index out of bounds 
         try{
             String string = "word";
             string.charAt(4);
         }
         
         catch (Exception g) {
             System.out.println("Caught Exception 'g'");
         System.out.println("--------------------");
         System.out.println(g);
          System.out.println();
         }
         
         //negative array size exception
         try{
             int[] numbers = new int[-5];
         }
         
         catch (Exception h) {
             System.out.println("Caught Exception 'h'");
         System.out.println("--------------------");
         System.out.println(h);
          System.out.println();
         }
         
         //null pointer 
         try{
            String string = null;
            string.charAt(0);
        }
         
         catch (Exception i) {
             System.out.println("Caught Exception 'i'");
         System.out.println("--------------------");
         System.out.println(i); 
         System.out.println();
         }
         
         //arithmetic
         try{
             int a = 1;
             int b = a / 0;
         }
         
         catch (Exception j) {
             System.out.println("Caught Exception 'j'");
         System.out.println("--------------------");
         System.out.println(j);
          System.out.println();
         }
         
         //file not found
         try{
            File file = new File("cheese.txt"); 
            Scanner FileIn = new Scanner(file);
         }
         
         catch (Exception k) {
             System.out.println("Caught Exception 'k'");
         System.out.println("--------------------");
         System.out.println(k);
          System.out.println();
         }
         
      
   }
}
