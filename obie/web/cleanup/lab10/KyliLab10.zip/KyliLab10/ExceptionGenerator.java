import java.io.*;
import java.util.*;

public class ExceptionGenerator {
   public static void main(String[] args) throws IOException {
      try {
         // Enter your code here for the exercises that follow
         File file = new File("Example.txt");
         Scanner fileIn = new Scanner(file);
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}
