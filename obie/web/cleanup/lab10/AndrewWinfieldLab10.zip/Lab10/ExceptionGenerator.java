import java.util.*;
import java.io.*;

public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int b = Integer.parseInt("1.34");
      }
      catch (Exception a) {
         System.out.println("Caught Exception 'a'");
         System.out.println("--------------------");
         System.out.println(a);
         System.out.println("");
      }
      //ArrayIndexOutOfBoundsException
      try{
          int[] intArray = new int[10];
          intArray[11] = 12;
      }catch(Exception b){
          System.out.println("Caught Exception 'b'");
          System.out.println("--------------------");
          System.out.println(b);
          System.out.println("");
      }
      //StringIndexOutOfBoundsException
      try{
          String str = "bob";
          char chr = str.charAt(3);
      }catch(Exception c){
          System.out.println("Caught Exception 'c'");
          System.out.println("--------------------");
          System.out.println(c);
          System.out.println("");
      }
      //NegativeArraySizeException
      try{
          int[] negArray = new int[-1];
      }catch(Exception d){
          System.out.println("Caught Exception 'd'");
          System.out.println("--------------------");
          System.out.println(d);
          System.out.println("");
      }
      //NullPointerException
      try{
          String nullStr = null;
          char nullChar = nullStr.charAt(0);
      }catch(Exception e){
          System.out.println("Caught Exception 'e'");
          System.out.println("--------------------");
          System.out.println(e);
          System.out.println("");
      }
      //ArithmeticException
      try{
          int zero = 0;
          int two = 2;
          int answer = 2 / 0;
      }catch(Exception f){
          System.out.println("Caught Exception 'f'");
          System.out.println("--------------------");
          System.out.println(f);
          System.out.println("");
      }
      //FileNotFoundException
      try{
          String name = "bobthetomato.txt";
          File file = new File(name);
          Scanner scanIt = new Scanner(file);
      }catch(Exception g){
          System.out.println("Caught Exception 'g'");
          System.out.println("--------------------");
          System.out.println(g);
          System.out.println("");
      }
   }
}
