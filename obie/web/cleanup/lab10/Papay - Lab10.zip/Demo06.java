public class Demo06 {
   public void a() {
      System.out.println("Entering a()");

      try {
         b();
      }
      catch (TestException e) {
         System.out.println("\nCaught TestException!\n");
      }

      System.out.println("Exiting a()");
   }

   public void b() throws TestException {
      System.out.println("Entering b()");

      try {
         c();
      }
      catch (TestException e) {
         System.out.println("\nCaught TestException!\n");
         throw e;
      }
      finally {
         System.out.println("Exiting b()");
      }
   }

   public void c() throws TestException {
      System.out.println("Entering c()");
      throw new TestException("thrown by c");
   }

   public static void main(String[] args) {
      Demo06 test = new Demo06();

      System.out.println("Entering main()");
      test.a();
      System.out.println("Exiting main()");
   }
}

