import java.io.*;
import java.util.*;
public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
        Scanner stdin = new Scanner(System.in);
        Scanner fileIn = null;
        File file = new File("test.txt");
        fileIn = new Scanner(file);
        
        }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}
