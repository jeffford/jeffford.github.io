public class Demo02 {
   public void a() throws TestException {
      System.out.println("Entering a()");
      b();
      System.out.println("Exiting a()");
   }
   public void b() throws TestException {
      System.out.println("Entering b()");
      c();
      System.out.println("Exiting b()");
   }
   public void c() throws TestException {
      System.out.println("Entering c()");
      throw new TestException("thrown by c");
   }
   public static void main(String[] args) {
      Demo02 test = new Demo02();
      System.out.println("Entering main()");
      try {
         test.a();
      }
      catch (TestException e) {
         System.out.println("\nCaught TestException!\n");
      }
      System.out.println("Exiting main()");
   }
}
