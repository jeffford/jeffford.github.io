	public class TestException extends Exception {
  	 public TestException() {
  	 }
  	 public TestException(String s) {
     	 super(s);
   		}
	}
