import java.io.*;
import java.util.*;
public class ExceptionGenerator {
   public static void main(String[] args) {
      try {
         // Enter your code here for the exercises that follow
         int a=1/0;
         
         
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}
