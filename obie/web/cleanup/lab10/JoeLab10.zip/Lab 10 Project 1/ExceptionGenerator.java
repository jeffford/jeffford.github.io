import java.util.*;
import java.io.*;
public class ExceptionGenerator {
   public static void main(String[] args)throws IOException {
      try {
         // Enter your code here for the exercises that follow
         
         // ArrayIndexOutOfBoundsException: int[] b = new int[4];
         // b[5] = 2;
         
         // NumberFormatException: int b = Integer.parseInt("1.34");
         
         // StringIndexOutOfBoundsException: String b = "this is a test";
         // int t = b.charAt(15);
         
         // NegativeArraySizeException: int[] b = new int[-2];
         
         String b = null;
         String a = b.substring(2, 4);

         
         // ArithmeticException: int b = 0;
         // int a = 3 / b;
         
         // FileNotFoundException: File file = new File("Test.txt");
         // Scanner fileIn = new Scanner(file);
         
      }
      catch (Exception e) {
         System.out.println("Caught Exception 'e'");
         System.out.println("--------------------");
         System.out.println(e);
      }
   }
}

