/**@author (Kent Vasko)
*@version (Lab 6, Date)
*February 20, 2006
*This program has methods that can be called to view and change properties of two dates
*/


import java.lang.String.*;

public class Date {

    public static int month, day, year, numofdays, actdays = 0, estdays = 0;
    
    public static final int JANUARY = 1, FEBRUARY = 2, MARCH = 3, APRIL = 4, MAY = 5, 
    JUNE = 6, JULY = 7, AUGUST = 8, SEPTEMBER = 9, OCTOBER = 10, NOVEMBER = 11,
    DECEMBER = 12;
    
    public static String mois, jour, an, date;
    
    public static boolean leapyear, valid;
        
    /**determines if the date is a real month or day
     * 
     *@param  month, day, year  parameters for the method to check
     */
    public static void dateCon(int month, int day, int year) {
        if (day >=1 && day <= 31) {
            daysInMonth(month);
            if (numofdays == 0){
                valid = false;
            }
            else {
                valid = true;
            }
        }
        else
            valid = false;
            
        }
    
    /**converts the date to a string
     * 
     *@param  month, day, year  these integers are converted to a string
     *@return  the date as a string
     */
    public static String toString(int month, int day, int year) {        

        /**gives the month as a string*/
        if (month >= 1 || month <= 12) {
            valid = true;
            if (month == 1)                
                mois = "January ";
            else if (month == 2)
                mois = "February ";
            else if (month == 3)
                mois = "March ";
            else if (month == 4)
                mois = "April ";
            else if (month == 5)
                mois = "May ";
            else if (month == 6)
                mois = "June ";
            else if (month == 7)
                mois = "July ";
            else if (month == 8)
                mois = "August ";
            else if (month == 9)
                mois = "September ";
            else if (month == 10)
                mois = "October ";
            else if (month == 11)
                mois = "November ";
            else if (month == 12)
                mois = "December ";
            }
       else if (month < 1 || month > 12)
            valid = false;
        
       
        /**extra variables to be sure and converts the day and year to strings*/    
        String comma = ", ";
        jour = "" + day + "";
        an = "" + year + "";
        
        /**puts the date together in a string*/
        if (valid == false)
            date = "Invalid Date";
        else if (valid == true) {
            date = mois.concat(jour);
            date = date.concat(comma);
            date = date.concat(an);
        }
        return date;
    } 
        
        /**determines if the year is a leap year
         * 
         *@param  year  method checks to see if it meets the requirements of a leap year
         *@return  whether or not the year is a leap year
         */
        public static boolean isLeapYear(int year) {
            if (year%4 == 0) {
                if (year%100 == 0) {
                    if (year%400 == 0)
                        leapyear = true;
                    else
                        leapyear = false;
                    }
                else 
                    leapyear = true;
            }  
            else if(year%4 != 0)
                leapyear = false;
                
            return leapyear;
        }
        
        /**tells how many days are in each month
         * 
         *@param  month  used determine the number of days in the particular month
         *@return  the number of days in the month
         */
        public static int daysInMonth(int month) {        
            
            switch (month) {
                case JANUARY: case MARCH: case MAY: case JULY: case AUGUST:
                case OCTOBER: case DECEMBER:
                    numofdays = 31;
                    break;
                case APRIL: case JUNE: case SEPTEMBER: case NOVEMBER:
                    numofdays = 30;
                    break;
                case FEBRUARY:
                    if(leapyear == true) {
                        numofdays = 29;
                        break;
                    }
                    else if(leapyear == false) {
                        numofdays = 28;
                        break;
                    }
                default: 
                    numofdays = 0;
                }
            return numofdays; 
        }
        
        /**changes the date
         * 
         *@param  day2, month2, and year2  takes these values and changes the date
         *@return  whether or not the date is false
         */
        public static boolean changeDate(int day2, int month2, int year2) {
            if (month2 < 1 || month2 > 12)
                valid = false;
            else if (month2 >= 1 || month2 <= 12) {
                month = month2;
                year = year2;
                day = day2;
                daysInMonth(month);
                if (numofdays == 0)
                    valid = false;
                
                else {
                valid = true;
                /**changes the date*/    
                date = toString(month, day, year);
            }
        }
             
            return valid;
        }
        
        /**finds the difference between two dates approximately
         * 
         *@param  day, month, year, day2, month2, year2  used to figure out the approximate
         *difference between the dates
         *@return  the value of the estimated number of days
         */
        public static int estDaysUntil(int day, int month, int year, int day2, int month2, int year2) {
            
            if (year == year2 && month == month2 && day == day2){
                estdays = 0;
            }
            else {    
                int years = (year2 - year) * 365;
                int months = (month2 - month) * 30;
                int days = day2 - day;
                estdays = days + months + years;
            }
            return estdays;
        }
        
        /**finds the exact difference between two dates
         *
         *@param  day, month, year, day2, month2, year2  used to find the actual difference
         * in days between the two dates
         * @return  the value of the actual number of days between the dates
         */
        public static int actDaysUntil (int day, int month, int year, int day2, int month2, int year2) {
          
          /**finds the days in the years and leapyears*/            
          if (year2 > year) {  
            while(year2 > year) {
                isLeapYear(year);
                if (leapyear == true){ 
                    actdays += 366;
                }
                else if(leapyear == false){
                    actdays += 365;
                }
                year++;
            }
          }
          else if (year > year2) {
              while (year > year2) {
                  isLeapYear(year);
                  if(leapyear == true)
                    actdays -= 366;
                  else if(leapyear == false)
                    actdays -= 365;
                  
                  year--;
                }
            }
            
            else if (year == year2)
                actdays = actdays;
            
            /**finds the days in the months*/
            if (month2 > month) {
                while(month2 > month) {
                    daysInMonth(month);
                    if (numofdays == 0) 
                        valid = false;
                    else
                        actdays = actdays + numofdays;
                        ++month;
                    }
                }
            else if (month > month2) {
                while(month > month2) {
                    daysInMonth(month);
                    if (numofdays == 0)
                        valid = false;
                    else
                        actdays = actdays - numofdays;
                        --month;
                    }
                }
                
            /**finds the difference between the days*/
                if(day2 > day)
                    actdays = actdays + (day2 - day);
                else if (day > day2)
                    actdays = actdays - (day - day2);
                else
                    actdays = actdays;
        return actdays;}
}