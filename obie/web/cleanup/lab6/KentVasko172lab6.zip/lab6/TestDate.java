/**@author  (Kent Vasko)
 *@version  (Lab6 TestDate)
 *February 23, 2006
 */

import java.util.*;

/**This class was created to test the Date program*/
public class TestDate {

    public static void main (String[] args) {
        
        /**initializes input*/
        Scanner stdin = new Scanner(System.in);
        
        /**variables*/
        String date, date2;
        int d, m, y, estdays, actdays;
        boolean valid, leapyear, leapyear2;

        /**gives the user instructions*/
        System.out.println("This program will work with dates that you input.");
        System.out.println("");
        System.out.println("You will be prompted to enter two dates as the months, days and years.");
        System.out.println("");
        System.out.println("Please enter your dates in the following ways:");
        System.out.println("Enter the month as its corresponding number, for example January ");
        System.out.println("is 1 and December is 12.");
        System.out.println("Enter the day as an integer, for example 15 or 10.");
        System.out.println("Enter the year as an integer, for example 1500 or 2006.");
        System.out.println("");
        
        /**gets the input from the user*/
        System.out.println("Please enter the month for the first date:");
            int month = stdin.nextInt();
        System.out.println("Please enter the day for the first date:");
            int day = stdin.nextInt();
        System.out.println("Please enter the year for the first date:");
            int year = stdin.nextInt();
        System.out.println("Please enter the month for the second date:");
            int month2 = stdin.nextInt();
        System.out.println("Please enter the day for the second date:");
            int day2 = stdin.nextInt();
        System.out.println("Please enter the year for the second date:");
            int year2 = stdin.nextInt();
            
        /**calls the date constructor*/
        Date.dateCon(month, day, year);
        
        /**Converts the date to a string and outputs it*/
        date = Date.toString(month, day, year);
            System.out.println(date);
            
        /**Tells whether or not the first year is a leap year*/
        leapyear = Date.isLeapYear(year);
            if (leapyear == true) {
                System.out.println("The year of date1 is a leap year.");
            }
            else {
                System.out.println("The year of date1 is not a leap year.");
            }
           
        /**changes the values of the dates so the second date can be output*/
        valid = Date.changeDate(day2, month2, year2);
            d = day; 
            m = month; 
            y = year;
            day = day2;
            month = month2;
            year = year2;
            
            leapyear2 = Date.isLeapYear(year);
                if (leapyear2 == true) {
                    System.out.println("The year of date2 is a leap year.");
                }
                else {
                    System.out.println("The year of date2 is not a leap year.");
                }
            
            if(valid == true) {
                date2 = Date.toString(month, day, year);
                System.out.println(date2);
            }
            else if(valid == false) {
                date2 = "Invalid date";
                System.out.println(date2);
            }
        
        /**outputs the estimated days between the two dates*/
        day = d;
        month = m;
        year = y;
        estdays = Date.estDaysUntil(day, month, year, day2, month2, year2);
            System.out.println("The estimated number of days between date1" +
            " and date2 is " + estdays + " days.");
            
        /**outputs the actual days between the two dates*/
        actdays = Date.actDaysUntil(day, month, year, day2, month2, year2);
            System.out.println("The actual number of days between date1" +
            " and date2 is " + actdays + " days.");
    }
}