
/*
Andrew Winfield
Lab 6
2/10/2006
*/
import java.util.*;
public class testDate{
    public static void main(String[] args){
        Scanner asdf = new Scanner(System.in);
        Date date1 = new Date();
        Date date2 = new Date();
        String dateStr;
        boolean leap = false;
        int daysUntil;
        //enter the dates
        System.out.println("Enter the first date.(month day year) After every" +
                           " number hit enter.");
            int month1 = asdf.nextInt();
            int day1 = asdf.nextInt();
            int year1 = asdf.nextInt();
        System.out.println("Enter the second date.(month day year) After every" +
                           " number hit enter.");
            int month2 = asdf.nextInt();
            int day2 = asdf.nextInt();
            int year2 = asdf.nextInt();
        
        date1.con(day1, month1, year1);
        //test the toString
        dateStr = date1.toString();
            System.out.println(dateStr);
        //test the isLeapYear
        leap = date1.isLeapYear(year1);
            if(leap == true)
                System.out.println("The first year is a leap year.");
            else
                System.out.println("The first year is not a leap year.");
        date2.con(day2, month2, year2);
        dateStr = date2.toString();
            System.out.println(dateStr);
        leap = date2.isLeapYear(year2);
            if(leap == true)
                System.out.println("The second year is a leap year.");
            else
                System.out.println("The second year is not a leap year.");
        //test estimateDaysUntil    
        daysUntil = date1.estimatedDaysUntil(day2, month2, year2);
            System.out.println("The estimated days from the first date to the" +
                               " second are:" + "\n" + daysUntil);
        //test actualDaysUntil
        daysUntil = date1.actualDaysUntil(day2, month2, year2);
            System.out.println("The actual days from the first date to the" +
                               " second are:" + "\n" + daysUntil);
        //test changeDate
        boolean temp = date1.changeDate(1, 2, 3);
        System.out.println(temp);
    }
}