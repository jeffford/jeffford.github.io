
/*
Andrew Winfield
Lab 6
2/10/2006
*/
import java.lang.Object;

public class Date{
    private int day, month, year;
    /*Constructs the First Year
     * accepts ints day, month, year
     * */
    public void con(int d, int m, int y){
        int temp = daysInMonth(d, m, y);
        
        if(temp != 0){
            year = y;
            month = m;
            day = d;
        }else
            System.out.println("Invalid Date");
    }
    //Converts the constructed date from int to string
    public String toString(){
        String str = new String();
        
        String temp = "";
        String Sday, Syear;
        
        if(month == 1){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("January ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 2){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("Febuary ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 3){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("March ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 4){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("April ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 5){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("May ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 6){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("June ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 7){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("July ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 8){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("August ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 9){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("September ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 10){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("October ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if(month == 11){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("November ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else if (month == 12){
            Sday = str.valueOf(day);
            Syear = str.valueOf(year);
            temp = temp.concat("December ");
            temp = temp.concat(Sday);
            temp = temp.concat(", ");
            temp = temp.concat(Syear);
        }else{
            temp = "Invalid Date";
        }
        
        return temp;
    }
    //Determins if the year is a leap year
    public boolean isLeapYear(int y){
        boolean leap = false;
        
        int the4 = (y % 4);
        int the100 = (y % 100);
        int the400 = (y % 400);
        
        if(the4 == 0)
            leap = true;
        if(the100 == 0)
            leap = false;
        if(the400 == 0)
            leap = true;
        return leap;
    }
    //Determins if the day is a correct day in the month.
    public int daysInMonth(int d, int m, int y){
        final int jan = 1;
        final int feb = 2;
        final int mar = 3;
        final int apr = 4;
        final int may = 5;
        final int june = 6;
        final int july = 7;
        final int aug = 8;
        final int sep = 9;
        final int oct = 10;
        final int nov = 11;
        final int dec = 12;
        
        if(m < 1 || m > 12){
            System.out.println("Incorrect date.");
            System.exit(1);
        }
        
        switch(m){
            case jan:
                    d = 31;
                break;
            case feb:
                boolean asdf;
                asdf = isLeapYear(y);
                if(asdf = false){
                        d = 28;
                }else{
                        d = 29;
                }
                break;
            case mar:
                    d = 31;
                break;
            case apr:
                    d = 30;
                break;
            case may:
                    d = 31;
                break;
            case june:
                    d = 30;
                break;
            case july:
                    d = 31;
                break;
            case aug:
                    d = 31;
                break;
            case sep:
                    d = 30;
                break;
            case oct:
                    d = 31;
                break;
            case nov:
                    d = 30;
                break;
            case dec:
                    d = 31;
                break;
            default:
                d = 0;
        }
        
        return d;
    }
    /*Cheks if the new date is valid then changes the date and returns true.
     * accepts ints day, month, year
     * */
    public boolean changeDate(int d, int m, int y){
        boolean temp = false;
        int cnt = daysInMonth(d, m, y);
        
        if(cnt == 0){
            temp = false;
        }else{
            day = d;
            month = m;
            year = y;
            temp = true;
        }
        
        return temp;
    }
    /*Takes a new date, and compares the old date to estimate the difference in days.
     * accepts ints day, month, year
     * */
    public int estimatedDaysUntil(int d, int m, int y){
        int cntyear = 0, cntmonth = 0, cntday = 0;
        int estimate;
        
        if(y > year){
            while(y > year){
                cntyear = 365 - cntyear;
                y--;
            }
        }else{
            while(y < year){
                cntyear = 365 + cntyear;
                y++;
            }
        }
        if(m > month){
            while(m > month){
                cntmonth = 30 - cntmonth;
                m--;
            }
        }else{
            while(m < month){
                cntmonth = 30 + cntmonth;
                m++;
            }
        }
        if(d > day){
            while(d > day){
                cntday = 1 - cntday;
                d--;
            }
        }else{
            while(d < day){
                cntday = 1 + cntday;
                d++;
            }
        }
        estimate = cntyear + cntmonth + cntday;
        
        return estimate;
    }
    /*takes new date and calculates the number of days to the original date
     *accepts ints day, month, year
     * */
    public int actualDaysUntil(int d, int m, int y){
        boolean validDate= false;
        boolean leap = false;
        int actual = 0;
        int cntm = m;
        int cntd = d;
        int cnty = y;
        
        int temp = daysInMonth(d, m, y);
        
        if(temp == 0){
            validDate = false;
        }else{
            validDate = true;
        }
        if(validDate == true){
            if(cnty < year){
                while(year < cnty){
                    leap = isLeapYear(cnty);
                    if(leap == true){
                        actual = 366 + actual;
                    }else{
                        actual = 365 + actual;
                    }
                    cnty++;
                }
            }else{
                while(year > cnty){
                    leap = isLeapYear(cnty);
                    if(leap == true){
                        actual = actual - 366;
                    }else{
                        actual = actual - 366;
                    }
                    cnty--;
                }
            }
            if(cntm < month){
                while(cntm < month){
                    int cnt = daysInMonth(d, cntm, y);
                    actual = cnt - actual;
                    cntm--;
                }
            }else if(cntm > month){
                while(cntm > month){
                    int cnt = daysInMonth(d, cntm, y);
                    actual = cnt + actual;
                    cntm++;
                }
            }else{
                while(cntd <= day){
                    actual++;
                    cntd++;
                }
                while(cntd >= day){
                    actual--;
                    cntd--;
                }
            }
        }else{
            System.out.println("You did not enter a valid date.");
        }
        
        return actual;
    }
}
