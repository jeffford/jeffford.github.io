
/**
 *This class Date takes dates and tranforms them, or tells things about them.
 *
 * @Rebecca Fischer
 * @2/20/2006
 */
public class Date
{
// instance variables - replace the example below with your own
    private int month;
    private int day;
    private int year;

    /**
     * Default constructor for objects of class Date.
     */
    public Date()
    {
        // initialise instance variables

        month=0;
        day=0;
        year=0;
    }

    /**
     * Constructor for objects of class Date with inputs for month, day and year.
     */
    public Date(int x, int y, int z)
    {
        // initialise instance variables
        if (1<=x&&x<=12){
        month=x;
    }
        else{
            month=0;
        }
      if (daysInMonth()!=0){
        day=y;
    }
        else{
            day=0;
        }
      if (z>1600)
        year=z;
      else
        year=0;
    }
    /**
     * An assessor to get day.
     *
     * @return     an int
     */
     public int getDay(){
       return day;
    }
    /**
    * An assessor to get month.
    *
    * @return     an int
    */
    public int getMonth(){
      return month;
   }
   /**
    * An assessor to get year.
    *
    * @return     an int
    */
    public int getYear(){
      return year;
   }


    /**
     * A method to convert the date into a string of the format month/day/year.
     *
     * @return     a string
     */
        public String toString(){
            if (day!=0&&month!=0&&year!=0){
       String temp="" + month + "/" + day + "/" + year;
       return temp;
    }
    else{  String temp="" +"Invalid Date";
       return temp;
        }}
    /**
     * A method that tests whether or not the date is a leap year.
     *
     * @param y    a Date
     * @return     a boolean
     */
  public boolean leapYear(){
    if (year%400==0){ return true;}
    else if (year%100==0){return false;}
    else if ( year%4==0) {return true;}
    else return false;
}
  /**
    * A method that sets the maximum number of days in a month.
    *
    * @return     an int
    */

public int daysInMonth(){
     switch(getMonth()){
            case 1: if(month==1); return 31;
            case 2: if(month==2); return leapYear () ? 29 : 28;//example of a conditional statement
            case 3: if(month==3); return 31;
            case 4: if(month==4); return 30;
            case 5: if(month==5); return 31;
            case 6: if(month==6); return 30;
            case 7: if(month==7); return 31;
            case 8: if(month==8); return 31;
            case 9: if(month==9); return 30;
            case 10: if(month==10); return 31;
            case 11: if(month==11); return 30;
            case 12: if(month==12); return 31;
           default: return 0;
         }}

       /**
             * Test whether or not a date is valid
             *
             * 
             * @return     a boolean
             */
  public boolean isValid(){
            if(day!=0&&month!=0&&year!=0){
                return true;
                }
              else
                return false;
            }
    /**
             * Changes the date if the date is valid
             *
             * @param a    an int
             * @param b    an int
             * @param c    an int
             * @return   a boolean
             */
     public boolean changeDate(int a, int b, int c){
         Date temp = new Date(a,b,c);
         if(temp.isValid()==true){
         month=a;
         day=b;
         year=c;
         return true;
        }
        else
           return false;}
           /**
             * Estimates the number of days between two dates.
             *
             * @param y    a Date
             * @param x    a Date
             * @return     an int
             */
  public int estimatedDaysUntil(Date y, Date x){
              int yearSum= 365*(x.getYear()-y.getYear());
              int monthSum=30*(x.getMonth()-y.getMonth());
              int daySum= (x.getDay()-y.getDay());
              int sum= yearSum+monthSum+daySum;
              return sum;

    }
    /**
      * Gives the number of days between two dates.
      *
      * @param y    a Date
      * @param x    a Date
      * @return     an int
      */

  public int actualDaysUntil(Date y, Date x){
         int yearOne=0;
         int yearTwo=0;
         int count1=0;
         int count2=0;
         int count3=0;
         int count4=0;
         int sum=0;
         int keepYear1=y.year;
         int keepYear2=x.year;
         int daySum=0;
               if(y.year<x.year){
          while(y.month<x.month){
              count3=count3+y.daysInMonth();
               y.month++;
            }
          while(y.month>x.month){
              count4=count4-x.daysInMonth();
               x.month++;
            }}
            if(y.year>x.year){
          while(y.month<x.month){
              count3=count3-y.daysInMonth();
               y.month++;
            }
          while(y.month>x.month){
              count4=count4+x.daysInMonth();
               x.month++;
            }}
         while(y.year<x.year){
            if(y.leapYear()==false){
                count1++;
                y.year=y.year+1;}
                else{
                  count2++;
                  y.year=y.year+1;}}
          while(y.year>x.year){
            if(x.leapYear()==false){
                count1++;
                x.year=x.year+1;}
                else{
                  count2++;
                  x.year=x.year+1;}}


              int yearSum=365*count1+366*count2;
              int monthSum=count3+count4;
              if(keepYear2>keepYear1){
                    daySum= x.getDay()-y.getDay();
                sum= Math.abs(yearSum+monthSum+daySum);}
              else{
                  daySum= y.getDay()-x.getDay();
                  sum= -Math.abs(yearSum+monthSum+daySum);
                        }
              return sum;

    }}
