
/**
 * This class tests the class Date. 
 * 
 * @author R.Fischer
 * @version 2/26/2006
 */
import java.util.*;
public class Test
{
    public static void main(String args[]){
        
        //get fist date
        System.out.println("Enter the day of first the date you wish to enter in the format dd:");
        Scanner stdin= new Scanner(System.in);
        int day1=stdin.nextInt();
        System.out.println("Enter the month of the first date you wish to enter in the format mm");
        int month1=stdin.nextInt();
        System.out.println("Enter the year of the first date you wish to enter in the format yyyy");
        int year1=stdin.nextInt();
        Date test1= new Date(month1, day1, year1);
        //get second date
        
        System.out.println("Enter the day of second the date you wish to enter in the format dd:");
        int day2=stdin.nextInt();
        System.out.println("Enter the month of the second date you wish to enter in the format mm");
        int month2=stdin.nextInt();
        System.out.println("Enter the year of the second date you wish to enter in the format yyyy");
        int year2=stdin.nextInt();
        Date test2= new Date(month2, day2, year2);
        
        //do calculations and output 
        System.out.println("The first date input was: ");
        System.out.println(test1.toString());
         System.out.println("The number of days in the month of the first date is: ");
        System.out.println(test1.daysInMonth());
         System.out.println("The number of estimated days between the two dates is:");
        System.out.println(test1.estimatedDaysUntil(test1, test2));
        System.out.println("The number of days between the two dates is:");
        System.out.println(test1.actualDaysUntil(test1, test2));
        System.out.println("It is "+test1.leapYear()+" that the year of the first date is a leap year.");
        System.out.println("It is "+test2.leapYear()+" that the year of the second date is a leap year.");
        test1.changeDate(11,23,2005);
        System.out.println("The first date changed is: " +test1);
        
    }}