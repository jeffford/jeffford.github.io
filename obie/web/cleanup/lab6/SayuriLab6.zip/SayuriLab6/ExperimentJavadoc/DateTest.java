/**
 * The class DateTest shows off all of the abilities of the class Date.
 * 
 * @author (Sayuri Ichida) 
 * @version (Lab 6, date completed-2/27/2006, date submitted-2/27/2006)
 */
import java.util.*;
public class DateTest
{
	
	/**
	 * The main method
	 * 
	 * @param  args with type String[]
	 */
	public static void main (String [] args) {
	
	// setup scanner
    Scanner stdin = new Scanner(System.in);
    System.out.println();
    
    // input values for year, month, and day of the first date
    System.out.println("Enter the first date.");
    System.out.print("     Enter a year as an integer: ");
    int year1 = stdin.nextInt();
    
    System.out.print("     Enter a month as an integer: ");
    int month1 = stdin.nextInt();
    
    System.out.print("     Enter a day as an integer: ");
    int day1 = stdin.nextInt();
    
    Date first_date = new Date(year1,month1,day1);
    
    System.out.println("You have entered " + first_date.toString() + ".");
    
    // check if the year of the first date is a leap year
    boolean leap1 = first_date.isLeapYear();
    if (leap1 == true) {
        System.out.println("The year, " + year1 + ", is a leap year.");
    }
    else {
       System.out.println("The year, " + year1 + ", is not a leap year.");
    }
    
    System.out.println();
    
    // input values for year, month, and day of the new date
    // to which the first date will be changed
    // if the new date is valid
    System.out.println("Change the first date to another date.");
    System.out.print("     Enter a year as an integer: ");
    int year1c = stdin.nextInt();
    
    System.out.print("     Enter a month as an integer: ");
    int month1c = stdin.nextInt();
    
    System.out.print("     Enter a day as an integer: ");
    int day1c = stdin.nextInt();
    
    boolean c = first_date.changeDate(year1c,month1c,day1c);
    
    if (c == true) {
        System.out.println("You have changed the first date to " + first_date.toString() + ".");
        if (first_date.isLeapYear() == true) {
            System.out.println("The year, " + year1c + ", is a leap year.");
        }
        else {
            System.out.println("The year, " + year1c + ", is not a leap year.");
        }
    }
    else {
        System.out.println("Since you entered the invalid date, the first date did not change.");
    }
        
    System.out.println();
    
    // input values for year, month, and day of the second date
    System.out.println("Enter the second date.");
    System.out.print("     Enter a year as an integer: ");
    int year2 = stdin.nextInt();
    
    System.out.print("     Enter a month as an integer: ");
    int month2 = stdin.nextInt();
    
    System.out.print("     Enter a day as an integer: ");
    int day2 = stdin.nextInt();
    
    Date second_date = new Date(year2,month2,day2);
    
    System.out.println("You have entered " + second_date.toString() + ".");
    
    // check if the year of the second date is a leap year
     if (second_date.isLeapYear() == true) {
        System.out.println("The year, " + year2 + ", is a leap year.");
    }
    else {
        System.out.println("The year, " + year2 + ", is not a leap year.");
    }
    
    System.out.println();
    
    if (first_date.getDate(3) != 0) {
    if (second_date.getDate(3) != 0) {
    // calculate the estimated number of days from the first day until the second day
    int estimated_days_until = first_date.estimatedDaysUntil(second_date);    
    // calculate the actual number of days from the first day until the second day
    int actual_days_until = first_date.actualDaysUntil(second_date);
    // print out the result of the two calculations above
    System.out.println("The number of days from the first date until the second date:");
    System.out.println("             estimated number of days: " + estimated_days_until);
    System.out.println("             actual number of days: " + actual_days_until);
    }
    }
    
    System.out.println();
	    
	}
}
