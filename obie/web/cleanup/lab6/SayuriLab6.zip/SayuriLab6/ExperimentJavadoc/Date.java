
/**
 * Class Data has the isLeapYear method to determine if the year is a leap year or not
 * and the daysInMonth method to that returns the number of days in the month.
 * Moreover, the class Date has the estimatedDaysUntila method
 * to calculate the estimated number of days until another date.
 * The class code has also the actualDaysUntil method
 * to calcualte the actual number of days until another date
 * using the isLeapYear method and daysInMonth method.
 * 
 * @author (Sayuri Ichida) 
 * @version (Lab 6, date completed-2/27/2006, date submitted-2/27/2006)
 */
public class Date
{
    // instance variables to describe the object attributes
    private int year;
    private int month;
    private int day;

    /**
     * Default constructor for objects of class Data
     */
    public Date()
    {
        int year = 1;
        int month = 1;
        int day = 1;
    }
    
    /**
     * Specific constructor for objects of class Data
     */
    public Date(int y, int m, int d) {
        Date initial = new Date();
        initial.setDate(1, y);
        initial.setDate(2, m);
        if (m < 1 || m > 12) {
            setDate(3,0);
            System.out.println("Bad request for month: " + m);
        }
        else if (d < 1 || d > initial.daysInMonth()) {
            setDate(3,0);
            System.out.println("Bad request for month: " + d);
        }
        else {
            setDate(1, y);
            setDate(2, m);
            setDate(3, d);
        }
    }

    /**
     * Date mutator that sets the year, month, and day of the date
     * 
     * @param  i an integer
     *         value the year, month, and day in integers
     */      
    public void setDate(int i, int value) {
      switch (i) {
          case 1: year = value; return;
          case 2: month = value; return;
          case 3: day = value; return;
          default:
              System.err.println("Machine: bad get; " + i);
              System.exit(i);
              return;
      }
    }
    
    /**
     * Date accessor that provides the year, month, and day of the date
     * 
     * @param  i an integer
     * @return     the year, month, and day of the date
     */      
    public int getDate(int i) {
        switch (i) {
            case 1: return year;
            case 2: return month;
            case 3: return day;
            default:
                System.err.println("Machine: bad get; " + i);
                System.exit(i);
                return i;
            }
    }
    
    /**
     * Converts the year, month, and day to string suitable for outputs 
     * 
     * @return     a string for a date such as "February 11, 2004" 
     */
    public String toString() {
        int y = getDate(1);
        int m = getDate(2);
        int d = getDate(3);
        String name_month = "a";
        switch (m) {
            case 1: name_month = "January"; break;
            case 2: name_month = "February"; break;
            case 3: name_month = "March"; break;
            case 4: name_month = "April"; break;
            case 5: name_month = "May"; break;
            case 6: name_month = "June"; break;
            case 7: name_month = "July"; break;
            case 8: name_month = "August"; break;
            case 9: name_month = "September"; break;
            case 10: name_month = "October"; break;
            case 11: name_month = "November"; break;
            case 12: name_month = "December"; break;
            default: System.out.println("Unexpected request: " + m);
        }
        if (d == 0) {
            return "Invalid Date";
        }
        else {
            return name_month + " " + d + ", " + y;
        }
    }
    
    /**
     * Determines if the year is a leap year or not
     * 
     * @return     true if the year is a leap year and false otherwise 
     */
    public boolean isLeapYear() {
        boolean isDivisibleBy4 = (year % 4) == 0;
        boolean isDivisibleBy100 = (year % 100) == 0;
        boolean isDivisibleBy400 = (year % 400) == 0;
        return isDivisibleBy4 && ((! isDivisibleBy100) || isDivisibleBy400);
    }
    
    /**
     * Returns the number of days in the month 
     * 
     * @return     the number of days as an integer in the month 
     */
    public int daysInMonth () {
        int days = 0;
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
               days = 31;
               break;
            case 4: case 6: case 9: case 11:
               days = 30;
               break;
            case 2:
               Date initial = new Date();
               initial.setDate(1, year);
               days = initial.isLeapYear() ? 29: 28;
               break;
            default: System.out.println("Unexpected request: " + month);
        }
        return days;
    }
    
    /**
     * Returns true if the new date is valid and flase otherwise
     * and changes the date to the new date
     * 
     * @param  y year
     *         m month
     *         d day
     * @return     true if the new date is valid and false otherwise
     */     
    public boolean changeDate(int y, int m, int d) {
        Date change = new Date();
        change.setDate(1, y);
        change.setDate(2, m);
        if (m < 1 || m > 12) {
            System.out.println("Bad request for month: " + m);
            setDate(3,0);
            return false;
        }
        else if (d < 1 || d > change.daysInMonth()) {
            System.out.println("Bad request for day: " + d);
            setDate(3,0);
            return false;
        }
        else {
            setDate(1, y);
            setDate(2, m);
            setDate(3, d);
            return true;
        }
    }
        
    /**
     * Returns the estimated number of days until another date
     * 
     * @param  x the date in integers
     * @return     the estimated difference in days between two dates
     * by assuming ever year has 365 days and every month has 30 days
     */         
    public int estimatedDaysUntil(Date x)  {
        return (x.getDate(1) - year) * 365 + (x.getDate(2) - month) * 30 + (x.getDate(3) - day);
    }
    
    /**
     * Returns the actual number of days until another date 
     * 
     * @param  x the date in integers
     * @return     the actual difference in days between two dates
     * by taking into account leap years and the different number of days in each month
     */
    public int actualDaysUntil (Date x) {
        Date initial = new Date();
        initial.setDate(1, year);
        initial.setDate(2, month);

        // calculate year_actual: sum of the days of each year between the year
        //                        of the first date and the second date
        //                        (not including the years of the first and the second dates)
        int year_actual = 0;  
        int a = 0;
        // when the first date is before the second date
        if (x.getDate(1) > year + 1) {
            for (int yy = year + 1; yy < x.getDate(1); ++yy) {
                Date yyy = new Date();
                yyy.setDate(1, yy);
                // when the year is a leap year
                if (yyy.isLeapYear() == true) { a = 366; }
                // when the year is not a leap year
                else { a = 365; }
                year_actual = year_actual + a;
            }
        }
        // when the first date is after the second date
        else if (x.getDate(1) < year - 1) {
            for (int yy = x.getDate(1) + 1; yy < year; ++yy) {
                Date yyy = new Date();
                yyy.setDate(1, yy);
                // when the year is a leap year
                if (yyy.isLeapYear() == true) { a = 366; }
                // when the year is not a leap year
                else { a = 365; }
                year_actual = year_actual - a;
            }
        }
        
        // calculate month_actual: sum of the days of each month between the month
        //                         of the first date and the second date
        //                         (not including the months of the first and the second dates)
        int month_actual = 0;
        // when the year of the first date and the year of the second date is the same
        if (year == x.getDate(1)) {
            // when the first date is before the second date
            if (month < x.getDate(2)) {
                for (int mm = month; mm < x.getDate(2); ++mm) {
                    Date mmm = new Date();
                    mmm.setDate(1, year);
                    mmm.setDate(2, mm);
                    month_actual = month_actual + mmm.daysInMonth();
                }
            }
            // when the first date is after the second date
            else {
                for (int mm = x.getDate(2); mm < month; ++mm) {
                    Date mmm = new Date();
                    mmm.setDate(1, x.getDate(1));
                    mmm.setDate(2, mm);
                    month_actual = month_actual - mmm.daysInMonth();
                }
            }
        }
        // when the year of the first date is before the year of the second date
        else if (year < x.getDate(1)) {
            for (int mm1 = month + 1; mm1 <= 12; ++mm1) {
                Date mmm1 = new Date();
                mmm1.setDate(1, year);
                mmm1.setDate(2, mm1);
                month_actual = month_actual + mmm1.daysInMonth();
            }
            for (int mm2 = 1; mm2 < x.getDate(2); ++mm2) {
                Date mmm2 = new Date();
                mmm2.setDate(1, x.getDate(1));
                mmm2.setDate(2, mm2);
                month_actual = month_actual + mmm2.daysInMonth();
            }
        }
        // when the year of the first date is after the year of the second date
        else {
            for (int mm1 = x.getDate(2); mm1 <= 12; ++mm1) {
                Date mmm1 = new Date();
                mmm1.setDate(1, x.getDate(1));
                mmm1.setDate(2, mm1);
                month_actual = month_actual - mmm1.daysInMonth();
            }
            for (int mm2 = 1; mm2 < month; ++mm2) {
                Date mmm2 = new Date();
                mmm2.setDate(1, year);
                mmm2.setDate(2, mm2);
                month_actual = month_actual - mmm2.daysInMonth();
            }
        }
        
        // calcualte day_actual
        int day_actual = 0;
        // when the year and the month of the first and the second dates are the same
        if ((year == x.getDate(1)) && (month == x.getDate(2))) {
            day_actual = x.getDate(3) - day;
        }
        // when the year of the first date is before the year of the second date
        else if (year < x.getDate(1)) {
            day_actual = (initial.daysInMonth() - day) + x.getDate(3);            
        }
        // when the year of the first date is after the year of the second date
        else if (year > x.getDate(1)) {
            day_actual = -((x.daysInMonth() - x.getDate(3)) + day);
        }
                   
        return year_actual + month_actual + day_actual;
    }
}
