
/**
 * The date class performs various operations on calendar dates.
 * 
 * @author Kyli Foltz 
 * @version 2/20/2006
 */
public class Date {
    // instance variables needed to describe a date
    private int month;
    private int day;
    private int year;
    
    // getMonth(): accessor
        public int getMonth() {
            return month;
        }
        
   // getYear(): accessor
        public int getYear() {
            return year;
        }
   
   // getDay)(): accessor
        public int getDay() {
            return day;
        }

    /**
     * Specific constructor to describe the month, day, and year of a date
     */
    public Date(int themonth, int theday, int theyear)
    {
        // initialize instance variables describing the month, day, and year
        year = theyear;
        
        if (themonth >=1 && themonth <= 12) 
            month = themonth;
        else {
            month = 0;
            day = 0;
        }
            
        if (theday >= 1 && theday <= this.daysInMonth(month, theday))
            day = theday;
        else
            day = 0;
    }
    
    /**
     * toString method - convert the integer date into a string
     * 
     * @return      String date if date is valid
     * @return      String date Invalid date if date is invalid
     */
    public String toString() {
        // convert the date
        if (day == 0) 
            return "Invalid date.";
        else {
            String date = "";
            switch (month) {
            case 1:
                date = "January " + day + ", " + year;
                break;
            case 2:
                date = "February " + day + ", " + year;
                break;
            case 3:
                date = "March " + day + ", " + year;
                break;
            case 4:
                date = "April " + day + ", " + year;
                break;
            case 5:
                date = "May " + day + ", " + year;
                break;
            case 6:
                date = "June " + day + ", " + year;
                break;
            case 7:
                date = "July " + day + ", " + year;
                break;
            case 8:
                date = "August " + day + ", " + year;
                break;
            case 9:
                date = "September " + day + ", " + year;
                break;
            case 10:
                date = "October " + day + ", " + year;
                break;
            case 11:
                date = "November " + day + ", " + year;
                break;
            case 12:
                date = "December " + day + ", " + year;
                break;
            default:
                date = "Invalid date";
            }
            return date;
        }
        }

/**
     * isLeapYear method - check to see if the year is a leap year
     * 
     * @param      theyear - represents the year
     * @return     true if the year is a leap year
     */
    public boolean isLeapYear(int theyear) {
        if (theyear%4 == 0) {
            if (theyear%100 == 0 && theyear%400 != 0)
                return false;
            else
                return true;
    }
        else return false;
    }

/**
     * daysInMonth method - determine the number of days in each month
     * 
     * @param      theyear - represents the year
     * @param      themonth - represents the month
     * @return     the number of days in the month
     */
    public int daysInMonth(int themonth, int theyear) {
        int days = 1;
        switch (themonth) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                days = 31;
                break;
            case 2:
                if (isLeapYear(theyear))
                    days = 29;
                else
                    days = 28;
                break;
            case 4: case 6: case 9: case 11:
                days = 30;
                break;
        }
        return days;
    }

/**
     * changeDate method - checks to see if a requested date change is valid    
     * 
     * @parameters  theday, themonth, theyear
     * @return      true if change is valid, otherwise false
     */   
    public boolean changeDate(int theday, int themonth, int theyear) {
        if (themonth >=1 && themonth <= 12  && theday >= 1 && theday <= this.daysInMonth(month, theday)) {
            month = themonth;
            day = theday;
            year = theyear;
            return true;
        }
        else
            return false;
        }

/**
     * estimatedDaysUntil method - estimates the number of days between two dates    
     * 
     * @parameters  a Date object
     * @return      number of days between the dates
     */   
    public int estimatedDaysUntil(Date z) {
        int yearsUntil = year - z.getYear();
        int monthsUntil = month - z.getMonth();
        int dayUntil = day - z.getDay();
        int daysUntil = yearsUntil * 365 + monthsUntil * 30 + dayUntil;
        return daysUntil;
    }

/**
     * actualDaysUntil method - computes the exact number of days between two dates    
     * 
     * @parameters  a Date object
     * @return      number of days between the dates
     */   
    public int actualDaysUntil(Date z) {
        int yearsUntil = year - z.getYear();
        int monthsUntil = month - z.getMonth();
        int dayUntil = day - z.getDay();
        int daysUntil = 0;
        if (yearsUntil >= 0) {
            int sum = 0;
            for (int i = z.getYear(); i < year; ++i) {
                if (isLeapYear(i))
                    sum = sum + 366;
                else 
                    sum = sum + 365;
                }
             daysUntil = sum;   
            }
        else {
            int sum = 0;
            for (int i = year; i < z.getYear(); ++i) {
                if (isLeapYear(i))
                    sum = sum - 366;
                else
                    sum = sum - 365;
                }
            daysUntil = sum;
            }
        
        if (monthsUntil >= 0) {
            int sum = 0;
            for (int i = z.getMonth(); i < month; ++i) {
              sum = sum + this.daysInMonth(i, z.getYear());
                }
            daysUntil = daysUntil + sum;
         }
        else {
            int sum = 0;
            for (int i = month; i < z.getMonth(); ++i) {
                sum = sum - this.daysInMonth(i, z.getYear());
                }
            daysUntil = daysUntil + sum;
            }
        daysUntil = daysUntil + dayUntil;
        return daysUntil;
    }
}
