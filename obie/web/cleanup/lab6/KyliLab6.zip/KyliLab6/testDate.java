
/**
 * To exercise the Date class
 * 
 * @author Kyli Foltz 
 * @version 2/27/2006
 */
import java.util.*;

public class testDate {
    public static void main(String [] args) {
        System.out.println("This program performs various operations on two dates.");
        Scanner stdin = new Scanner(System.in);
        System.out.print("Please enter an integer representing the month of the first date: ");
        int month1 = stdin.nextInt();
        System.out.print("Please enter an integer representing the day of the month: ");
        int day1 = stdin.nextInt();
        System.out.print("Please enter an integer representing the year: ");
        int year1 = stdin.nextInt();
        Date date1 = new Date(month1, day1, year1);
        
        System.out.println("");
        System.out.print("Please enter an integer representing the month of the second date: ");
        int month2 = stdin.nextInt();
        System.out.print("Please enter an integer representing the day of the month: ");
        int day2 = stdin.nextInt();
        System.out.print("Please enter an integer representing the year: ");
        int year2 = stdin.nextInt();
        Date date2 = new Date(month2, day2, year2);
        
        System.out.println("");
        System.out.println(date1.toString());
        System.out.println(date2.toString());
    
        if (date1.isLeapYear(year1)) 
            System.out.println("The year " + year1 + " is a leap year.");
        else
            System.out.println("The year " + year1 + " is not a leap year.");
            
        if (date2.isLeapYear(year2))
            System.out.println("The year " + year2 + " is a leap year.");
        else
            System.out.println("The year " + year2 + " is not a leap year.");
        
        int days1 = date2.estimatedDaysUntil(date1);
        System.out.println("The estimated number of days from the first date until the second date is " + days1 + ".");
        int days2 = date2.actualDaysUntil(date1);
        System.out.println("The actual number of days from the first date until the second date is " + days2 + ".");
        System.out.println("If the number of days is negative the second date is before the first date.");
    
        System.out.println("");
        System.out.print("Please enter an integer representing the month of a date to replace the first date: ");
        int month3 = stdin.nextInt();
        System.out.print("Please enter an integer representing the day of the new month: ");
        int day3 = stdin.nextInt();
        System.out.print("Please enter an integer representing the new year: ");
        int year3 = stdin.nextInt();
        date1.changeDate(month3, day3, year3);
        System.out.println("After the date change: ");
        
        System.out.println("");
        System.out.println(date1.toString());
        System.out.println(date2.toString());
    
        if (date1.isLeapYear(year1)) 
            System.out.println("The new year " + year3 + " is a leap year.");
        else
            System.out.println("The new year " + year3 + " is not a leap year.");
            
        if (date2.isLeapYear(year2))
            System.out.println("The year " + year2 + " is a leap year.");
        else
            System.out.println("The year " + year2 + " is not a leap year.");
        
        int days1a = date2.estimatedDaysUntil(date1);
        System.out.println("The estimated number of days from the new first date until the second date is " + days1a + ".");
        int days2a = date2.actualDaysUntil(date1);
        System.out.println("The actual number of days from the new first date until the second date is " + days2a + ".");
        System.out.println("If the number of days is negative the second date is before the new first date.");
    }
}