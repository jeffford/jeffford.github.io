/**
 * This class tests the class Date. 
 * @author Dominique Godfrey 
 * 2/27/2006
 */

import java.util.*;
public class Test
{
    public static void main(String[] args){
//setup scanner 
Scanner stdin = new Scanner(System.in);
System.out.println();

//input date 
    
System.out.print("Enter a number month: ");
int month1 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day1 = stdin.nextInt();
System.out.print("Enter a year: ");
int year1 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();

System.out.print("Enter a number month: ");
int month2 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day2 = stdin.nextInt();
System.out.print("Enter a year: ");
int year2 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();

System.out.print("Enter a number month: ");
int month3 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day3 = stdin.nextInt();
System.out.print("Enter a year: ");
int year3 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();

System.out.print("Enter a number month: ");
int month4 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day4 = stdin.nextInt();
System.out.print("Enter a year: ");
int year4 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();

System.out.print("Enter a number month: ");
int month5 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day5 = stdin.nextInt();
System.out.print("Enter a year: ");
int year5 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();

System.out.print("Enter a number month: ");
int month6 = stdin.nextInt();
System.out.print("Enter a day of that month: ");
int day6 = stdin.nextInt();
System.out.print("Enter a year: ");
int year6 = stdin.nextInt();
System.out.println();
System.out.println();
System.out.println();


      Date test1 = new Date(month1, day1, year1);
      Date test2 = new Date(month2, day2, year2);
      Date test3 = new Date(month3, day3, year3);
      Date test4 = new Date(month4, day4, year4);
      Date test5 = new Date(month5, day5, year5);
      Date test6 = new Date(month6, day6, year6);
      
      
        
        System.out.println(test1.daysInMonth());
        System.out.println(test2.estimatedDaysUntil(test1, test2));
        System.out.println(test3.actualDaysUntil(test3, test4));
        System.out.println(test4.toString());
        System.out.println(test5.leapYear());
       
        
        
        
    }}

