
/**
 *Here is a Class Date which takes dates and tranforms them, or tells things about them.
 * Dominique Godfrey 
 * 2-27-06
 */
public class Date
{
// instance variables
    private int month;
    private int day;
    private int year;
    
/**
* Default constructor for class Date.
* inputs for month, day and year.
*/
    public Date(int a,
    int b,
    int c)
    {
// initialise instance variables
 
        if (1<=a&&a<=12){
        month=a;
    }
        else{
            month=0;
        }
      if (1<=b&&b<=31){
        day=b;
    }
        else{
            day=0;
        }
        year=c;
    }
    
    
/**
* An assessor to get month.
* return a string
*/
    public int getMonth(){
      return month;
   }
   
/**
* An assessor to get day
* return a string
*/
     public int getDay(){
       return day;
    }
    
/**
* An assessor to get year.
*return a string
*/
    public int getYear(){
      return year;
   }
   
/**
* converting the date into a string in the format of month, day, year.
* @return a string
*/
       public String toString(){
       String temp="" + month + "," + day + "," + year;
       return temp;
    }

/**
* testing whether the date is a leap year or not. 
* @param b a Date
* @return a boolean
*/
  public boolean leapYear(){
    if (year%400==0&&year%4==0){return true;}
    else if (year%100==0){return false;}
    else return false;
}
/**
*  seting the maximum number of days in a month.  
* @param b a Date
* @return an int
*/

public int daysInMonth(){
     switch(getMonth()){
            case 1: return 31;
            case 2: 
            if(leapYear()) 
                return 29;
            else
                return 28;
            case 3: return 31;
            case 4: return 30;
            case 5: return 31;
            case 6: return 30;
            case 7: return 31;
            case 8: return 31;
            case 9: return 30;
            case 10: return 31;
            case 11: return 30;
            case 12: return 31;
            default: return 0;
         }}

/**
* Change dates . 
* @param a, b, c 
 * @return an int
*/
public boolean changeDate(int a, int b, int c){
         Date temp = new Date(a,b,c);
         if(temp.isValid()==true){
         month=a;
         day=b;
         year=c;
         return true;
        }
        else
           return false;}
public boolean isValid(){
            if(month!=0&&day!=0&&year!=0){
                return true;
                }
              else
                return false;
        }


/**
* Estimates the number of days between two dates. 
* @param b a Date
 * @return an int
*/

  public int estimatedDaysUntil(Date b, Date a){
              int monthSum=30*(a.getMonth()-b.getMonth());
              int daySum= (a.getDay()-b.getDay());
              int yearSum= 365*(a.getYear()-b.getYear());
              int sum= monthSum+daySum+yearSum;
              return sum;
            
    }
/**
* Estimates the number of days between two dates. 
* @param b a Date
* @return an int
*/

  public int actualDaysUntil(Date b, Date a){
         int yearOne=0;
         int yearTwo=0;
         if(b.leapYear()==false){
                  yearOne= 365*b.getYear();}
                else {
                  yearOne = 366*b.getYear();}
              if(a.leapYear()==false){
                  yearTwo= 365*a.getYear();}
                else {
                     yearTwo = 366*a.getYear();}
             
              int monthSum=(a.daysInMonth()*a.getMonth())-(b.daysInMonth()*b.getMonth());
              int daySum= (a.getDay()-b.getDay());
              int yearSum= (yearTwo-yearOne);
              int sum= monthSum+daySum+yearSum;
              return sum;

    }
    
}

