/**
 * The class Date was created to allow the output of dates.
 * 
 * @author Joe Moeller
 * @version 2/20/2006
*/

public class Date {

    // instance variables are brought into the class
    private int year, month, day;
    
    /**
     * Constructor for the objects of Date class 
     */
    
    public Date(int y, int m, int d) {
      // initialize instance variables
      year = y;
   
        if (m >= 1 && m <= 12){
            month = m;
            int actualDays = daysInMonth(month);
            if (d <= actualDays && d >= 1)
                day = d;
            else 
                day = 0;
                }
        else {
            month = 0;
            day = 0;
            }
    
    }
      /**
       * method changeDate allows the user to change the set date to 
       * something different.  
       */
      public boolean changeDate(int y, int m, int d) {
         if (m >= 1 && m <= 12){
            int actualDays = daysInMonth(month);
            if (d <= actualDays && d >= 1){
                day = d;
                month = m;
                year = y;
                return true;}
            else {
                return false;}
                }
        else {
            return false;
            }
    
    }
     /**
      * method estimatedDaysUntil gives an estimated reading of the 
      * number of days between the first date and the second date.
      */
     public int estimatedDaysUntil(int y, int m, int d) {
         int tempmonth,tempm,tempyear,tempy,tempday,tempd;
         int yDifference, yProduct, mDifference, mProduct, dDifference;
         if (year <= y){
            if (month <= m) {
                mDifference = m - month;
                mProduct = mDifference * 30;
                yDifference = (y - year);
            }
            else {                
                mDifference = (12 - month) + (m);
                mProduct = mDifference * 30;
                yDifference = (y - year) - 1;
             }
              yProduct = yDifference * 365;
             if (day <= d) {
                 dDifference = d - day;
             }
             else {
                dDifference = 0;
            }
             return mProduct + yProduct + dDifference;
         }
     
         else {
             
             tempmonth=m;
             tempm=month;
             tempyear=y;
             tempy=year;
             tempday=d;
             tempd=day;
             
         if (tempmonth <= tempm) {
                mDifference = tempm - tempmonth;
                mProduct = mDifference * 30;
                yDifference = (tempy - tempyear);
            }
            else {                
                mDifference = (12 - tempmonth) + (tempm);
                mProduct = mDifference * 30;
                yDifference = (tempy - tempyear) - 1;
             }
              yProduct = yDifference * 365;
             if (tempday <= tempd) {
                 dDifference = tempd - tempday;
             }
             else {
                dDifference = 0;
            }
            System.out.println(mProduct + " " + yProduct + " " + dDifference);
             return (mProduct + yProduct + dDifference)* -1;
            
         }
        }
             
        /**
         * method actualDaysUntil allows the user to find the actual 
         */     
             
             
public int actualDaysUntil(int y, int m, int d) {
        int yDifference, dDifference, daysInYear, yProduct, mDifference, mProduct, dayInMonth1, dayInMonth2;; 
         if (year <= y){
            daysInMonth(month);
            //dayInMonth1 = Date.daysInMonth(month); 
            //dayInMonth2 = Date.daysInMonth(m); 
            daysInMonth(m);
            yDifference = y - year;
                if (isLeapYear())
                    daysInYear = 366;
                else 
                    daysInYear = 365;
            yProduct = yDifference * daysInYear;
                
                if (month <= m) { 
                    daysInMonth(month);
                   //dayInMonth1 = Date.daysInMonth(month); 
                   //dayInMonth2 = Date.daysInMonth(m);
                   daysInMonth(m);
                   mDifference = m - month;
                   mProduct = mDifference * m;//dayInMonth2;
                   yDifference = (y - year);
                }
                
                else {
                    daysInMonth(month);
                   //dayInMonth1 = Date.daysInMonth(month); 
                   //dayInMonth2 = Date.daysInMonth(m); 
                   daysInMonth(m);
                   mDifference = (12 - month) + (m);
                   mProduct = mDifference * m;//dayInMonth2;
                   yDifference = (y - year) - 1;
                }
                if (day <= d){
                    daysInMonth(month);
                    daysInMonth(m);
                    //dayInMonth1 = Date.daysInMonth(month); 
                    //dayInMonth2 = Date.daysInMonth(m);
                    dDifference = m - month;//dayInMonth2 - dayInMonth1;
                }
                else
                    dDifference = 0;
         
                return mProduct + yProduct + dDifference;
            }

       else {
             
             int tempmonth=m;
             int tempm=month;
             int tempyear=y;
             int tempy=year;
             int tempday=d;
             int tempd=day;
             
         if (tempmonth <= tempm) {
                mDifference = tempm - tempmonth;
                mProduct = mDifference * 30;
                yDifference = (tempy - tempyear);
            }
            else {                
                mDifference = (12 - tempmonth) + (tempm);
                mProduct = mDifference * 30;
                yDifference = (tempy - tempyear) - 1;
             }
              yProduct = yDifference * 365;
             if (tempday <= tempd) {
                 dDifference = tempd - tempday;
             }
             else {
                dDifference = 0;
            }
           
             return (mProduct + yProduct + dDifference)* -1;
            
         }
        }
        
     /**
      * Method isLeapYear created to determine whether
      * the given year is a leap year or not.
      * */    
         
     public boolean isLeapYear()   { 
        if (year % 4 != 0) {
            if ((year % 100 == 0) && (year % 400 != 0))
                return false;
        }
        
        else {
            return true;
     }
     
            return true;
 }
 
 /**
  * Method daysInMonth
  * 
  * @param  month
  * @return number value of days per month; 
  *         29 for february if isLeapYear is true, 
  *         else 28 will be returned for february
  */
 
    public int daysInMonth(int month) {
        switch (month) {
            case 1: return 31;
            case 2: 
            if (isLeapYear())
                return 29;
            else 
                return 28;
            case 3: return 31;
            case 4: return 30;
            case 5: return 31;
            case 6: return 30;
            case 7: return 31;
            case 8: return 31;
            case 9: return 30;
            case 10: return 31;
            case 11: return 30;
            case 12: return 30;
            default: return 0;
        }
    }
            
   
    //public int estimatedDaysUntil(
    
    /** 
     * Method toString
     * 
     * @param   none
     * @return  either String Invalid or String Valid
     */    
    public String toString() {
       if (day == 0) {
           String invalid = "Invalid Date";
           return invalid;
       }
       else {
       switch (month) {
           case 1:
                return "January " + day + "," + " " + year;
           case 2:
                return "February " + day + "," + " " + year;
           case 3:
                return "March " + day + "," + " " + year;
           case 4:
                return "April " + day + "," + " " + year;
           case 5:
                return "May " + day + "," + " " + year;
           case 6:
                return "June " + day + "," + " " + year;
           case 7:
                return "July " + day + "," + " " + year;
           case 8:
                return "August " + day + "," + " " + year;
           case 9:
                return "September " + day + "," + " " + year;
           case 10:
                return "October " + day + "," + " " + year;
           case 11:
                return "November " + day + "," + " " + year;
           case 12:
                return "December " + day + "," + " " + year;
                
           default: return "";
            }

}}}