
/**
 * testDate tests the class Date.  The user can input dates,
 * change the dates, and see how many days it is until a certain date
 * occurs.
 * 
 * @author Joe Moeller 
 * @version 2/20/06
 */
import java.util.*;
import java.lang.*;
public class testDate {
    public static void main(String[] args) {
                
        Scanner stdin = new Scanner(System.in);
        //prompt for date1 input
        System.out.println("Input the first date in the form of (mm/dd/yyyy): ");
        String firstDate = stdin.nextLine();
        
        //set the month for date 1
        firstDate = firstDate.trim();
        int d1 = firstDate.indexOf("/");
        String month1 = firstDate.substring(0, d1);
        month1 = month1.trim();
        int newMonth1 = Integer.parseInt(month1);
        
        //set the day for date 1
        firstDate = firstDate.trim();
        d1 = firstDate.indexOf("/");
        String day1 = firstDate.substring(0, d1);
        day1 = day1.trim();
        int newDay1 = Integer.parseInt(day1);
        
        //set the year 
        firstDate = firstDate.trim();
        d1 = firstDate.indexOf("/");
        String year1 = firstDate.substring(0, d1);
        year1 = year1.trim();
        int newYear1 = Integer.parseInt(year1);
        
        
        Date date1 = new Date(newYear1, newMonth1, newDay1);
        
        //prompt for date 2
        System.out.println("Input the second date: ");
        String secondDate = stdin.nextLine();
        
        //set the month
        secondDate = secondDate.trim();
        int d2 = secondDate.indexOf("/");
        String month2 = secondDate.substring(0, d2);
        month2 = month2.trim();
        int newMonth2 = Integer.parseInt(month2);
        
        //set the day
        secondDate = secondDate.trim();
        d2 = secondDate.indexOf("/");
        String day2 = secondDate.substring(0, d2);
        day2 = day2.trim();
        int newDay2 = Integer.parseInt(day2);
        
        //set the year
        secondDate = secondDate.trim();
        d2 = secondDate.indexOf("/");
        String year2 = secondDate.substring(0, d2);
        year2 = year2.trim();
        int newYear2 = Integer.parseInt(year2);
        
        Date date2 = new Date (newYear2, newMonth2, newDay2);
        
        System.out.println("The first date you entered is: " + date1.toString());
        System.out.println("The second date you entered is: " + date2.toString());
        System.out.println();
        System.out.println("Is date 1 a leap year?" + date1.isLeapYear());
        System.out.println("Is date 2 a leap year?" + date2.isLeapYear());
        System.out.println();
        System.out.println("The exact number of days from date 1 to date 2 is: " + date1.actualDaysUntil(newYear2, newMonth2, newDay2));
    }
    
}
