
/**
 * This program manipulates dates in american format.
 * 
 * @author Greg Petersen
 * @version 2/20/2006
 */
public class Date
{
      // variables
    /** the day of the year */
    int day;
    /** the month of the year*/
    int month;
    /** the year */
    int year;
    
      // constructors
      /** Constructs a date using with the calls (month, day, year) where all are ints.
     * @return a date with Date(month,day,year).
     * */
    public Date(int m, int d, int y) {
        month=m;
        year=y;
        int dIM = daysInMonth();
        if(m<1 || m>12) 
            day=0;
        else if(d<1 || d>dIM)
            day=0;
        else day=d;
    }
      // methods
    /** This converts the date to the form "month day, year" i.e. May 3, 2006
     * @return the date in the form "month day, year" i.e. May 3, 2006
     * */
    public String toString() {
        String s = null;
        if(month==1) s="January";
        else if (month==2) s = "February";
        else if (month==3) s = "March";
        else if (month==4) s = "April";
        else if (month==5) s = "May";
        else if (month==6) s = "June";
        else if (month==7) s = "July";
        else if (month==8) s = "August";
        else if (month==9) s = "September";
        else if (month==10) s = "October";
        else if (month==11) s = "November";
        else s = "December";
        if(day==0) 
            s = ("Invalid Date");
        else
            s = (s + " " + day + ", " + year);
        return s;
    }
    /** Checks to see if the year is a leap year.
     * @return true if the year is a leap year false if not.
     * */
    public boolean isLeapYear() {
        int div4 = year % 4;
        int div100 = year % 100;
        int div400 = year % 400;
        if(div4 == 0 && (div100!=0 || div400==0))
            return true;
        else
            return false;
    }
    
    /** Finds the exact number of days in each month for a specific year.
     * @return the number of days in a month in int form.
     * */
    public int daysInMonth() {
        int temp;
        switch(month) {
            case 1 : temp = 31; break;
            case 2 : if(isLeapYear()==true) temp = 29; else temp = 28; break;
            case 3 : temp = 31; break;
            case 4 : temp = 30; break;
            case 5 : temp = 31; break;
            case 6 : temp= 30; break;
            case 7 : temp =31; break;
            case 8 : temp =31; break;
            case 9 : temp= 30; break;
            case 10 : temp= 31; break;
            case 11 : temp =30; break;
            case 12 : temp =31; break;
            default: temp = 0;
        }
        return temp;
    }
    /** Changes the date using the calls changeDate(month,day,year).
     * @return true and a new date if date valid, if not 0 and false.  
     * */
    public boolean changeDate(int m, int d, int y) {
        int tempMonth = month, temp;
        month = m;
        int dIM = daysInMonth();
        if(m<1 || m>12) 
            temp=0;
        else if(d<1 || d>dIM)
            temp=0;
        else temp=d;
        if(temp!=0) {
            day = d;
            month = m;
            year = y;
            return true;
        } else {
            month = tempMonth;
            return false;
        }
    }
    /** gets the day
     * @return the day in date
     * */
    public int getDay() {
        return day;
    }
    /** gets the month
     * @return the month in date
     * */
    public int getMonth() {
        return month;
    }
    /** gets the year
     * @return the year in date
     * */
    public int getYear() {
        return year;
    }
    /** Estimates the number of days between two dates by assuming each month has 30
     * days and each year has 365 days.
     * @return an approximate number of days between each date.
     * */
    public int estimatedDaysUntil(Date d) {
        int total=0;
        if(day==0 || d.getDay()==0) {
            total=0;
        } else {
        int diffDay = d.getDay() - day;
        int diffMonth = (d.getMonth() - month)*30;
        int diffYear = (d.getYear() - year)*365;
        }
        return total;
    }
    
    /** gives the actual amount of days between two dates.  This factors in leap years
     * and the different number of days in the month.
     * @return the actual number of days between two dates
     * */
    public int actualDaysUntil(Date d) {
        int diffDay = d.getDay() - day;
        int diffMonth = 0;
        int diffYear = 0;
        int tempYear = year;
        int tempMonth = month;
        int i = 0;
        int total=0;
        
        if(day==0 || d.getDay()==0) total =0;
        else {
            for(i=month;i<d.getMonth();i++) {
                month=i;
                diffMonth += daysInMonth();
            }
            for(i=d.getMonth();i<tempMonth;i++) {
                month=i;
                diffMonth =diffMonth- daysInMonth();
            }
            for(i=year;i<d.getYear();i++) {
                year = i;
                if(isLeapYear()==true) diffYear += 366;
                else diffYear += 365;
            }
            for(i=d.getYear();i<tempYear;i++) {
                year = i;
                if(isLeapYear()==true) diffYear =diffYear- 366;
                else diffYear =diffYear- 365;
            }
            year=tempYear;
            month=tempMonth;
            total = diffDay + diffMonth + diffYear;
        }
        return total;
    }
}
