
/**
 * Write a description of class DateTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;

public class DateTest
{
	public static void main() {
	
	Scanner stdin = new Scanner(System.in);
	
	// get dates
	System.out.println("Please input the first date:");
	System.out.print("     Day:   ");
	int day1 = stdin.nextInt();
	System.out.print("     Month: ");
	int month1 = stdin.nextInt();
	System.out.print("     Year:  ");
	int year1 = stdin.nextInt();
	System.out.println("Please input the second date:");
	System.out.print("     Day:   ");
	int day2 = stdin.nextInt();
	System.out.print("     Month: ");
	int month2 = stdin.nextInt();
	System.out.print("     Year:  ");
	int year2 = stdin.nextInt();
	
	// construct dates
	Date date1 = new Date(month1,day1,year1);
	Date date2 = new Date(month2,day2,year2);
	
	// print out information about dates using statements.
	System.out.println("\n" + date1.toString() + "               " +  date2.toString());
	System.out.println("is Leap Year: " + date1.isLeapYear() + "        is Leap Year?: " + date2.isLeapYear());
	System.out.println("Days in month: " + date1.daysInMonth() + "         Days in month: " + date2.daysInMonth());
	System.out.println("\nEstimated days between dates: " + date1.estimatedDaysUntil(date2));
	System.out.println("Exact days between dates:     " + date1.actualDaysUntil(date2));
	
	// change date1 to date2 and find days between
	System.out.println("now change date 1 to date 2 and find days between");
	date1.changeDate(month2,day2,year2);
	System.out.println("exact days between dates: " + date1.actualDaysUntil(date2));
	}
}
