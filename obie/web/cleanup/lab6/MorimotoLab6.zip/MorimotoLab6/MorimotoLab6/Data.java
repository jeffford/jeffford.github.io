/**
 * Class date mainly has two functions; 
 * one is determined whther the input is leap year; 
 * another one is estimating and calculating the diffrence of day in two input 
 * 
 * @author Hiroki Morimoto
 * @version 2/21/2006
 */

public class Data{

    //instnace variable
    private int year;
    private int manth;
    private int day;
    
    /**
     * default constructer--that initialize the instnace variables
     */ 
    public Data(){
        year = 0;
        manth = 0;
        day = 0;
    }
    
    /**
     * mutator--to be used to change the year of the dete
     */ 
    public void setYear(int x){
        year = x;
    }
    
     /**
     * mutator--to be used to change the month of the dete
     */ 
    public void setManth(int x){
        manth = x;
    }
    
     /**
     * mutator--to be used to change the day of the dete
     */ 
    public void setDay(int x){
        day = x;
    }
    
     /**
     * accessor--to be used to acess the year and retrun it
     * 
     * @return instance variable year
     */ 
    public int getYear(){
        return year;
    }
    
     /**
     * accessor--to be used to acess the month and retrun it
     * 
     * @return instance variable month
     */     
    public int getManth(){
        return manth;
    }
    
     /**
     * accessor--to be used to acess the day and retrun it
     * 
     * @return instance variable day
     */  
    public int getDay(){
        return day;
    }
    
    /**
     * specific constructer--that renew the instance variables with specific value form input. 
     *                       If the values are not in proper range (also using dayIMonth methods), set the month or day to 0
     * 
     * 
     * @param a  formal parameter for year
     * @param b  formal parameter for month
     * @param c  formal parameter for day
     * 
     */
     public Data(int a, int b, int c){
        setYear(a);
        
        if(b > 0 && b <= 12){
            setManth(b);
        }
        else{
            setManth(0);
        }
        
        int x = this.daysInMonth();
        if(c > 0 && c <= x){
            setDay(c);
        }
        else{
            setDay(0);
        }
    }
    
    /**
     * instance method--that change the date using the input values as formal parameter and retrun true. 
     * Also determined if the input all the date are valid. 
     * When these are not proper, set the value to 0 and retrun false
     * 
     * @param a  formal parameter for year
     * @param b  formal parameter for month
     * @param c  formal parameter for day
     * 
     * @return whether the input value is valid or not
     */ 
      
    public boolean changeDate(int a, int b, int c){
        
        boolean checkManth = false;
        boolean checkDay = false;
        
        setYear(a);
        
        if(b > 0 && b <= 12){
            setManth(b);
            checkManth = true;
        }
        else
            setManth(0);
   
   
        int x = this.daysInMonth();
        if(c > 0 && c <= x){
            setDay(c);
            checkDay = true;
        }
        else{
            setDay(0);
        }
        
        if(checkDay == true && checkManth == true)
            return true;
        else
            return false;
    }
    
    /**
     * 
     * instance method--that change the date to string form (month day, year).
     * Also it represent the month literally 
     * if the month or day is setted to 0, return the string "Invalid Date"
     * 
     * @return the srting form of date
     */ 
    
    public String toString(){
        
        String st = "";
        switch(manth){
            case 1: st = "January "; break;
            case 2: st = "February "; break;
            case 3: st = "March "; break;
            case 4: st = "April "; break;
            case 5: st = "May "; break;
            case 6: st = "June "; break;
            case 7: st = "July "; break;
            case 8: st = "August "; break;
            case 9: st = "September "; break;
            case 10: st = "October "; break;
            case 11: st = "November "; break;
            case 12: st = "December "; break;
            default: st = "Invalid Date"; break;
            
        }
            
        if(day != 0 && manth != 0){
            st = st + day + ", " + year;
        }
        else{
            st = "Invlid Date";
    }
         return st;
    }
    
    /**
     * 
     * instance method--that determined if the inputtd year is leap year or not
     * 
     * @return The input year is leap year or not.
     */
     
    public boolean isLeapYear(){
        boolean isDivisibleBy4 = (year % 4) == 0;
        boolean isDivisibleBy100 = (year % 100) == 0;
        boolean isDivisibleBy400 = (year % 400) == 0;
        
        boolean leapyear = isDivisibleBy4 && ((! isDivisibleBy100) || isDivisibleBy400);
        return leapyear;
    }
    
    /** instance method--that calculate the actual number of days in the month accroding to month and year
     * 
     * @return the proper number of days in month
     */ 
    
    public int daysInMonth(){
        int ans;
        switch(manth){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                ans = 31;
                break;
            case 4: case 6: case 9: case 11:
                ans = 30;
                break;
            case 2:
                if(isLeapYear())
                    ans = 29;
                else
                    ans = 28;
                break;
            default:
                ans = 0;
            }
            
            return ans;
        }
            
    /**
     * 
     * instance method--that estimate the diffrence of two date
     * think the year is 365 days and month is 30 days constant
     * 
     * @param another date in Data form
     * @return the number of days in diffrence of two date
     */ 
    
    
    public int estimatedDaysUntil(Data that){
        
        int dayD = 0;
        int manthD = 0;
        int yearD = 0;
        
        dayD = 1 * (that.getDay() - day);
        manthD = 30 * (that.getManth() - manth);
        yearD = 365 * (that.getYear() - year);
        
        return dayD + manthD + yearD;
    }
    
    /**
     * instance method--that calculate actural number of days until another date
     * Accoring to date, deal with days in leap year (that has 366 days) 
     * and days in month (that has 28, 29, 30 or 31)
     * 
     * @param another date in Data form
     * @return the number of days in diffrence of two date
     */ 
    
    public int actualDaysUtil(Data that){
        
        Data Ndata = new Data(getYear(), getManth(), getDay());
        Data Mdata = new Data(that.getYear(), that.getManth(), that.getDay());
        int dayD = 0;
        int manthD = 0;
        int yearD = 0;
        
        //calculate number of days from ealier year to later year
        if(Ndata.getYear() > Mdata.getYear()){
            int temp = Ndata.getYear();
            Ndata.setYear(Mdata.getYear());
            Mdata.setYear(temp);
        }
            
        while(Ndata.getYear() < Mdata.getYear()){
            if(Ndata.isLeapYear()) yearD = yearD + 366;
            else  yearD = yearD + 365;
            Ndata.setYear(1 + Ndata.getYear());
        }

        if(year > that.getYear()) yearD = -yearD; 
           
        //calculate number of days from month month to later month
        if(Ndata.getManth() > Mdata.getManth()){
            int temp = Ndata.getManth();
            Ndata.setManth(Mdata.getManth());
            Mdata.setManth(temp);
        }
            
        while(Ndata.getManth() < Mdata.getManth()){
            int i = Ndata.daysInMonth();
            manthD = manthD + i;
            Ndata.setManth(1 + Ndata.getManth());
        }

        if(manth > that.getManth()) manthD = -manthD; 
        
        dayD = Mdata.getDay() - Ndata.getDay();
        
        
        System.out.println("Y : " + yearD + "\nM : " + manthD + "\nD : " + dayD);
        return dayD + manthD + yearD;
    }
        
        
    
}