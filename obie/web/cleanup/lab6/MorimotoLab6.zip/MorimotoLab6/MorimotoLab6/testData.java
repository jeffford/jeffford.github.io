import java.util.*;
import java.io.*;

public class testData{

   public static void main(String[] args){
       
       Scanner stdin = new Scanner(System.in);
       
       System.out.print("Enter the year : ");
       int y = stdin.nextInt();
       System.out.print("Enter the month : ");
       int m = stdin.nextInt();
       System.out.print("Enter the day : ");
       int d = stdin.nextInt();
       
       Data test = new Data(y,m,d);
       String ans = test.toString();
       System.out.println(ans);
 
       boolean n = test.isLeapYear();
       if(n)
            System.out.println("is leap year");
       else
            System.out.println("is not leap year");
            
       System.out.println("\nNext, we will estimate and then determined the acutal number of days until another date");     
       
       System.out.println("\nFirst, do you want to change date? Y or N");
       
       String s = "";
       boolean yn = true;
       do{
            System.out.print("Y or N :");
            s = stdin.nextLine();
            s = s.toLowerCase();
            int len = s.length();
            if(len == 1)
                if(s.charAt(0) == 'y' || s.charAt(0) == 'n')
                    yn = false;
                else 
                   System.out.println("Error! Again!");
            else 
                System.out.println("Error! Again");
         }while(yn);
       
       boolean tf = true;
       if(s.charAt(0) == 'y'){
           do{
                System.out.print("Change the year : ");
                y = stdin.nextInt();
                System.out.print("Change the month : ");
                m = stdin.nextInt();
                System.out.print("Chnage the day : ");
                d = stdin.nextInt(); 

                if(test.changeDate(y, m, d)) tf = false;
                else System.out.print("Invalid number! Again");
            }while(tf);
       }
 
 
       ans = test.toString();
 
       System.out.println("\nThen enter next date" );
       
       System.out.print("Enter the year : ");
       y = stdin.nextInt();
       System.out.print("Enter the month : ");
       m = stdin.nextInt();
       System.out.print("Enter the day : ");
       d = stdin.nextInt();
       
       Data that = new Data(y,m,d);
       String ansThat = that.toString();
       System.out.println(ansThat);
 
       boolean k = that.isLeapYear();
       if(k)
            System.out.println("is leap year");
       else
            System.out.println("is not leap year");
            
       int estimateDate = test.estimatedDaysUntil(that);
       int actualDate = test.actualDaysUtil(that);
       
       System.out.println();
       System.out.println("The results are");
       System.out.println("In our estimate, there are  "+ estimateDate + " days differece");
       System.out.println("from " + ans + " to " + ansThat);
       
       System.out.println("In our calucuration, there are actual "+ actualDate + " days differece");
       System.out.println("from " + ans + " to " + ansThat);
   }
}