import java.util.Random;

public class DiceTester {
   public static void rollTest(Die a, Die b) {
      for (int i=0; i < 10; i ++) {
         a.roll();
         b.roll();
         System.out.print( a + "  " + b);
         if (a.equals(b)) 
            	System.out.print(" ** EQUAL **");
         System.out.println("");
      }
   }

   public static void main(String[] args) {
      Random seeder = new Random();

      Die a = new Die(seeder.nextLong());
      Die b = new Die(seeder.nextLong());

      rollTest(a, b);

      b = (Die)a.clone();
      System.out.println("\n\nCloned dice:\n------------");
      System.out.print( a + "  " + b);
      if (a.equals(b)) 
         		System.out.print(" ** EQUAL **");
      System.out.println("");

      System.out.println("\n\nCloned dice roll test:");
      System.out.println("----------------------");
      rollTest(a, b);

   }
}//DieTester.java
