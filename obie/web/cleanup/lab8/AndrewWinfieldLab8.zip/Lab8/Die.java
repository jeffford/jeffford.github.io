import java.awt.Graphics;
import java.util.Random;

public class Die{
    private static final int NUM_FACES = 6;
    
    private int value;
    private Random generator;
    
    public Die(){
        generator = new Random();
        value = roll();
    }
    
    public Die(long seed){
        generator = new Random(seed);
        value = roll();
    }
    
    public int roll(){
        value = generator.nextInt(NUM_FACES) + 1;
        return value;
    }
    
    public int getValue(){
        return value;
    }
    
    private void setValue(int x){
        value = x;
    }
    
    public String toString(){
        String output;
        if(value == 6){
            output = "Die [ 6 ]";
        }else if(value == 5){
            output = "Die [ 5 ]";
        }else if(value == 4){
            output = "Die [ 4 ]";
        }else if(value == 3){
            output = "Die [ 3 ]";
        }else if(value == 2){
            output = "Die [ 2 ]";
        }else if(value == 1){
            output = "Die [ 1 ]";
        }else{
            output = "";
        }
        
        return output;
    }
    
    public Object clone(){
           int temp = getValue();
           return new Die(temp);
    }
    
    public boolean equals(Object v){
        if(v instanceof Die){
               Die temp = (Die) v;
               int rollOne = getValue();
               int rollTwo = temp.getValue();
               return (rollOne == rollTwo);
        }else{
            return false;
        }
    }
}
