public class Problem01 {

   public static void f() {
   }

   public static void main(String[] args) {

      int i = 10;
      int j = 20;

      f();

      System.out.println( "main: i = " + i );
      System.out.println( "main: j = " + j );
   }
}

