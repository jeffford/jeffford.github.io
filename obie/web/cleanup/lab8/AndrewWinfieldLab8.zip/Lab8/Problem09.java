public class Problem09 {

   static int counter = 0;

   public static void f() {
      ++counter;
   }

   public static void g() {
      int counter = 10;
      f();
      f();
   }

   public static void h() {
      f();
      g();
      f();
   }

   public static void main(String[] args) {

      f();
      System.out.println( counter );

      counter = 0;

      g();

      System.out.println( counter );

      counter = 0;

      h();

      System.out.println( counter );
   }
}
