
import java.awt.Graphics;
import java.util.Random;
public class Die {
   private static final int NUM_FACES = 6;
   private int value;
   private Random generator;
   public Die() {
      generator = new Random();
      roll();
   }
   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }
   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }
   
   public int getValue() {
      return value;
   }
   
   private void setValue(int x) {
      value = x;
   }
   public String toString() {
       return "" + "Die [ " + getValue() + " ]"; 
   }
   
   public Object clone() {
       Die temp = new Die(); 
       temp.setValue (getValue() );
       return temp; 
   }
   
   public boolean equals(Die v) {
       if (getValue()==v.getValue() )
            return true;
       else
            return false; 
       
   }
}
