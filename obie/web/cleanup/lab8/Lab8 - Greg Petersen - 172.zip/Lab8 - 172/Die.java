import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   public Die() {
      generator = new Random();
      roll();
   }

   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   public int getValue() {
      return value;
   }

   private void setValue(int x) {
      value = x;
   }

   public String toString() {
       String temp;
       if(value==6) temp = "Die [ 6 ]";
       else if(value==5) temp = "5";
       else if(value==4) temp = "4";
       else if(value==3) temp = "3";
       else if(value==2) temp = "2";
       else temp = "1";
       return temp;
   }

   public Object clone() {
       Die temp = new Die();
       temp.generator = new Random(43);
       generator = new Random(43);
       temp.value = value;
       return temp;
   }

   public boolean equals(Die a) {
       boolean temp;
       if(a.getValue()==value) temp = true;
       else temp=false;
       return temp;
   }
}
