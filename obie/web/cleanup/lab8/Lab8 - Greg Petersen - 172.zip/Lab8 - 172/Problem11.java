public class Problem11 {

   public static void f(int a) {

      System.out.println( "int a: " + a );
   }

   public static void f(char a) {

      System.out.println( "char a: " + a );
   }

   public static void main(String[] args) {

      int i = 1;
      char c = 'c';

      f(i);
      f(c);
   }
}//11.java
