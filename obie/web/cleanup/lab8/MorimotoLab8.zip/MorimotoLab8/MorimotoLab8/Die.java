import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   public Die() {
      generator = new Random();
      roll();
   }

   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   public int getValue() {
      return value;
   }

   private void setValue(int x) {
      value = x;
   }

   public String toString() {
       String s = "Die[ " + value + " ]";
       return s;
   }
   
      public boolean equals(Object v) {
          
          if(v instanceof Die){
              int x1 = value;
              
              Die tmp = (Die)v;
              int x2 = tmp.getValue();
          
              return x2 == x1;
          }
          
          else{
            return false;
          }
   }
   
   public Object clone() {
       int val = getValue();
       
       Die temp = new Die();
       temp.setValue(val);
       
       return temp;
   }


}