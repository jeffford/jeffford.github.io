import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   public Die() {
      generator = new Random();
      roll();
   }

   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   public int getValue() {
      return value;
   }

   private void setValue(int x) {
      value = x;
   }

   public String toString() {
       String number;
       value = getValue();
       if (value == 6) 
        number = "Die [" + value + "]";
       else if (value == 5) 
        number = "Die [" + value + "]";
       else if (value == 4) 
        number = "Die [" + value + "]";
       else if (value == 3) 
        number = "Die [" + value + "]";
       else if (value == 2) 
        number = "Die [" + value + "]";
       else if (value == 1) 
        number = "Die [" + value + "]";
       else
        number = "";
       
       return number;    
   }

   public Object clone() {
    int rollit = getValue();    
    return new Die (rollit);
   }

   public boolean equals(Object v) {
    if (v instanceof Die) {
        Die p = (Die) v;
        int r1 = (int) getValue();
        int r2 = (int) p.getValue();
        return (r1 == r2);
    }
    else return false;
   }
}

