public class Problem10 {

   public int i = 0;

   public void f(int i) {
      System.out.println( "i: " + i );
      i = 4;
      System.out.println( "i: " + i );
      i = this.i;
      System.out.println( "i: " + i );
   }

   public static void main(String[] args) {

      Problem10 testObject = new Problem10();

      int i = 1;

      System.out.println( "i: " + i );

      testObject.f(i);

      System.out.println( "i: " + i );
      System.out.println( "i: " + testObject.i );
   }
}
