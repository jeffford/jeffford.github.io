import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   public Die() {
      generator = new Random();
      roll();
   }

   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   public int getValue() {
      return value;
   }

   private void setValue(int x) {
      value = x;
   }

   public String toString() {
       return "Die["+ value +"]";
   }

   public Object clone() {
       Die cl = new Die();
       cl.generator = generator;
       cl.value = value;
       return cl;
   }

   public boolean equals(Die v) {
       if(v.value==value)
            return true;
       else
            return false;
   }
}
