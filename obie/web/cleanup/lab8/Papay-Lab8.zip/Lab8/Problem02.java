public class Problem02 {

   public static void f(int i, int j) {

      System.out.println( "f: i = " + i );
      System.out.println( "f: j = " + j );
   }

   public static void main(String[] args) {
      int i = 10;
      int j = 20;

      f(i, j);

      System.out.println( "main: i = " + i );
      System.out.println( "main: j = " + j );
   }
}//02.java
