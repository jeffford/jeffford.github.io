public class Problem04 {

   public static void f(int i, int j) {

      int temp;

      temp = i;
      i = j;
      j = temp;

      System.out.println( "f: i = " + i );
      System.out.println( "f: j = " + j );
   }

   public static void main(String[] args) {

      int a = 10;
      int b = 20;

      f(a, b);
      f(b, a);

      System.out.println( "main: a = " + a );
      System.out.println( "main: b = " + b );
   }
}//04.java
