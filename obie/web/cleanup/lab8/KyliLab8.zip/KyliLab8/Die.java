/**
 * Exercise 2 from Lab8.
 * 
 * @author Lab Specifications
 * @version 3/13/2006
 */
import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   /**
     * Default Constructor for objects of class Die
     */
   public Die() {
      generator = new Random();
      roll();
   }

   /**
     * Specific Constructor for objects of class blah
     */
   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   /**
     * roll() method
     * 
     */
   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   /**
     * getValue() mutator method
     * 
     */
   public int getValue() {
      return value;
   }

   /**
     * setValue() accessor method
     * 
     * @param  x   an integer
     */
   private void setValue(int x) {
      value = x;
   }

   /**
     * toString() method
     * 
     */
   public String toString() {
       return "Die[ " + value + " ]";
   }

   /**
     * clone method
     * 
     */
   public Object clone() {
   }

   /**
     * equals() method
     * 
     * @param  v   a die object
     */
   public boolean equals(Object v) {
       if (value == v.getValue()) 
           return true;
       else
           return false;
   }
}
