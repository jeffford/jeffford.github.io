public class Problem08 {

   static int a = 0;
   static int b = 1;

   public static void f() {

      System.out.println( "a: " + a );
      System.out.println( "b: " + b );

      a = 10;
      b = 20;

   }

   public static void main(String[] args) {

      int a = 2;
      int b = 3;

      System.out.println( "a: " + a );
      System.out.println( "b: " + b );

      f();

      System.out.println( "a: " + a );
      System.out.println( "b: " + b );

   }
}//08.java
