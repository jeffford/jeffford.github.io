
import java.awt.Graphics;
import java.util.Random;

public class Die {
   private static final int NUM_FACES = 6;

   private int value;
   private Random generator;

   public Die() {
      generator = new Random();
      roll();
   }

   public Die(long seed) {
      generator = new Random(seed);
      roll();
   }

   public int roll() {
      value = generator.nextInt(NUM_FACES) + 1;
      return value;
   }

   public int getValue() {
      return value;
   }

   private void setValue(int x) {
      value = x;
   }

   public String toString() {
       switch (value) {
           case 1: 
                String dieValue = "Die[1]";
                return dieValue;
           case 2:
                dieValue = "Die[2]";
                return dieValue;
           case 3:
                dieValue = "Die[3]";
                return dieValue;
           case 4:
                dieValue = "Die[4]";
                return dieValue;
           case 5:
                dieValue = "Die[5]";
                return dieValue;
           case 6:
                dieValue = "Die[6]";
                return dieValue;
           default: 
                dieValue = "No Value!";
                return dieValue;
            }
           
       
   }

   public Object clone() {
       Random newGen = new Random();
       newGen = generator;       
       return newGen;
   }

   public boolean equals(int v) {
       if (v == value)
            return true;
       
       else 
            return false;
        
   }
}

