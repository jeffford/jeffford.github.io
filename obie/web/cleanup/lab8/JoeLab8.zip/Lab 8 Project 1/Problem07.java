import java.awt.Point;

public class Problem07 {

   public static void f(Point i, Point j) {

      i.move(3,3);
      j = i;
      j.move(4,4);

      System.out.println( "f: i = ( " + i.x + ", " + i.y + " )" );
      System.out.println( "f: j = ( " + j.x + ", " + j.y + " )" );
   }

   public static void main(String[] args) {

      Point a = new Point(1,1);
      Point b = new Point(2,2);

      System.out.println( "main: a = ( " + a.x + ", " + a.y + " )" );
      System.out.println( "main: b = ( " + b.x + ", " + b.y + " )" );

      f(a, b);

      System.out.println( "main: a = ( " + a.x + ", " + a.y + " )" );
      System.out.println( "main: b = ( " + b.x + ", " + b.y + " )" );

      f(b, a);

      System.out.println( "main: a = ( " + a.x + ", " + a.y + " )" );
      System.out.println( "main: b = ( " + b.x + ", " + b.y + " )" );
   }
}//07.java
