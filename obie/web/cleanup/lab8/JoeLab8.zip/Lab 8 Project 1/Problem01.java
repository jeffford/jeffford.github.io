
/**
 * Write a description of class Problem01 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Problem01 {

   /**
    * method f()
    */
   
   public static void f() {
   }
   /**
    * method main
    */
   
   public static void main(String[] args) {

      int i = 10;
      int j = 20;

      f();

      System.out.println( "main: i = " + i );
      System.out.println( "main: j = " + j );
   }
}//01.java.

