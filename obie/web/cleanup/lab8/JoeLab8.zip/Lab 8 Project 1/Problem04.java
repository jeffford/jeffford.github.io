
/**
 * Write a description of class Problem04 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Problem04 {
    
   /**
    * method f()
    * 
    * @param int i, int j
    */
   
   public static void f(int i, int j) {

      int temp;

      temp = i;
      i = j;
      j = temp;

      System.out.println( "f: i = " + i );
      System.out.println( "f: j = " + j );
   }

   /**
    * method main
    */
   
   public static void main(String[] args) {

      int a = 10;
      int b = 20;

      f(a, b);
      f(b, a);

      System.out.println( "main: a = " + a );
      System.out.println( "main: b = " + b );
   }
}//04.java
