/**&author  Kent Vasko
 *&version  Lab7
 * March 12, 2006
 */

import java.util.*;
import java.lang.*;
import java.io.*;

public class EncodeDecode { 

        /** Varibles for the entire class*/
        static char E = 'E', D = 'D', first, second, third, fourth;
        
        static int codelength, lengthcode, firstnumber, secondnumber, thirdnumber, fourthnumber;
        
        static String code, fn, sn, tn, fthn;

    /** String EnDe
     *&param   string edfile, string that will be encoded or decoded
     *&return  string code, string that is returned to the calling program
     */
    public static String EnDe(String edfile) {
                
        edfile = edfile.trim();
        char edorde = edfile.charAt(0);
        
        if (edorde == E){
            codelength = edfile.length();
            edfile = edfile.substring(1,codelength);
            edfile = edfile.trim();
            code = Encode(edfile);
        }
        else if (edorde == D){
            codelength = edfile.length();
            edfile = edfile.substring(1,codelength);
            edfile = edfile.trim();
            code = Decode(edfile);
        }
        else
            code = "error";
       
        return code;     
    }
    
    /**String Encode
     *&param  string edfile, string that will be encoded
     *@return string edfile, string that is encoded is returned to EnDe
     */
    public static String Encode(String edfile) {
                
        /**takes the first number out*/
        first = edfile.charAt(0);
        firstnumber = first - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the second number out*/
        second = edfile.charAt(0);
        secondnumber = second - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the third number out*/
        third = edfile.charAt(0);
        thirdnumber = third - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the fourth number out*/
        fourth = edfile.charAt(0);
        fourthnumber = fourth - 48;
        
        /**first step of encoding, changing numbers*/
        firstnumber = (firstnumber + 7) % 10;
        secondnumber = (secondnumber + 7) % 10;
        thirdnumber = (thirdnumber + 7) % 10;
        fourthnumber = (fourthnumber + 7) % 10;
        
        /**second step of encoding, switching numbers*/
        tn = "" + firstnumber + "";
        fthn = "" + secondnumber + "";
        fn = "" + thirdnumber + "";
        sn = "" + fourthnumber + "";
        
        /**third step of encoding, putting numbers in string*/
        edfile = fn + sn + tn + fthn;
        
        return edfile;
    }
    
    /**String Decode
     *&param  string edfile, this string is decoded
     *&return  string edfile, this decoded string is returned to EnDe
     */
    public static String Decode(String edfile) {
        
         /**takes the first number out*/
        first = edfile.charAt(0);
        firstnumber = first - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the second number out*/
        second = edfile.charAt(0);
        secondnumber = second - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the third number out*/
        third = edfile.charAt(0);
        thirdnumber = third - 48;
        lengthcode = edfile.length();
        edfile = edfile.substring(1,lengthcode);
        
        /**takes the fourth number out*/
        fourth = edfile.charAt(0);
        fourthnumber = fourth - 48;
        
        /**first step of decoding, changing numbers*/
        if (firstnumber >= 7)
            firstnumber = firstnumber - 7;
        else 
            firstnumber = firstnumber + 3;
            
        if (secondnumber >= 7)
            secondnumber = secondnumber - 7;
        else 
            secondnumber = secondnumber + 3;
            
        if (thirdnumber >= 7)
            thirdnumber = thirdnumber - 7;
        else 
            thirdnumber = thirdnumber + 3;
            
        if (fourthnumber >= 7)
            fourthnumber = fourthnumber - 7;
        else 
            fourthnumber = fourthnumber + 3;
        
        /**second step of decoding, switching numbers*/
        tn = "" + firstnumber + "";
        fthn = "" + secondnumber + "";
        fn = "" + thirdnumber + "";
        sn = "" + fourthnumber + "";
        
        /**third step of encoding, putting numbers in string*/
        edfile = fn + sn + tn + fthn;
        
        return edfile; 
    }

}

