//Kent Vasko
//Lab 7
//March 12, 2006

import java.io.*;
import java.util.*;

public class TestED {

    public static void main (String[] args) throws IOException {
        
        char E = 'E', D = 'D', firstletter;
        
        double en = 0.0, de = 0.0, er = 0.0, total = 0.0;
     
        //sets up standard input
        Scanner stdin = new Scanner(System.in);        
        
        //gets the file name from the user
        System.out.println("This program will encode or decode your file and");
        System.out.println("will output your file as a new file.");
        System.out.println("Enter the name of your file: ");
        String filename = stdin.nextLine();
        File file = new File(filename);
        System.out.println("Enter a name for the file that will be output: ");
        String outputFileName = stdin.nextLine();        
        
        //sets up the file input stream
        Scanner fileIn = new Scanner(file);  
        
        //sets up the file output stream
        PrintWriter fileOut = new PrintWriter(outputFileName);
        
        while (fileIn.hasNext()) {
            String edfile = fileIn.nextLine();
            //tells whether or not the file was encoded or decoded
            edfile = edfile.trim();
            firstletter = edfile.charAt(0);
            
            if (firstletter == E) {
                String code = EncodeDecode.EnDe(edfile);
                code = "" + edfile + " ENCODED: " + code + "";
                fileOut.println(code);
                en++;
                total++;
            }
            
            else if (firstletter == D) {
                String code = EncodeDecode.EnDe(edfile);
                code = "" + edfile + " DECODED: " + code + "";
                fileOut.println(code);
                de++;
                total++;
            }
            
            else {
                String code = "Error: Not a number that could be encoded or decoded.";
                fileOut.println(code);
                er++;
                total++;
            }
        }
        
        fileOut.close();
        
        //the summary that is output to the terminal
        System.out.println("The total number of requests is " + total + ".");
        System.out.println("The number of encodings is " + en + ".");
        System.out.println("The number of decodings is " + de + ".");
        System.out.println("The number of erroneous requests is " + er + ".");
        System.out.println("Encoding percentage is " + en/total + ".");
        System.out.println("Decoding percentage is " + de/total + ".");
        System.out.println("Error percentage is " + er/total + ".");
        
    }
}