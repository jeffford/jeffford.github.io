//Kent Vasko
//Lab6 TestDate
//February 23, 2006


import java.util.*;
import java.io.*;
import java.lang.String.*;

//This class was created to test the Date program
public class TestPigLatin {

    public static void main (String[] args) throws IOException {
            
            String testfile = "ToPigLatin.txt";
            File file = new File(testfile);            
            Scanner line = new Scanner(file);
            
            String eword = line.nextLine();
            int numoflines = eword.charAt(0) - 48;
            
            for (int loop = 1; numoflines >= loop; numoflines--){
                eword = line.nextLine();
                System.out.println(eword);
                PigLatin latindecochon = new PigLatin();
                String plword = latindecochon.Translate(eword);
                System.out.println(plword);
            }
    }
}