/**&author   Kent Vasko
 *&version   Lab7
 * February 27, 2006
 */

import java.io.*;

public class PigLatin {

    /**Translate method
     *@param   String eword, this string is translated from English to Pig Latin
     *&return   String plword, this string is the Pig Latin version of the English word
     */
        public String Translate(String eword) throws IOException {
        
        /**variables*/
        String plword;
        char a = 'a', A = 'A', e = 'e', E = 'E', i = 'i', I = 'I', o = 'o', O = 'O', u = 'u', U = 'U';
                
        char firstletter = eword.charAt(0);
        
        if (firstletter == a || firstletter == e || firstletter == i || firstletter == o
        || firstletter == u || firstletter == A || firstletter == E || firstletter == I 
        || firstletter == O || firstletter == U) {
            plword = "" + eword + "ay";         
            }
        else {
            eword = eword.substring(1);
            plword = "" + eword + "" + firstletter + "ay";
        }
            
        return plword;
        }
        
    }