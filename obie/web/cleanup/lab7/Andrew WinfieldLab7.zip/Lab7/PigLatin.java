
/**
Andrew Winfield
2-27-2006
lab 6 project 1
*/

public class PigLatin{
    public static String Translate(String str){
        char first = str.charAt(0);
        if(first == 'a' || first == 'e' || first == 'i' || first == 'o' || first == 'u' ||
           first == 'A' || first == 'E' || first == 'I' || first == 'O' || first == 'U'){
            str = str.concat("ay");
        }else{
            str = str.substring(1);
            String temp = str.valueOf(first);
            str = str.concat(temp);
            str = str.concat("ay");
        }
        
        return str;
    }
}
