/*
Andrew Winfield
3-12-2006
Lab7
*/

import java.util.*;
import java.lang.*;
import java.io.*;

public class EncodeDecode{ 
    static char e = 'E', d = 'D', first, second, third, fourth;
    static int codeL, lengthcode, firstN, secondN, thirdN, fourthN;
    static String code, FName, SName, TName, FourName;

    public static String encodeDec(String editF){
                
        editF = editF.trim();
        char tempchar = editF.charAt(0);
        
        if (tempchar == e){
            codeL = editF.length();
            editF = editF.substring(1, codeL);
            editF = editF.trim();
            code = Encode(editF);
        }
        else if (tempchar == d){
            codeL = editF.length();
            editF = editF.substring(1, codeL);
            editF = editF.trim();
            code = Decode(editF);
        }
        else
            code = "error";
       
        return code;     
    }
    
    public static String Encode(String editF){
                
        //takes the first number
        first = editF.charAt(0);
        firstN = first - 48;
        lengthcode = editF.length();
        editF = editF.substring(1, lengthcode);
        
        //takes the second number
        second = editF.charAt(0);
        secondN = second - 48;
        lengthcode = editF.length();
        editF = editF.substring(1, lengthcode);
        
        //takes the third number
        third = editF.charAt(0);
        thirdN = third - 48;
        lengthcode = editF.length();
        editF = editF.substring(1, lengthcode);
        
        //takes the fourth number out
        fourth = editF.charAt(0);
        fourthN = fourth - 48;
        
        //chang numbers
        firstN = (firstN + 7) % 10;
        secondN = (secondN + 7) % 10;
        thirdN = (thirdN + 7) % 10;
        fourthN = (fourthN + 7) % 10;
        
        //switch numbers
        TName = "" + firstN + "";
        FourName = "" + secondN + "";
        FName = "" + thirdN + "";
        SName = "" + fourthN + "";
        
        //put numbers in the string
        editF = FName + SName + TName + FName;
        
        return editF;
    }
    
    public static String Decode(String editF){
        
         //takes the first number
        first = editF.charAt(0);
        firstN = first - 48;
        lengthcode = editF.length();
        editF = editF.substring(1,lengthcode);
        
        //takes the second number
        second = editF.charAt(0);
        secondN = second - 48;
        lengthcode = editF.length();
        editF = editF.substring(1,lengthcode);
        
        //takes the third number
        third = editF.charAt(0);
        thirdN = third - 48;
        lengthcode = editF.length();
        editF = editF.substring(1,lengthcode);
        
        //takes the fourth number
        fourth = editF.charAt(0);
        fourthN = fourth - 48;
        
        //chang numbers
        if (firstN >= 7)
            firstN = firstN - 7;
        else 
            firstN = firstN + 3;
            
        if (secondN >= 7)
            secondN = secondN - 7;
        else 
            secondN = secondN + 3;
            
        if (thirdN >= 7)
            thirdN = thirdN - 7;
        else 
            thirdN = thirdN + 3;
            
        if (fourthN >= 7)
            fourthN = fourthN - 7;
        else 
            fourthN = fourthN + 3;
        
        //switch numbers
        TName = "" + firstN + "";
        FourName = "" + secondN + "";
        FName = "" + thirdN + "";
        SName = "" + fourthN + "";
        
        //put numbers in string
        editF = FName + SName + TName + FourName;
        
        return editF; 
    }

}


