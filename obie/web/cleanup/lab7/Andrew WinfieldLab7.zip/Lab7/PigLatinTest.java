
/**
Andrew Winfield
2-27-2006
lab 6 project 1
*/
import java.io.*;
import java.util.*;
import java.lang.*;

public class PigLatinTest{
    public static void main(String[] args) throws IOException{
        //open the file
        String name = "ToPigLatin.txt";
        File file = new File(name);
        Scanner line = new Scanner(file);
        //get the first line as a string and convert it to an integer
        String str = line.nextLine();
        int length = str.length();
        char temp = str.charAt(0);
        int num = new Character(temp);
        int x = 0;
        int cnt = num;
        int overal = 0;
        int mul = 1;
        while(cnt >= 0){
            if(x < length){
                temp = str.charAt(x);
                num = new Character(temp);
                overal = overal * mul;
                overal = overal + (num - 48);
                x++;
                mul = mul * 10;
            }else{
                cnt = -1;
            }
        }
        //use the integer to make a four loop to go through the file line by line
        for(int i = 1; i <= overal; i++){
            str = line.nextLine();
            System.out.println(str);
            PigLatin asdf = new PigLatin();
            str = asdf.Translate(str);
            System.out.println(str);
        }
    }
}
