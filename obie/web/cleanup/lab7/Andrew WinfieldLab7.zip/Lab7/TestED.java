/*
Andrew Winfield
3- 12-2006
lab7
 */

import java.io.*;
import java.util.*;

public class TestED{
    public static void main (String[] args) throws IOException{
        char e = 'E', d = 'D', firstL;
        double encode = 0, decode = 0, erron = 0, total = 0;
     
        //set up input
        Scanner asdf = new Scanner(System.in);
        
        //get file name
        System.out.println("Enter file name: ");
        String name = asdf.nextLine();
        File file = new File(name);
        System.out.println("Enter a file name for the output: ");
        String outputFN = asdf.nextLine();        
        
        Scanner fileIn = new Scanner(file);
        
        PrintWriter fileOut = new PrintWriter(outputFN);
        
        while (fileIn.hasNext()) {
            String editF = fileIn.nextLine();
            editF = editF.trim();
            firstL = editF.charAt(0);
            
            if (firstL == e) {
                String code = EncodeDecode.encodeDec(editF);
                code = "" + editF + " Encode: " + code + "";
                fileOut.println(code);
                encode++;
                total++;
            }
            
            else if (firstL == d) {
                String code = EncodeDecode.encodeDec(editF);
                code = "" + editF + " Decode: " + code + "";
                fileOut.println(code);
                decode++;
                total++;
            }
            
            else {
                fileOut.println("Error can not be decoded or encoded.");
                erron++;
                total++;
            }
        }
        
        //output summery
        System.out.println("Total number of requests: " + total);
        System.out.println("Number of encodings: " + encode);
        System.out.println("Number of decodings: " + decode);
        System.out.println("Number of erroneous requests: " + erron);
        System.out.println("Encoding percentage: " + (encode / total));
        System.out.println("Decoding percentage: " + (decode / total));
        System.out.println("Error percentage is: " + (erron / total));
        
    }
}
