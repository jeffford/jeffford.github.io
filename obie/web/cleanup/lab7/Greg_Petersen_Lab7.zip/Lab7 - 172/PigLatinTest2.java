
/**
 * Tests PigLatin Class
 * 
 * @author Greg Petersen
 * @version 3/12/06
 */

import java.io.*;
import java.util.*;

public class PigLatinTest2
{
	public static void Main() throws IOException {
	    int i;
	    String word;
	    
	    Scanner fileIn = new Scanner(new File("toPigLatin2.txt"));
	    int total = fileIn.nextInt();
	    
	    for(i=0;i<=total;i++) {
	        word = fileIn.nextLine();
	        System.out.println(word);
	        word = PigLatin.translate(word);
	        System.out.println(word);
	    }
	}
}
