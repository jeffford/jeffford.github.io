
/**
 * A program that allows the user to enter in a file of 4 digit numbers with E and D's before
 * each number which will symbolize encode and decode.
 * 
 * @author Greg Petersen
 * @version 3/12/06
 */

import java.util.*;
import java.io.*;
import java.text.*;

public class EncoderTest
{
    public static void main() throws IOException {
        int currentNumber, temp;
        int Eint=0,Dint=0,Uint=0,total=0;
        String currentChar;
        
        // get names for input and output file
        Scanner stdin = new Scanner(System.in);
        System.out.println("Please enter the input file name: ");
        String input = stdin.nextLine();
        System.out.println("Please enter the output file name: ");
        String output = stdin.nextLine();
        
        // initialize scanner and print writer
        Scanner fileIn = new Scanner(new File(input));
        FileWriter output2 = new FileWriter(output);
        PrintWriter fileOut = new PrintWriter(output2);
        
        // start while loop
        while(fileIn.hasNext()) {
            currentChar = fileIn.next();
            currentNumber = fileIn.nextInt();
            temp = currentNumber;
            // decode if E and print and count
            if(currentChar.equals("E")) {
                currentNumber = BankEncoder.encode(currentNumber);
                Eint += 1; total += 1;
                fileOut.println(temp + "   ENCODE   " + currentNumber);
                //System.out.println(temp + "     " + currentNumber);
            }
            // encode if D and print and count
            else if(currentChar.equals("D")) {
                currentNumber = BankEncoder.decode(currentNumber);
                Dint += 1; total += 1;
                fileOut.println(temp + "   DECODE   " + currentNumber);
                //System.out.println(temp + "     " + currentNumber);
            }
            // else print error and count
            else {
                Uint += 1; total += 1;
                fileOut.println(currentChar + "       Error, unrecognized command");
                //System.out.println(currentChar + "      Error, unrecognized command");
            }
        }
        // construct percentages and print in out file
        float total2 = total, Efl = Eint, Dfl = Dint, Ufl = Uint;
        float Eper = Efl/total2; 
        float Dper = Dfl/total2;
        float Uper = Ufl/total2;
        NumberFormat style = NumberFormat.getNumberInstance();
        style.setMaximumFractionDigits(2);
        style.setMinimumFractionDigits(2);
        //System.out.println();
        //System.out.println(" total encodings: " + Eint + "      percentage: " + style.format(Eper));
        //System.out.println(" total decodings: " + Dint + "      percentage: " + style.format(Dper));
        //System.out.println(" total errors:    " + Uint + "      percentage: " + style.format(Uper));
        //System.out.println(" total requests:  " + total);
        fileOut.println();
        fileOut.println(" total encodings: " + Eint + "      percentage: " + style.format(Eper));
        fileOut.println(" total decodings: " + Dint + "      percentage: " + style.format(Dper));
        fileOut.println(" total errors:    " + Uint + "      percentage: " + style.format(Uper));
        fileOut.println(" total requests:  " + total);
        fileOut.close();
    }
}