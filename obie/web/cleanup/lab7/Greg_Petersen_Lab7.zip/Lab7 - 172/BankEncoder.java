
/**
 * A program that encodes and decodes bank numbers.
 * 
 * @author Greg Petersen
 * @version 3/12/06
 */
public class BankEncoder
{
    /** This method takes a number and encodes it into the bank format. */
    public static int encode(int oldNumber) {
        //seperate out each digit of the number
        int digit1 = oldNumber/1000; oldNumber=oldNumber%1000;
        int digit2 = oldNumber/100; oldNumber=oldNumber%100;
        int digit3 = oldNumber/10; oldNumber=oldNumber%10;
        int digit4 = oldNumber;
        //adjust the numbers using the given formula
        digit1 = (digit1+7)%10;
        digit2 = (digit2+7)%10;
        digit3 = (digit3+7)%10;
        digit4 = (digit4+7)%10;
        //put the number back together in the appropriate order
        int newNumber = digit3*1000 + digit4*100 + digit1*10 + digit2;
        
        return newNumber;
    }
    /** This method takes a number in bank format and decodes it into its original number. */
    public static int decode(int oldNumber) {
         //seperate out each digit of the number
        int digit1 = oldNumber/1000; oldNumber=oldNumber%1000;
        int digit2 = oldNumber/100; oldNumber=oldNumber%100;
        int digit3 = oldNumber/10; oldNumber=oldNumber%10;
        int digit4 = oldNumber;
        //convert back to regular numbers
        if(digit1>6) digit1 = digit1-7;
        else digit1 = digit1+3;
        if(digit2>6) digit2 = digit2-7;
        else digit2 = digit2+3;
        if(digit3>6) digit3 = digit3-7;
        else digit3 = digit3+3;
        if(digit4>6) digit4 = digit4-7;
        else digit4 = digit4+3;
        //return number in appropriate order
        int newNumber = digit3*1000 + digit4*100 + digit1*10 + digit2;
        
        return newNumber;
    }
}
