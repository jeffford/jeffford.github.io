
/**
 * A class that translates english words into Pig Latin.
 * 
 * @author Greg Petersen
 * @version 3/12/06
 */
public class PigLatin
{
    /** This class changes english into PigLatin.  Any Capitalized words are changed so that
     * they are translated and still capitalized.  Also, any punctuation is maintained as
     * well.
     * */
    public static String translate(String english) {
        // declare variables
        int length = 50, i = 0;
        char temp, temp2, temp3;
        String word = null, PLatin = "", ay = "ay";
        boolean blank = false, vowel = false;
        
        // check to see if anything in string.
        english = english.trim();
        length = english.length();
        
        // get length of first word
        while(length!=0) {
            for(i=0;i<length;i++) {
                temp = english.charAt(i);
                blank = Character.isWhitespace(temp);
                if (blank==true) break;
            }
            // select out first word and cut out first word from original sentence
            word = english.substring(0,i);
            english = english.substring(i,length);
            
            // check to see if first letter is vowel
            if(word.charAt(0) == 'a') vowel=true;
            else if(word.charAt(0) == 'A') vowel=true;
            else if(word.charAt(0) == 'E') vowel=true;
            else if(word.charAt(0) == 'I') vowel=true;
            else if(word.charAt(0) == 'O') vowel=true;
            else if(word.charAt(0) == 'U') vowel=true;
            else if(word.charAt(0) == 'e') vowel=true;
            else if(word.charAt(0) == 'i') vowel=true;
            else if(word.charAt(0) == 'o') vowel=true;
            else if(word.charAt(0) == 'u') vowel=true;
            else if(word.length() == 1) vowel=true;
            else vowel = false;
            
            length = word.length();
            // convert word to piglatin if first letter is vowel.
            if(vowel && Character.isLetterOrDigit(word.charAt(length-1))) word = word + "ay";
            else if(vowel) {
                temp = word.charAt(length-1);
                word = word.substring(0,length-1) + ay + temp;
            }
                
            // convert if not vowel and word is bigger than two letters.
            else if(length>2) {
                temp = word.charAt(0);
                temp2 = word.charAt(1);
                temp3 = word.charAt(length-1);
                if(Character.isLowerCase(temp)==false && Character.isLowerCase(temp2)==true) {
                    temp = Character.toLowerCase(temp);
                    temp2 = Character.toUpperCase(temp2);
                }
                word = word.substring(2,length-1);
                if(Character.isLetterOrDigit(temp3))
                    word = temp2 + word + temp3 + temp + ay;
                else 
                    word = temp2 + word + temp + ay + temp3;
            }
            else { //if length equals 2
                temp = word.charAt(0);
                temp2 = word.charAt(1);
                blank = Character.isLetterOrDigit(temp2);
                word = word.substring(1,length);
                if(blank) {
                    if(Character.isLowerCase(temp)==false && Character.isLowerCase(temp2)==true) {
                        temp = Character.toLowerCase(temp);
                        temp2 = Character.toUpperCase(temp2);
                    }
                    word = Character.toString(temp2) + Character.toString(temp) + ay;
                }
                else
                    word = temp + ay + word;
            }
            
            PLatin = PLatin + word + " ";
            
            english = english.trim();
            length = english.length();
        }
        return PLatin;
    }       
}
