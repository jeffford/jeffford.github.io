
/**
 * Write a description of class PigLatinTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
// get necessary libraries for i/o
import java.util.*; 
import java.io.*;	   
public class PigLatinTest {
    public static void main (String[] args) throws IOException { 

//Create a File
   String filename = ""+"ToPigLatin.txt";
    File file = new File(filename);

//Create a Scanner for the file
    Scanner fileIn = new Scanner(file);
    while (fileIn.hasNext()) {
        String currentLine = fileIn.nextLine();
        System.out.println(currentLine);
        System.out.println(PigLatin.Translate(currentLine));
    }
fileIn.close(); }} 
