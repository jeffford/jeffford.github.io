
/**
 * This class encodes and decodes a series of strings.
 * 
 * @author Rebecca Fischer
 * @version 2/13/06
 */
public class Encrypt
{
        /**
         * This method encodes the string.
         * 
         * @param  y   a string
         * @return     a string
         */
        public static String encode(String y)
        {
                if (y.startsWith("E") == true){

                    char a=y.charAt(1);
                    char b=y.charAt(2);
                    char c=y.charAt(3);
                    char d=y.charAt(4);
                    int e=Character.getNumericValue(a);
                    int f=Character.getNumericValue(b);
                    int g=Character.getNumericValue(c);
                    int h=Character.getNumericValue(d);
                    e=(e+7)%10;
                    f=(f+7)%10;
                    g=(g+7)%10;
                    h=(h+7)%10;
                    return ""+g+h+e+f;
                    
                  }
   else 
     return ""+"Cannot encode.";}
        /**
              * This method decodes the string.
              * 
              * @param  y   a string
              * @return     a string
              */
             public static String decode(String y)
             {
                     if (y.startsWith("D") == true){
     
                         char a=y.charAt(1);
                         char b=y.charAt(2);
                         char c=y.charAt(3);
                         char d=y.charAt(4);
                         int e=Character.getNumericValue(a);
                         int f=Character.getNumericValue(b);
                         int g=Character.getNumericValue(c);
                         int h=Character.getNumericValue(d);
            switch(e){
            case 1: if(e==1); e=4;break;
            case 2: if(e==2); e=5;break;
            case 3: if(e==3); e=6;break;
            case 4: if(e==4); e=7;break;
            case 5: if(e==5); e=8;break;
            case 6: if(e==6); e=9;break;
            case 7: if(e==7); e=0;break;
            case 8: if(e==8); e=1;break;
            case 9: if(e==9); e=2;break;
            case 10: if(e==0); e=3;break;
            }
            
            
            switch(f){
            case 1: if(f==1); f=4;break;
            case 2: if(f==2); f=5;break;
            case 3: if(f==3); f=6;break;
            case 4: if(f==4); f=7;break;
            case 5: if(f==5); f=8;break;
            case 6: if(f==6); f=9;break;
            case 7: if(f==7); f=0;break;
            case 8: if(f==8); f=1;break;
            case 9: if(f==9); f=2;break;
            case 10: if(f==0); f=3;break;
         }
         
         switch(g){
            case 1: if(g==1); g=4;break;
            case 2: if(g==2); g=5;break;
            case 3: if(g==3); g=6;break;
            case 4: if(g==4); g=7;break;
            case 5: if(g==5); g=8;break;
            case 6: if(g==6); g=9;break;
            case 7: if(g==7); g=0;break;
            case 8: if(g==8); g=1;break;
            case 9: if(g==9); g=2;break;
            case 10: if(g==0); g=3;break;
         }
         
         switch(h){
            case 1: if(h==1); h=4;break;
            case 2: if(h==2); h=5;break;
            case 3: if(h==3); h=6;break;
            case 4: if(h==4); h=7;break;
            case 5: if(h==5); h=8;break;
            case 6: if(h==6); h=9;break;
            case 7: if(h==7); h=0;break;
            case 8: if(h==8); h=1;break;
            case 9: if(h==9); h=2;break;
            case 10: if(h==0); h=3;break;
         }
                return ""+g+h+e+f;
               }
        else 
          return ""+"Cannot decode.";
          }
        }