/**
 * This class translates regular english words into pig-latin.
 * 
 * @author Rebecca 
 * @version 3/12/06
 */
public class PigLatin
{
    
    /**
     * This method does the translation.
     *
     * @param  y   a string
     * @return a string    
     */
    
    public static String Translate(String y) {
        //convert to lowercase to aviod weirdness
        y=y.toLowerCase();
      // check if it starts with a vowell or a contanant
      if ( (y.startsWith("a") || y.startsWith("e") || y.startsWith("i") ||
            y.startsWith("o") || y.startsWith("u")||y.startsWith("A") || y.startsWith("E") || y.startsWith("I") ||
            y.startsWith("O") || y.startsWith("U")) == true){
      return "" + y + "ay" ;}
   else{
     return ""+y.substring(1)+y.substring(0,1)+"ay";}
    }
  }