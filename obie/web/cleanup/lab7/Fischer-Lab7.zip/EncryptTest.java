/**
 * This tests the class Encrypt.
 * 
 * @author Rebecca Fischer
 * @version 3/12/06
 */
// get necessary libraries for i/o
import java.util.*; 
import java.io.*;      
public class EncryptTest {
    public static void main (String[] args) throws IOException { 

//Create a File
   String filename = ""+"ToEncrypt.txt";
    File file = new File(filename);
    String filename2 = ""+"Encrypted.txt";
    PrintWriter fileOut = new PrintWriter(filename2);

//Create a Scanner for the file
    Scanner fileIn = new Scanner(file);
    //while loop for encoding and decoding
    while (fileIn.hasNext()) {
        String currentLine = fileIn.nextLine();
        System.out.println(currentLine);
        fileOut.println(currentLine);
            if(currentLine.startsWith("E")){
                System.out.println(Encrypt.encode(currentLine));
                fileOut.println(Encrypt.encode(currentLine));}
            else if(currentLine.startsWith("D")){
                System.out.println(Encrypt.decode(currentLine));
                fileOut.println(Encrypt.decode(currentLine));}
            else{
                System.out.println("Not a valid command");
                fileOut.println("Not a valid command");}
    }
fileIn.close(); 
fileOut.close();}} 