
/**
 * The PigLatin class will take an input string and convert it
 * from the English form of a word into the Pig Latin form of it.
 * 
 * @author Joe Moeller
 * @version 2-27-06
 */
public class PigLatin
{
            
    /**
     * Method Translate - translates word from English to Pig Latin
     * 
     * @param   String english
     * @return  translated string
     */
    
    public String Translate(String english) {
        //cuts the blank space off each end of the string
        english = english.trim();
       
        //using if-else-if statements we can see if
        //the input string begins with a vowel or not
        if (english.charAt(0) == 'a')
            return english + "ay";
        else if (english.charAt(0) == 'e')
            return english + "ay";
        else if (english.charAt(0) == 'i')
            return english + "ay";
        else if (english.charAt(0) == 'o')
            return english + "ay";
        else if (english.charAt(0) == 'u')
            return english + "ay";
        else {
            //if word doesnt start with a vowel, the method
            //uses this else statement to convert the word that 
            //begins with a consonant
            String firstLetter = english.substring(0, 1);
            english = english.substring(1, english.length());
            String pigLatin = english + firstLetter + "ay";
            return pigLatin;
 
 
}
}
}
