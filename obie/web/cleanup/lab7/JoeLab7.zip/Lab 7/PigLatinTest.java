
/**
 * Calls the PigLatin class to translate English words into Pig Latin form.
 * 
 * @author Joe Moeller
 * @version 2-27-06
 */
import java.util.*;
import java.io.*;
public class PigLatinTest {
    public static void main(String[] args) throws IOException {
        
    //set up scanner    
    Scanner stdin = new Scanner(System.in);
    
    //determine the file    
    System.out.print("File: ");
    String englishWord = stdin.nextLine();
    File file = new File(englishWord);
    
    //set up the file stream
    Scanner fileIn = new Scanner(file);
    
    //allow use of class PigLatin
    PigLatin pigTranslate = new PigLatin ();
    
    //look through lines one by one
    String wordCount = fileIn.nextLine();
    System.out.println(wordCount);
    int wordNumber = Integer.parseInt(wordCount);
    
    for (int i = 0; i < wordNumber; i++){
        String line = fileIn.nextLine();
        line = pigTranslate.Translate(line);
        System.out.println(line);
}
}
}
