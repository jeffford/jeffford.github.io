
/**
 * class TransmitData contains methods to decode
 * or encode information from an input text file.
 * 
 * @author Joe Moeller
 * @version 3-9-06
 */
public class TransmitData
{
    
    /**
     * Constructor for objects of class TransmitData
     */
    public TransmitData()
    {
        // initialise instance variables
        int x = 0;
    }

    /**
     * method encode encodes information
     * 
     * @param  String infoLine
     * @return encoded information line 
     */
    public String encode(String infoLine)
    {
        infoLine = infoLine.trim();
        

            String integers = infoLine;

            String firstNumber = integers.substring(0, 1);
            int firstInteger = Integer.parseInt(firstNumber);
            
            String secondNumber = integers.substring(1, 2);
            int secondInteger = Integer.parseInt(secondNumber);
            
            String thirdNumber = integers.substring(2, 3);
            int thirdInteger = Integer.parseInt(thirdNumber);
            
            String fourthNumber = integers.substring(3, integers.length());
            int fourthInteger = Integer.parseInt(fourthNumber);
            
            //convert original integers in the 4-digit number to their
            //encoded form.
            int encodedFirstInteger = (firstInteger + 7) % 10;
            int encodedSecondInteger = (secondInteger + 7) % 10;
            int encodedThirdInteger = (thirdInteger + 7) % 10;
            int encodedFourthInteger = (fourthInteger + 7) % 10;
            
            //put encoded numbers into order in a string
            String encodedNumber = encodedThirdInteger + "" +  encodedFourthInteger + "" + encodedFirstInteger + "" + encodedSecondInteger + "";
            return encodedNumber;
            
                    
    }
    /**
     * method decode decodes information
     * 
     * @param String infoLine
     * @return decoded line of information
     */


    public String decode(String infoLine){
       
        infoLine = infoLine.trim();
        
        String integers = infoLine;
        
        String firstNumber = integers.substring(0, 1);
        int firstInteger = Integer.parseInt(firstNumber);
            
        String secondNumber = integers.substring(1, 2);
        int secondInteger = Integer.parseInt(secondNumber);
            
        String thirdNumber = integers.substring(2, 3);
        int thirdInteger = Integer.parseInt(thirdNumber);
            
        String fourthNumber = integers.substring(3, integers.length());
        int fourthInteger = Integer.parseInt(fourthNumber);
        
        int decodedFirstNumber = 0;
        
        switch (firstInteger) {
            case 0:
                decodedFirstNumber = 3;
                break;
            case 1:
                decodedFirstNumber = 4;
                break;
            case 2:
                decodedFirstNumber = 5;
                break;
            case 3:
                decodedFirstNumber = 6;
                break;
            case 4:
                decodedFirstNumber = 7;
                break;
            case 5:
                decodedFirstNumber = 8;
                break;
            case 6:
                decodedFirstNumber = 9;
                break;
            case 7:
                decodedFirstNumber = 0;
                break;
            case 8:
                decodedFirstNumber = 1;
                break;
            case 9:
                decodedFirstNumber = 2;
                break;
    }
        int decodedSecondNumber = 0;
        switch (secondInteger) {
            case 0:
                decodedSecondNumber = 3;
                break;
            case 1:
                decodedSecondNumber = 4;
                break;
            case 2:
                decodedSecondNumber = 5;
                break;
            case 3:
                decodedSecondNumber = 6;
                break;
            case 4:
                decodedSecondNumber = 7;
                break;
            case 5:
                decodedSecondNumber = 8;
                break;
            case 6:
                decodedSecondNumber = 9;
                break;
            case 7:
                decodedSecondNumber = 0;
                break;
            case 8:
                decodedSecondNumber = 1;
                break;
            case 9:
                decodedSecondNumber = 2;
                break;
    }
            int decodedThirdNumber = 0;
        switch (thirdInteger) {
            case 0:
                decodedThirdNumber = 3;
                break;
            case 1:
                decodedThirdNumber = 4;
                break;
            case 2:
                decodedThirdNumber = 5;
                break;
            case 3:
                decodedThirdNumber = 6;
                break;
            case 4:
                decodedThirdNumber = 7;
                break;
            case 5:
                decodedThirdNumber = 8;
                break;
            case 6:
                decodedThirdNumber = 9;
                break;
            case 7:
                decodedThirdNumber = 0;
                break;
            case 8:
                decodedThirdNumber = 1;
                break;
            case 9:
                decodedThirdNumber = 2;
                break;
            
        }
            
            int decodedFourthNumber = 0;
        switch (fourthInteger) {
            case 0:
                decodedFourthNumber = 3;
                break;
            case 1:
                decodedFourthNumber = 4;
                break;
            case 2:
                decodedFourthNumber = 5;
                break;
            case 3:
                decodedFourthNumber = 6;
                break;
            case 4:
                decodedFourthNumber = 7;
                break;
            case 5:
                decodedFourthNumber = 8;
                break;
            case 6:
                decodedFourthNumber = 9;
                break;
            case 7:
                decodedFourthNumber = 0;
                break;
            case 8:
                decodedFourthNumber = 1;
                break;
            case 9:
                decodedFourthNumber = 2;
                break;
            
        }
            
        //put decoded numbers into a string    
        String decodedNumber = decodedThirdNumber + "" + decodedFourthNumber + "" +  decodedFirstNumber + "" + decodedSecondNumber + "";
        return decodedNumber;
    }
}