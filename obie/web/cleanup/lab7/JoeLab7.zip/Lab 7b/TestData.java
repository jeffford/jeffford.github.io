
/**
 * class TestData is designed to use class TransmitData to 
 * encode or decode the desired text file.
 * 
 * @author Joe Moeller 
 * @version 3-9-06
 */
import java.util.*;
import java.io.*;
public class TestData {
    public static void main(String[] args) throws IOException {
    
    //scanner is created
    Scanner stdin = new Scanner(System.in);
    
    //file is input into the program
    System.out.print("File: ");
    String data = stdin.nextLine();
    File file = new File(data);
    
    Scanner fileIn = new Scanner(file);
    
    //new TransmitData class is created
    TransmitData transmission = new TransmitData();
    
    //new output file is created
    System.out.print("What would you like the output file name to be? ");
    String outputFileName = stdin.nextLine();
    FileWriter newFile = new FileWriter(outputFileName); 
    PrintWriter fileOut = new PrintWriter(newFile);
    
    //variables are initialized
    double T = 0;
    double E = 0;
    double D = 0;
    double invalid = 0;
    
    //while loop continues to execute
    //as long as there is a next line
 while (fileIn.hasNextLine()) {
    
    ++T;
    String temp = fileIn.next();

    //if-else statement to examine first letter
    //of each line
    if (temp.equals("E")) {
            String dataLine = fileIn.next();
            
            String encodedData = transmission.encode(dataLine);
            fileOut.println(dataLine + " ENCODED: " + encodedData);
            ++E;
    }

    else if (temp.equals("D")) {
            String dataLine = fileIn.next();
            
            String decodedData = transmission.decode(dataLine);
            fileOut.println(dataLine + " DECODED: " + decodedData);
            ++D;
        }
    
    else {
        String dataLine = fileIn.next();
       fileOut.println(dataLine + ": " + temp + " is not a valid character!");
       ++invalid;
   }
   
}
        //calculations of percentages
        double encPercent = (E / T) * 100;
        double decPercent = (D / T) * 100;
        double invPercent = (invalid / T) * 100;
        //print out the calculations
        fileOut.println();
        fileOut.println("Total number of requests: " + T);
        fileOut.print("Number of Encodings: " + E + ", being ");
        fileOut.printf("%5.2f" , encPercent); 
        fileOut.println("%" + " of the total");
        fileOut.print("Number of Decodings: " + D + ", being ");
        fileOut.printf("%5.2f" , decPercent);
        fileOut.println("%" + " of the total");
        fileOut.print("Number of erroneous requests:" + invalid + ", being ");
        fileOut.printf("%5.2f" , invPercent); 
        fileOut.println("%" + " of the total");
        fileOut.close();
}
    }
