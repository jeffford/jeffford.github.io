
/**
 * TransmitData encodes and decodes numbers.
 * 
 * @author Kyli Foltz 
 * @version 3/10/2006
 */
public class TransmitData
{
    /**
     * Encode - encode a 4 digit positive integer
     * 
     * @param code the number to be encoded
     * @return     the encoded number
     */
    public String Encode(int code)
    {
        // Tear the number apart
        int digit1 = code % 10;
        code = code / 10;
        int digit2 = code % 10;
        code = code / 10;
        int digit3 = code % 10;
        code = code / 10;
        int digit4 = code % 10;

        // Make the appropriate replacement
        digit1 = (digit1 + 7) % 10;
        digit2 = (digit2 + 7) % 10;
        digit3 = (digit3 + 7) % 10;
        digit4 = (digit4 + 7) % 10;
        
        // Switch the appropriate digits
        int rememberD1 = digit1;
        digit1 = digit3;
        digit3 = rememberD1;
        int rememberD2 = digit2;
        digit2 = digit4;
        digit4 = rememberD2;
        
        // Return the encoded number
        return digit4 + "" + digit3 + "" + digit2 + "" + digit1;
        }

/**
     * Decode - Decode a 4 digit positive integer
     * 
     * @param code the number to be decoded
     * @return     the decoded number
     */
    public String Decode(int code)
    {
        // Tear the number apart
        int digit1 = code % 10;
        code = code / 10;
        int digit2 = code % 10;
        code = code / 10;
        int digit3 = code % 10;
        code = code / 10;
        int digit4 = code % 10;

        // Switch the appropriate digits
        int rememberD1 = digit1;
        digit1 = digit3;
        digit3 = rememberD1;
        int rememberD2 = digit2;
        digit2 = digit4;
        digit4 = rememberD2;
        
        // Undo the replacements
        if (digit1 >= 7)
            digit1 = digit1 - 7;
        else
            digit1 = digit1 + 10 - 7;
        if (digit2 >= 7)
            digit2 = digit2 - 7;
        else 
            digit2 = digit2 + 10 - 7;
        if (digit3 >= 7)
            digit3 = digit3 - 7;
        else 
            digit3 = digit3 + 10 - 7;
        if (digit4 >= 7)
            digit4 = digit4 - 7;
        else 
            digit4 = digit4 + 10 - 7;
        
        // Return the decoded number
        return digit4 + "" + digit3 + "" + digit2 + "" + digit1;
        }
    }
