
/**
 * TransmitDataDemo exercises the TrasmitData class.
 * 
 * @author Kyli Foltz 
 * @version 3/11/2006
 */

import java.util.*;
import java.io.*;

public class TransmitDataDemo
{
    /**
     * Main method to exercise the TransmitData class
     * 
     */
    public static void main(String[] args) throws IOException {
        // Obtain the file names from the user
        Scanner stdin = new Scanner(System.in);
        System.out.print("Enter the file name that contains the data: ");
        String name = stdin.nextLine();
        System.out.println();
        System.out.print("Enter the file name for the results: ");
        String outputFileName = stdin.nextLine();
        
        // Construct the output file writer
        PrintWriter fileOut = new PrintWriter(outputFileName);
        
        // Get the file that contains the data
        File file = new File(name);
        Scanner fileIn = new Scanner(file);
        
        // Encode or decode each integer in the file
        int counter1 = 0;
        int counter2 = 0;
        int counter3 = 0;
        while (fileIn.hasNext()) {
            String letter = fileIn.next();
            if (letter.equals("E")) {
                TransmitData c = new TransmitData();
                int word = fileIn.nextInt();               
                fileOut.println(word + " ENCODED: " + c.Encode(word));
                String temp = fileIn.nextLine();
                ++counter1;
            }
            else if (letter.equals("D")) {
                TransmitData c = new TransmitData();
                int word = fileIn.nextInt();
                fileOut.println(word + " DECODED: " + c.Decode(word));
                String temp = fileIn.nextLine();
                ++counter2;
            }
            else {
                fileOut.println(fileIn.next() + ": INAPPROPRIATE CHARACTER");
                String temp = fileIn.nextLine();
                ++counter3;
            }
        }
        
        // Print a summary of results
        fileOut.println();
        fileOut.println("SUMMARY");
        double total = counter1 + counter2 + counter3;
        double c1 = counter1 / total;
        fileOut.println("Number of requests: " + total);
        fileOut.println("Number of encodings: " + counter1);
        fileOut.printf("Percentage of total: %5.2f", c1);
        fileOut.println();
        double c2 = counter2 / total;
        fileOut.println("Number of decodings: " + counter2);
        fileOut.printf("Percentage of total: %5.2f", c2);
        fileOut.println();
        double c3 = counter3 / total;
        fileOut.println("Number of erroneous requests: " + counter3);
        fileOut.printf("Percentage of total: %5.2f", c3);
        fileOut.close();
        System.out.println("Check the specified file for the results.");
    }
}
