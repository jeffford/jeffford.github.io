
/**
 * The PigLatin class translates English words into Pig Latin.
 * 
 * @author      Kyli Foltz 
 * @version     3/7/2006
 */
public class PigLatin
{
    /**
     * PigLatin - Translates a given English word into Pig Latin
     * 
     * @param      word - English word to be translated
     * @return     Translation of word into Pig Latin 
     */
    public String Translate(String word)
    {
        // Translate the English word
        word = word.toLowerCase();
        char first = word.charAt(0);
        if (first == 'a' || first == 'e' || first == 'i' || first == 'o' || first == 'u') 
            return word + "ay";
        else 
            return word.substring(1) + first + "ay";
        }
}
