
/**
 * The PigLatinTest exercises the PigLatin class.
 * 
 * @author  Kyli Foltz 
 * @version 3/7/2006
 */
import java.io.*;
import java.util.*;

public class PigLatinTest
{
    /**
     * Main method to exercise the PigLatin class
     * 
     */
    public static void main(String[] args) throws IOException { 
        // open the file that contains the English words
        File file = new File("ToPigLatin.txt");
        Scanner fileIn = new Scanner(file);
        int number = fileIn.nextInt();
        String temp = fileIn.nextLine();
        for (int i = 1; i <= number; ++i) {
            String word = fileIn.nextLine();
            System.out.print(word + ": ");
            PigLatin w = new PigLatin();
            String latin = w.Translate(word);
            System.out.println(latin);
        }
    }
}
