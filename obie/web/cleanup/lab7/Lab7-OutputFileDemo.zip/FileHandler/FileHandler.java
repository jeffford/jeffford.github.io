import java.util.*;
import java.io.*;

//demo for Cory and Jerry for input and output files in Java 5.0
//does not actually do any encoding or decoding
public class FileHandler {
    public static void main (String[] args) throws IOException {
        //Setup interactive Scanner for obtaining names from the console
    Scanner stdin = new Scanner(System.in);
        //Obtain name of input file and output file from user
    System.out.print("Input Filename: ");
    String inputFilename = stdin.nextLine();
    
    System.out.print("Output Filename: ");
    String outputFileName = stdin.nextLine();
        //Create input file 
     File file = new File(inputFilename);
     Scanner fileIn = new Scanner(file);
        //And output file
     PrintWriter fileOut = new PrintWriter(outputFileName);

    while (fileIn.hasNext()) {
        String which = fileIn.next();
        fileOut.print(" Read " + which);
           if (which.equals("E")) fileOut.print("    encode it:      ");
           else if (which.equals("D")) fileOut.print("    decode it:      ");
           else fileOut.print("    erroneous input do nothing for : ");
        int number = fileIn.nextInt();
        fileOut.println(number);
    }
fileIn.close();
fileOut.close();
System.out.println("Run completed.");
    }
}
