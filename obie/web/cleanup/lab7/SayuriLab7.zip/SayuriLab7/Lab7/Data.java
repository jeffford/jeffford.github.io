
/**
 * The class Data encode and decode a 4 digit numbers that was read
 * from the input text file and output on the output file.
 * 
 * @author (Sayuri Ichida) 
 * @version (Lab 7, date completed-3/13/2006, date submitted-3/15/2006)
 */
public class Data
{
    // instance variable
    private int code;

    /**
     * Default constructor for objects of class Data
     */
    public Data()
    {
        // initialise instance variable
        code = 0;
    }

     /**
     * Data mutator that sets a 4 or less digit integer
     * 
     * @param c a 4 or less digit positive integer
     * 
     */
    public void setData(int c) {
        code = c;
    }
    
    /**
     * Data accessor that provides a 4 or less digit integer
     * 
     * @return     a 4 or less digit positive integer
     */ 
    public int getData() {
        return code;
    }
    
    /**
     * Encode the 4 digit positive integer
     * 
     * @return  encoding of the original 4 digit number   
     */
    public Data Encode()
    {
        Data temp = new Data();
        
        // tear the 4 digit integer apart into its separate components
        int i1 = code / 1000;                 // first digit
        int i2 = code % 1000 / 100;           // second digit
        int i3 = code % 1000 % 100 / 10;      // third digit
        int i4 = code % 1000 % 100 % 10;      // fourth digit
        
        // do the replacement
        i1 = (i1 + 7) % 10;       
        i2 = (i2 + 7) % 10;        
        i3 = (i3 + 7) % 10;
        i4 = (i4 + 7) % 10;
        
        // do the exchanges and combine the 4 numbers into a 4 or less digit integer
        temp.setData(i3 * 1000 + i4 * 100 + i1 * 10 + i2);
        
        return temp;
    }
    
    /**
     * Decode the 4 digit positive integer
     * 
     * @return  decoding of the original 4 digit number   
     */
    public Data Decode()
    {
        Data temp = new Data();
        
        // tear the 4 digit integer apart into its separate components
        int i1 = code / 1000;                 // first digit
        int i2 = code % 1000 / 100;           // second digit
        int i3 = code % 1000 % 100 / 10;      // third digit
        int i4 = code % 1000 % 100 % 10;      // fourth digit
        
        // make copy for i1 and i2 before undoing the exchanges
        int copy_i1 = i1;
        int copy_i2 = i2;
        
        // undo the exchanges for the encode
        i1 = i3;
        i3 = copy_i1;
        i2 = i4;
        i4 = copy_i2;
        
        // undo the replacement for each integer
        if (i1 >= 7) {
            i1 = i1 - 7;
        }
        else {
            i1 = i1 + 3;
        }
          
        if (i2 >= 7) {
            i2 = i2 - 7;
        }
        else {
            i2 = i2 + 3;
        }
        
        if (i3 >= 7) {
            i3 = i3 - 7;
        }
        else {
            i3 = i3 + 3;
        }
        
        if (i4 >= 7) {
            i4 = i4 - 7;
        }
        else {
            i4 = i4 + 3;
        }
        
        // combine the 4 numbers into a 4 or less digit integer
        temp.setData(i1 * 1000 + i2 * 100 + i3 * 10 + i4);
        
        return temp;
    }
    
    /**
     * Converts the 4 or less digit positive integer to string suitable for outputs 
     * 
     * @return     a string for the 4 or less digit positive integer 
     */
    public String toString() {
        return code + "";
    }
}
