
/**
 * The class PigLatin translate the English words into the PigLatin language.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PigLatin
{
    // instance variable
    private String word;

    /**
     * Constructor for objects of class PigLatin
     */
    public PigLatin()
    {
        // initialize instance variable
        word = "ay";
    }
    
    // mutator
    public void setPig(String w) {
        word = w;
    }
    
    // accessor
    public String getPig() {
        return word;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public PigLatin Translate()
    {
        PigLatin temp = new PigLatin();
        // set the first letter of a word to be first_letter
        String first_letter = word.substring(0,1);
        // if a word begins with a vowel(a, e, i, o, or u)
        if (first_letter.equals("a") || first_letter.equals("e") || first_letter.equals("i") || first_letter.equals("o") || first_letter.equals("u")) {
            // simply added "ay" to the word
            temp.setPig(word + "ay");
        }
        // otherwise
        else {
            // determine the length of the word
            int length = word.length();
            // define letters to be a word without the first letter of the word
            String letters = word.substring(1, length);
            // add the first letter of the word to the end of the "letters" and then add "ay" 
            temp.setPig(letters + first_letter + "ay");
        }
        return temp;
    }
    
    public String toString() {
        return word;
    }
        
}
