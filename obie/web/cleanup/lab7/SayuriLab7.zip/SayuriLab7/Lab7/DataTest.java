
/**
 * The class DataTest tests the class Data.
 * 
 * @author (Sayuri Ichida) 
 * @version (Lab 7, date completed-3/13/2006, date submitted-3/15/2006)
 */
import java.util.*;
import java.io.*;
public class DataTest
{
   /**
	 * The main method
	 * 
	 * @param  args with type String[]
	 */
   public static void main (String [] args) throws IOException {
       // set up standard input stream
       Scanner stdin = new Scanner(System.in);
       
       // determine file
       System.out.print("File: ");
       String name = stdin.nextLine();
       File file = new File(name);
       
       // set up file stream
       Scanner fileIn = new Scanner(file);
       
       // request the output file name for the user
       System.out.print("Please enter a string for the output file name: ");
       String outputFileName = stdin.nextLine();
       
       // construct the output file writer
       PrintWriter fileOut = new PrintWriter(outputFileName);
       
       // initialize all of the count numbers
       int count = 0;
       int count_encodings = 0;
       int count_decodings = 0;
       int count_error = 0;
       
       // process lines one by one
       while (fileIn.hasNext()) {
                   
           // get the first character as a String
           String letter = fileIn.next();
           
           // get the integer
           Integer number = fileIn.nextInt();

           Data current = new Data();
           current.setData(number);
           
           // if an E is found
           if (letter.equals("E")) {
               // encode (perform the Encode method in Data class)
               Data encoded = current.Encode();
               // print the original number followed by its encoding on the console window
               //System.out.println(number + " ENCODED: " + encoded);
               // print the original number follewd by its encoding on the output file
               fileOut.println(number + " ENCODED: " + encoded);
               // count the number of encodings
               ++ count_encodings;
            }
            // if a D is found
            else if (letter.equals("D")) {
                // decode (perform the Decode method in Data class)
                Data decoded = current.Decode();
                // print the original number followed by its decoding on the console window
                //System.out.println(number + " DECODED: " + decoded);
                // print the original number follewd by its decoding on the output file
                fileOut.println(number + " DECODED: " + decoded);
                // count the number of decodings
                ++ count_decodings;
            }
            // if any other letter is found
            else {
                //System.out.println("The erroneous character, \"" + first_letter + "\" was found.");
                fileOut.println("The erroneous character \"" + letter + "\" was found.");
                // count the number of erroneous requests
                ++ count_error;
            }
            
            //System.out.println();
            fileOut.println();
            
            // count the total number of requests
            ++count;
        }
        
        // calculate the encoding percentage of the total
        double per_encodings = 100 * Double.valueOf(count_encodings) / Double.valueOf(count);
        // calculate the decoding percentage of the total
        double per_decodings = 100 * Double.valueOf(count_decodings) / Double.valueOf(count);
        // calculate the erroneous request percentage of the total
        double per_error = 100 * Double.valueOf(count_error) / Double.valueOf(count);
        
        // print a summary of statistics on the console window
        //System.out.println("The totla number of requests: " + count);
        //System.out.println("The number of encodings: " + count_encodings);
        //System.out.printf("       Its percentage of the total: %1.2f%n", per_encodings);
        //System.out.println("The number of decodings: " + count_decodings);
        //System.out.printf("       Its percentage of the total: %1.2f%n", per_decodings);
        //System.out.println("The number of erroneous requests: " + count_error);
        //System.out.printf("       Its percentage of the total: %1.2f%n", per_error);
        //System.out.println();
        
        // print a summary of statistics on the output file
        fileOut.println("The totla number of requests: " + count);
        fileOut.println("The number of encodings: " + count_encodings);
        fileOut.printf("       Its percentage of the total: %1.2f%n", per_encodings);
        fileOut.println("The number of decodings: " + count_decodings);
        fileOut.printf("       Its percentage of the total: %1.2f%n", per_decodings);
        fileOut.println("The number of erroneous requests: " + count_error);
        fileOut.printf("       Its percentage of the total: %1.2f%n", per_error);
        fileOut.println();
        
        fileOut.close();
        
    }
                      
}
