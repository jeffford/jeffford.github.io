
/**
 * The PigLatinTest class tests the class PigLatin.
 * 
 * @author (Sayuri Ichida) 
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
public class PigLatinTest
{
   public static void main (String [] args) throws IOException {
       // set up standard input stream
       Scanner stdin = new Scanner(System.in);
       
       // create a file
       File file = new File("ToPigLatin.txt");
       
       // create a Scanner for the file
       Scanner fileIn = new Scanner(file);
       
       // open the file read the number of English words in the file
       int number_of_words = Integer.valueOf(fileIn.nextLine()); 
       System.out.println("There are " + number_of_words + " words.");
       System.out.println();

       // process lines one by one
       for (int i = 0; i < number_of_words; i++) {
           // read each English word
           String english = fileIn.nextLine();
           PigLatin e = new PigLatin();
           e.setPig(english);
           System.out.println(english);
           // translate it to PigLatin
           PigLatin pig = e.Translate();
           // print the translation
           System.out.println("translation: " + pig.toString());
           System.out.println();
       }
                  
   }
}
