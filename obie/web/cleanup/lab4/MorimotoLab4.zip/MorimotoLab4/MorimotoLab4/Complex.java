public class Complex{

  //instance variable tp describe the objext
    private double Real;
    private double Imaginary;
    
  //default constructer complex()
    public Complex(){
         Real = 1.0;
         Imaginary = 1.0;
     }
     
  //setReal():mutator
    public void setReal(double x){
        Real = x;
    }

  //setImaginary():mutator
    public void setImaginary(double y){
        Imaginary = y;
    }

  //getReal:accessor
   public double getReal(){
       return Real;
   }
   
  //getImaginary:accessor
   public double getImaginary(){
       return Imaginary;
   }
   
   //specific constructer Complex()
   public Complex(double x, double y){
     setReal(x);   
     setImaginary(y);
   }
   
   //Add(Complex x):add a complex number and x
   public Complex Add(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real + x.getReal());
       temp.setImaginary(Imaginary + x.getImaginary());
       return temp;
   }
   
   //Subtract(Complex x):subtract a complex number to x
   public Complex Subtract(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real - x.getReal());
       temp.setImaginary(Imaginary - x.getImaginary());
       return temp;
   }
   
   
   //Multiply(Complex x):multiply a complex number and x
   public Complex Multiply(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real * x.getReal() - Imaginary * x.getImaginary());
       temp.setImaginary(x.getReal() * Imaginary + Real * x.getImaginary());
       return temp;
   }
   
   //Divide(Complex x):add a complex number and x
   public Complex Divide(Complex x){
       Complex temp = new Complex();
       temp.setReal((Real * x.getReal() + Imaginary * x.getImaginary()) / (x.getReal() * x.getReal() +  x.getImaginary()*  x.getImaginary()));
       temp.setImaginary(( -(Real * x.getImaginary()) + Imaginary * x.getReal()) / (x.getReal() * x.getReal() +  x.getImaginary()*  x.getImaginary()));
       return temp;
   }
   
   //scalarAdd(Complex x):add a complex number and x
   public Complex scalarAdd(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real + x.getReal());
       temp.setImaginary(x.getImaginary());
       return temp;
   }
   
   //scalarSubtract(Complex x):subtract a complex number to x
   public Complex scalarSubtract(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real - x.getReal());
       temp.setImaginary(x.getImaginary());
       return temp;
   }
   
   
   //scalarMultiply(Complex x):multiply a complex number and x
   public Complex scalarMultiply(Complex x){
       Complex temp = new Complex();
       temp.setReal(Real * x.getReal());
       temp.setImaginary(Real * x.getImaginary());
       return temp;
   }
   
   //scalarDivide(Complex x):add a complex number and x
   public Complex scalarDivide(Complex x){
       Complex temp = new Complex();
       temp.setReal((Real * x.getReal()) / (x.getReal() * x.getReal() +  x.getImaginary()*  x.getImaginary()));
       temp.setImaginary( -(Real * x.getImaginary()) / (x.getReal() * x.getReal() +  x.getImaginary()*  x.getImaginary()));
       return temp;
   }

   
   //conjugate():convert to comjudage
   public Complex conjugate(){
       Complex temp = new Complex();
       temp.Real = Real;
       temp.Imaginary = -(Imaginary);
       return temp;
   }

   //absolute():convert to absolute
   public double absolute(){
       double  temp = Real * Real + Imaginary * Imaginary;
       return temp;
   }
   
   //reciprocal(): comvert to reciprocal
   public Complex reciprocal(){
       Complex temp = new Complex();
       temp.Real = Real / (Real * Real + Imaginary * Imaginary);
       temp.Imaginary = - Imaginary / (Real * Real + Imaginary * Imaginary);
       return temp;
   }
   
   
   //convert complex number to string
   public String toString(){
      if(Imaginary >= 0)
         return Real + "+" + Imaginary + "i";
      else
         return "" + Real + Imaginary + "i";
   }
}

   