public class CokeMachine{

  //instance variable tp describe the objext
    private int TotalCan; 
    private int TotalToken;
    
  //default constructer CokeMachine()
    public CokeMachine(){
         TotalCan = 0;
         TotalToken = 0;
     }
     
  //setCan():mutator
    public void setCan(int x){
        TotalCan = x;
    }

  //setToken():mutator
    public void setToken(int y){
        TotalToken = y;
    }

  //getCan:accessor
   public int getCan(){
       return TotalCan;
   }
   
  //getToken:accessor
   public int getToken(){
       return TotalToken;
   }
   
   //specific constructer CokeMachine()
   public CokeMachine(int x, int y){
     setCan(x);   
     setToken(y);
   }
   
   //AddCan(int x):add cans
   public CokeMachine AddCan(int x){
       CokeMachine temp = new CokeMachine();
       temp.setCan(TotalCan + x);
       temp.setToken(TotalToken);
       return temp;
   }
   
   //AddCToken(int x):add token
   public CokeMachine AddToken(int x){
       CokeMachine temp = new CokeMachine();
       temp.setCan(TotalCan);
       temp.setToken(TotalToken + x);
       return temp;
   }
   
   //SubCan(int x):subtract cans
   public CokeMachine SubCan(int x){
       CokeMachine temp = new CokeMachine();
       temp.setCan(TotalCan - x);
       temp.setToken(TotalToken);
       return temp;
   }
   
   //SubCToken(int x):subtract token
   public CokeMachine SubToken(int x){
       CokeMachine temp = new CokeMachine();
       temp.setCan(TotalCan);
       temp.setToken(TotalToken - x);
       return temp;
   }
   
    //convert to string
    public String toString(){
        return  TotalCan + " / " + TotalToken ;
     }
}

   