import java.util.*;
import java.io.*;

public class MachineTest{

   public static void main(String[] args){
       
       Scanner stdin = new Scanner(System.in);

       //create a machine with 10 coke and no token
       System.out.print("create machine with how many coke :" ); 
       int x = stdin.nextInt();
       CokeMachine test = new CokeMachine(x,0);;
       
       //add 10 more cokoes to the machine       
       System.out.print("How many cokes add :" ); 
       x = stdin.nextInt();
       test = test.AddCan(x);
       
       //insert tokens in the machine
       System.out.print("How many tokens insert :" ); 
       int y = stdin.nextInt();
       test = test.AddToken(y);
       
       //print our the number of token inerted
       System.out.print("inserted token= " + test.getToken()); 
       System.out.println();
       
       //print our the number of cans in the machine
       System.out.print("total cans = " + test.getCan()); 
       System.out.println();
       
       //get a coke
       do{
       System.out.print("How many cokes do you buy :" ); 
       x = stdin.nextInt();
       }while (x > test.getCan() || y < x );
       
       test = test.SubCan(x);
       
       
       //print out remain cans
       System.out.println("The remaining numbe of cokes is " + test.getCan());
       
       //print out changes
       System.out.println("The changes are " + ( y - x ));
   }
}