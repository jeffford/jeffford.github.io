import java.util.*;
import java.io.*;

public class ComplexNum{

  //entry point 
  public static void main(String[] args){
      
      Scanner stdin = new Scanner(System.in);
      
      //extract values for z1, z2 and z3
      Complex z1 = new Complex();
      System.out.print("Enter Real(z1): ");
      double x = stdin.nextDouble();
      System.out.print("Enter Imaginary(z1): ");
      double y = stdin.nextDouble();  
      z1.setReal(x);
      z1.setImaginary(y);

      Complex z2 = new Complex();
      System.out.print("Enter Real(z2): ");
      x = stdin.nextDouble();
      System.out.print("Enter Imaginary(z2): ");
      y = stdin.nextDouble();  
      z2.setReal(x);
      z2.setImaginary(y);
 
      Complex z3 = new Complex();
      System.out.print("Enter Real(z3): ");
      x = stdin.nextDouble();
      System.out.print("Enter Imaginary(z3): ");
      y = stdin.nextDouble();  
      z3.setReal(x);
      z3.setImaginary(y);
 
      //extract values for r
      Complex r = new Complex();
      System.out.print("Enter number(r): ");
      x = stdin.nextDouble();
      r.setReal(x);
      r.setImaginary(0);
 
      Complex sum = z1.Add(z2);
      Complex diffrence = z1.Subtract(z2);
      Complex product = z1.Multiply(z2);
      Complex quotient = z1.Divide(z2);
      
      Complex scalarSum = r.scalarAdd(z1);
      Complex scalarDiffrence = r.scalarSubtract(z1);
      Complex scalarProduct = r.scalarMultiply(z1);
      Complex scalarQuotient = r.scalarDivide(z1);
      
      Complex conjugate = z1.conjugate();
      double absolute = z1.absolute();
      Complex reciprocal = z1.reciprocal();
      
      //caompute z1 + z2 + z3
      
      Complex expression = z1.Add(z2.Add(z3));
      
      Complex ex1 = z1.Add(z2);
      Complex ex2 = ex1.Add(z3);
      
      System.out.println("z1 + z2 = " + sum);
      System.out.println("z1 - z2 = " + diffrence);
      System.out.println("z1 * z2 = " + product);
      System.out.println("z1 / z2 = " + quotient);
       
      System.out.println("r + z2 = " + scalarSum);
      System.out.println("r - z2 = " + scalarDiffrence);
      System.out.println("r * z2 = " + scalarProduct);
      System.out.println("r / z1 = " + scalarQuotient);
      
      System.out.println("conjugate(z1) = " + conjugate);
      System.out.println("absolute(z1) = " + absolute);
      System.out.println("reciprocal(z1) = " + reciprocal);
     
      System.out.println("z1 + z2 + z3 = " + expression);
      System.out.println("(z1 + z2) + z3 = " + ex2);
      
  }
}
      