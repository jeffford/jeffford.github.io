 

//Kent Vasko
//MathOperations
//Lab4, problems 2-4
//February 6, 2006

import java.util.*;

public class Complex {

    public static void main (String[] args) {
        //declaring variables
        double z1, z2, x, y, u, v, s, t, r;
        
        //initializes input
        Scanner stdin = new Scanner(System.in);
        
        //prompts for the user
        System.out.println("This program calculates the answers for complex numbers.");
        System.out.println("The program will perform math functions on the complex numbers z1 and z2");
        System.out.println("The program will also perform math functions with complex and real numbers called scalar.");
        System.out.println("z1 = x + yi and z2 = u + vi");
        System.out.println("Please do not input zero for any of the variables.");
        System.out.println("Please enter a value for x:");
            x = stdin.nextDouble();
        System.out.println("Please enter a value for y:");
            y = stdin.nextDouble();
        System.out.println("Please enter a value for u:");
            u = stdin.nextDouble();
        System.out.println("Please enter a value for v:");
            v = stdin.nextDouble();
        System.out.println("Please enter a value for r:");
            r = stdin.nextDouble();
        
        //calls the methods
        Add(x, y, u, v);
        Subtract(x, y, u, v);
        Multiply(x, y, u, v);
        Divide(x, y, u, v);
        Conjugate(x, y);
        AbsoluteValue(x, y);
        Reciprocal(x, y);
        ScalarAdd(x, y, r);
        ScalarSubtract(x, y, r);
        ScalarMultiply(x, y, r);
        ScalarDivide(x, y, r);
        ComZero(x, y);
        MultiRecip(x, y);
    }

    //add operations
    public static void Add(double x, double y, double u, double v) {
         double addxu = x + u;
         double addyv = y + v;
         System.out.println("z1 + z2 = " + addxu + " + " + addyv + "i.");
     }

    //subtract operations
    public static void Subtract(double x, double y, double u, double v) {
         double subxu = x - u;
         double subyv = y - v;
         System.out.println("z1 - z2 = " + subxu + " + " + subyv + "i.");
     }

    //multiply operations
    public static void Multiply(double x, double y, double u, double v) {
         double mu1 = x*u - y*v;
         double mu2 = y*u + x*v;
         System.out.println("z1 * z2 = " + mu1 + " + " + mu2 + "i.");
     }

    //divide operations
    public static void Divide(double x, double y, double u, double v) {
         double div1 = (x*u + y*v)/(u*u + v*v);
         double div2 = (-x*v + y*u)/(u*u + v*v);
         System.out.println("z1/z2 equals " + div1 + " + " + div2 + "i.");
     }

    //conjugate
    public static void Conjugate(double x, double y) {
         System.out.println("The conjugate of x + yi = " + x + " - " + y + "i.");
     }

    //absolutevalue
    public static void AbsoluteValue(double x, double y) {
        double abs = x*x + y*y;
         System.out.println("The absolute value of x + yi = " + abs + ".");
     }

    //reciprocal
    public static void Reciprocal(double x, double y) {
         double rec1 = x/(x*x + y*y);
         double rec2 = -y/(x*x + y*y);
         System.out.println("The reciprocal value of x + yi = " + rec1 + " + " + rec2 + "i.");
     }

    //scalaradd
    public static void ScalarAdd(double x, double y, double r) {
        double addrx = r + x;
         System.out.println("r + z = " + addrx + " + " + y + "i.");
     }
     
    //scalarsubtract
    public static void ScalarSubtract(double x, double y, double r) {
        double subrx = r - x;
         System.out.println("r - z = " + subrx + " + " + y + "i.");
     }
     
    //scalarmultiply
    public static void ScalarMultiply(double x, double y, double r) {
        double mulrx = r * x;
        double mulry = r * y;
         System.out.println("r * z = " + mulrx + " + " + mulry + "i.");
     }
     
    //scalardivide
    public static void ScalarDivide(double x, double y, double r) {
        double divrx = r*x/(x*x + y*y);
        double divry = -r*y/(x*x + y*y);
         System.out.println("r/z = " + divrx + " + " + divry + "i.");
     }
     
     //complex number zero
     public static void ComZero(double x, double y) {
        double comx = x - x;
        double comy = y - y;
         System.out.println("The z1's additive inverse added to z1 equals " +
         "the complex number " + comx + " + " + comy + "i or 0.");
     }

     //multiplied by reciprocal
     public static void MultiRecip(double x, double y) {
        double mulre = (x + y) * (1/(x + y));
         System.out.println("z1 multiplied by its reciprocal is " + mulre + " + 0i or " + mulre + ".");
     }

}