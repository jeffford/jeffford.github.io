//import library for scanner class
import java.util.*;

public class Test{
public static void main(String args[]){
//get first complex nember
Complex first= new Complex();
    Scanner stdin = new Scanner(System.in);
        System.out.println("A complex number is defined as a number of the form  x + yi, where x and y are real numbers and i is a number such that i2 is -1.");
       
        System.out.println("Please enter the portion of the complex number that corresponds to x:");
            double x= stdin.nextDouble();
        
        System.out.println("Please enter the portion of the complex number that corresponds to y:");
            double y= stdin.nextDouble();
                first.setFirst(x);
                first.setSecond(y);
                
//get second complex number
Complex second= new Complex();
    
    System.out.println("Please enter the portion of the complex number that corresponds to x for a second Complex number:");
        double w= stdin.nextDouble();
    
    System.out.println("Please enter the portion of the complex number that corresponds to y for a second Complex number:");
        double t= stdin.nextDouble();
            second.setFirst(w);
            second.setSecond(t);
            
//get real number
    System.out.println("Please enter a real number that you wish to use for real number computations:");
        double z= stdin.nextDouble();
        
//do computations
     Complex testAdd= first.add(second);
     Complex testSubtract= first.subtract(second);
     Complex testMultiply = first.multiply(second);
     Complex testDivide=first.divide(second);
     Complex testConjugate=first.conjugate();
     Complex testABS=first.absoluteValue();
     Complex testReciprocal=first.reciprocal();
     Complex testScalarAdd=first.scalarAdd(z);
     Complex testScalarSubtract=first.scalarSubtract(z);
     Complex testScalarMultiply=first.scalarMultiply(z);
     Complex testScalarDivide=first.scalarDivide(z);
     boolean testEquality = first.equality(first,second);
     Complex testReciprocalMultiplication=first.multiply(testReciprocal);
//convert computations into strings for output
        String a = testAdd.toString();
        String b = testSubtract.toString();
        String k = testMultiply.toString();
        String c = testDivide.toString();
        String d = testConjugate.toString();
        String e = testABS.toStringABS();
        String f = testReciprocal.toString();
        String g = testScalarAdd.toString();
        String h = testScalarSubtract.toString();
        String i = testScalarMultiply.toString();
        String j = testScalarDivide.toString();
        String l = testReciprocalMultiplication.toString();
//output the results of the computations
        System.out.println("The result of the first and second complex numbers added is:");
            System.out.println(a);
        System.out.println("The result of the first and second complex numbers subtracted is:");
            System.out.println(b);
        System.out.println("The result of the first and second complex numbers multiplied is:");
            System.out.println(k);
        System.out.println("The result of the first and second complex numbers divided is:");
            System.out.println(c);
        System.out.println("The conjugate of the complex number is:");
            System.out.println(d);
        System.out.println("The absolute value of the first complex number is:");
            System.out.println(e);
        System.out.println("The reciprocal of the first complex number is:");
            System.out.println(f);
        System.out.println("The result of the first complex number added to the real number is:");
            System.out.println(g);
        System.out.println("The result of the first complex number with the real number subtracted is:");
            System.out.println(h);
        System.out.println("The result of the first complex number and the real number multiplied is:");
            System.out.println(i);
        System.out.println("The result of the first complex number with the real number divided into it is:");
            System.out.println(j); 
        System.out.print("It is ");
            System.out.print(testEquality);
            System.out.println(" that the first and second complex numbers are equal.");
        System.out.println("The result of the first compex number multiplied by it's reciprocal is:");
        System.out.println(testReciprocalMultiplication);
}
}
