//The purpose of this program is to support the use of complex numbers
//Written by Rebecca Fischer
public class Complex{

// instance variables
    double firstReal;
    double secondReal;

//default constructer Complex()
    public Complex(){
        firstReal = 1;
        secondReal = 1;
}
// setFirst() mutator
    public void setFirst( double n){
        firstReal = n;}

// setSecond() mutator
    public void setSecond( double n) {
        secondReal = n;}

// getFirst() accessor
    public double getFirst(){
        return firstReal;}

// getSecond() accessor
    public double getSecond(){
        return secondReal;
        }
//Add
    public Complex add(Complex x){
        Complex temp = new Complex();
        temp.setFirst(firstReal + x.getFirst());
        temp.setSecond(secondReal + x.getSecond());
        return temp;
        }

//Subtract
 public Complex subtract(Complex x){
        Complex temp = new Complex();
        temp.setFirst(firstReal - x.getFirst());
        temp.setSecond(secondReal - x.getSecond());
        return temp;
        }
//Multiply
public Complex multiply(Complex x){
        Complex temp = new Complex();
        temp.setFirst((firstReal * x.getFirst())-(secondReal * x.getSecond()));
        temp.setSecond((firstReal*x.getSecond())+(secondReal*x.getFirst()));
        return temp;
        }
//Divide
public Complex divide(Complex x){
        Complex temp = new Complex();
        temp.setFirst(((firstReal * x.getFirst())+(secondReal * x.getSecond()))/(x.getFirst()*x.getFirst() + x.getSecond()*x.getSecond()));
        temp.setSecond(((-1*firstReal * x.getSecond())+(secondReal*x.getFirst()))/(x.getFirst()*x.getFirst() + x.getSecond()*x.getSecond()));
        return temp;
        }
//Conjugate
public Complex conjugate(){
  Complex temp = new Complex();
  temp.setFirst(firstReal);
  temp.setSecond(-1*secondReal);
  return temp;
  }

//absoluteValue
  public Complex absoluteValue(){
    Complex temp = new Complex();
    temp.setFirst((firstReal*firstReal));
    temp.setSecond((secondReal*secondReal));
    return temp;
  }

//Reciprocal
  public Complex reciprocal(){
   Complex temp = new Complex();
   temp.setFirst(firstReal/((firstReal*firstReal)+(secondReal*secondReal)));
   temp.setSecond((-1*secondReal)/((firstReal*firstReal)+(secondReal*secondReal)));
   return temp;
 }

//scalarAdd
 public Complex scalarAdd(double y){
       Complex temp = new Complex();
       temp.setFirst(firstReal + y);
       temp.setSecond(secondReal);
       return temp;
 }
//scalarSubtract
 public Complex scalarSubtract(double y){
   Complex temp = new Complex();
   temp.setFirst(firstReal - y);
   temp.setSecond(secondReal);
   return temp;
 }
//scalarMultiply
 public Complex scalarMultiply(double y){
        Complex temp = new Complex();
        temp.setFirst(firstReal * y);
        temp.setSecond(secondReal* y);
        return temp;
        }

//scalarDivide
        public Complex scalarDivide(double y){
           Complex temp = new Complex();
           temp.setFirst((y*firstReal)/((firstReal*firstReal)+(secondReal*secondReal)));
           temp.setSecond((-1*y*secondReal)/((firstReal*firstReal)+(secondReal*secondReal)));
   return temp;
        }
//toString
    public String toString(){
       return "" + firstReal + "+" + secondReal+"i";
    }
// toString for ABS
    public String toStringABS(){
       return "" + firstReal + "+" + secondReal;
    }
//equality test
public boolean equality(Complex x, Complex y){
String a = x.toStringABS();
String b = y.toStringABS();
int equals=a.compareTo(b);
  if( equals==0){
  return true;}
  else{  
  return false;
    }
}
}
