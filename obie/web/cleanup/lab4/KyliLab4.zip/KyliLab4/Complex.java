//Purpose: To perform normal operations on complex numbers
//Author: Kyli Foltz        2/6/06


public class Complex {
    
        //instance variables to describe the object
        double real;
        double imaginary;
        
        //default constructor Complex()
            public Complex() {
                real = 1;
                imaginary = 1;
            }
                
        //setReal(): mutator
            public void setReal (double x) {
                    real = x;
                }
           
        //setImaginary(): mutator
            public void setImaginary (double y) {
                    imaginary = y;
                }
              
       //getReal(): accessor
            public double getReal() {
                return real;
            }
         
        //getImaginary(): accessor
             public double getImaginary() {
                 return imaginary;
             }
       //add (Complex z): add a complex number and z
             public Complex add (Complex z) {                
                 Complex temp = new Complex();
                 temp.setReal(real + z.getReal());
                 temp.setImaginary(imaginary + z.getImaginary());
                 return temp;
             }
             
       //subtract (Complex z): subtract a complex number and z
             public Complex subtract (Complex z) {
                 Complex temp = new Complex();
                 temp.setReal(real - z.getReal());
                 temp.setImaginary(imaginary - z.getImaginary());
                 return temp;
             }
       
       //multiply (Complex z): multiply a complex number and z
             public Complex multiply (Complex z) {
                 Complex temp = new Complex();
                 temp.setReal(real*z.getReal() - imaginary*z.getImaginary());
                 temp.setImaginary(imaginary*z.getReal() + real*z.getImaginary());
                 return temp;
             }
        
        //divide (Complex z): divide a complex number and z
             public Complex divide (Complex z) {
                 Complex temp = new Complex();
                 temp.setReal((real*z.getReal()+imaginary*z.getImaginary())/(z.getReal()*z.getReal()+z.getImaginary()*z.getImaginary()));
                 temp.setImaginary((-(real*z.getImaginary())+imaginary*z.getReal())/(z.getReal()*z.getReal()+z.getImaginary()+z.getImaginary()));
                 return temp;
             }
             
        //conjugate: compute the conjugate of a complex number
            public Complex conjugate () {
                 Complex temp = new Complex();
                 temp.setReal(real);
                 temp.setImaginary(-imaginary);
                 return temp;
             }
             
        //absolute: compute the absolute value of a complex number
            public Complex absolute () {
                 Complex temp = new Complex();
                 temp.setReal(Math.sqrt(real*real+imaginary*imaginary));
                 temp.setImaginary(0);
                 return temp;
             }
             
        //reciprocal: compute the reciprocal of a complex number
            public Complex reciprocal () {
                 Complex temp = new Complex();
                 temp.setReal((real/(real*real+imaginary*imaginary)));
                 temp.setImaginary((-imaginary)/(real*real+imaginary*imaginary));
                 return temp;
             }
        
        //additive inverse: compute the additive inverse of a complex number
            public Complex inverse () {
                Complex temp = new Complex ();
                temp.setReal(-real);
                temp.setImaginary(-imaginary);
                return temp;
            }
            
       //toString(): convert a complex number to a string suitable for output
            public String toString() {
                 return real + " + " + imaginary + "i";
             }
     }
 
