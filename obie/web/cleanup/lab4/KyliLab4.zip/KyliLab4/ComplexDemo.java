//Purpose: To test the Complex class
//Author: Kyli Foltz        2/8/06

import java.util.*;

public class ComplexDemo {
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        
        //extract values for the real and imaginary parts of a complex number
        Complex r = new Complex();
        System.out.print("Enter the real part of a complex number r: ");
        double a = stdin.nextDouble();
        System.out.print("Enter the imaginary part of a complex number r: ");
        double b = stdin.nextDouble();
        r.setReal(a);
        r.setImaginary(b);
        System.out.println();
        
        Complex s = new Complex();
        System.out.println("Enter the real part of a complex number s.");
        System.out.print("    This complex number should be non-zero: ");
        double c = stdin.nextDouble();
        System.out.print("Enter the imaginary part of a complex number s: ");
        double d = stdin.nextDouble();
        s.setReal(c);
        s.setImaginary(d);
        System.out.println();
        
        Complex t = new Complex();
        System.out.print("Enter the real part of a complex number t: ");
        double f = stdin.nextDouble();
        System.out.println("Enter the imaginary part of a complex number t.");
        System.out.print("    If you would like to perform scalar operations enter a 0: ");
        double g = stdin.nextDouble();
        t.setReal(f);
        t.setImaginary(g);
        System.out.println();
        
        //operate on r, s, and t
        Complex sum = r.add(s);
        Complex difference = r.subtract(s);
        Complex product = r.multiply(s);
        Complex quotient = r.divide(s);
        
        //test commutative property
        Complex expression = r.add(s.add(t));
        Complex ex1 = r.add(s);
        Complex ex2 = ex1.add(t);
        
        //operate on r
        Complex conjugate = r.conjugate();
        Complex absolutevalue = r.absolute();
        Complex reciprocal = r.reciprocal();
        Complex inverse = r.inverse();
        
        //test properties of complex numbers
        Complex additiveInverse = r.add(inverse);
        Complex multiplicativeInverse = r.multiply(reciprocal);
        
        //display operation results
        System.out.println("For r = " + r.toString() + " and s = " + s.toString() + " and t = " + t.toString());
        System.out.println("    r + s = " + sum.toString());
        System.out.println("    r - s = " + difference.toString());
        System.out.println("    r * s = " + product.toString());
        System.out.println("    r / s = " + quotient.toString());
        System.out.println();
        System.out.println("    The conjugate of r is " + conjugate.toString() + ".");
        System.out.println("    The absolute value of r is " + absolutevalue.toString() + ".");
        System.out.println("    The reciprocal of r is " + reciprocal.toString() + ".");
        System.out.println("    The additive inverse of r is " + inverse.toString() + ".");
        System.out.println();
        System.out.println("    r plus its additive inverse is " + additiveInverse.toString() + ".");
        System.out.println("    r multiplied by its reciprocal is " + multiplicativeInverse.toString() + ".");
        System.out.println("    r + (s + t) = " + expression + " and (r + s) + t = " + ex2 + ".");      
        
        if (g == 0) {
            System.out.println();
            Complex scalarAdd = t.add(s);
            Complex scalarSubtract = t.subtract(s);
            Complex scalarMultiply = t.multiply(s);
            Complex scalarDivide = t.divide(s);
            System.out.println("Scalar operations were requested.");
            System.out.println("    t + s = " + scalarAdd.toString());
            System.out.println("    t - s = " + scalarSubtract.toString());
            System.out.println("    t * s = " + scalarMultiply.toString());
            System.out.println("    t / s = " + scalarDivide.toString());
        }
        else {
            System.out.println();
            System.out.println("Scalar operations were not requested.");
        }
    }
}
        
        
        