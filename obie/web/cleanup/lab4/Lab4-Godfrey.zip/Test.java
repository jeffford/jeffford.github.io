import java.util.*;

public class Test {
    public static void main(String[] args) {

//setup scanner 
Scanner stdin = new Scanner(System.in);
System.out.println();

//input  for z1 
Complex z1 = new Complex();
System.out.print("Enter a value for real part of a complex z1 ;");
double real = stdin.nextDouble();
System.out.print("Enter a value for imaginary part of a complex z1 " + "number: ");
double imaginary = stdin.nextDouble();
z1.setReal(real);
z1.setImaginary(imaginary);
System.out.println();
System.out.println();

//input for z2
Complex z2 = new Complex();
System.out.print("Enter a value for real part of a complex z2 " + "number: ");
real = stdin.nextDouble();
System.out.print("Enter a value for imaginary part of a complex z2 " + "number: ");
imaginary = stdin.nextDouble();
z2.setReal(real);
z2.setImaginary(imaginary);
System.out.println();
System.out.println();

//input a real r
System.out.print("Enter a value for real part r " + "number: ");
double r = stdin.nextDouble();
System.out.println();



//perform operations on z1 and z2
Complex sum = z1.add(z2);
Complex difference = z1.subtract(z2);
Complex product = z1.multiply(z2);
Complex divide = z1.divide(z2);
Complex absolute = z1.absolute();
Complex reciprocal = z1.reciprocal();
Complex conjugate = z1.conjugate();
Complex scalarAdd = z1.scalarAdd(r);
Complex scalarSubtract = z1.scalarSubtract(r);
Complex scalarMulitply = z1.scalarMulitply(r);
Complex scalarDivide = z1.scalarDivide(r);




//display operation results
System.out.println("For z1 = " + z1.toString() + " and z2 =" + z2.toString());
System.out.println("z1 + z2 = " +     sum.toString());
System.out.println("z1 - z2 = " +     difference.toString());
System.out.println("z1 * z2 = " +     product.toString());
System.out.println("z1  = " +     absolute.toString());
System.out.println("z1  = " +     reciprocal.toString());
System.out.println("z1  = " +     conjugate.toString());
System.out.println("r + z1  = " +     scalarAdd.toString());
System.out.println("r - z1 = " +     scalarSubtract.toString());
System.out.println("r * z1 = " +     scalarMulitply.toString());
System.out.println("r / z1 = " +     scalarDivide.toString());




System.out.println();
}
}  