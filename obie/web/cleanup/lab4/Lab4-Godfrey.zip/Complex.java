//The purpose of this program is to support the use of complex numbers

public class Complex{
       
// instance variables
    double Real;
    double Imaginary;

   

//default constructer Complex()
    public Complex(){
        Real = 1;
        Imaginary = 1;
        
}
// setFirst() mutator
    public void setReal( double n){
        Real = n;}
// setFirst() mutator
    public void setImaginary( double n){
        Imaginary = n;}        
       
     

// getFirst() accessor
    public double getReal(){
        return Real;} 
       
// getSecond() accessor
    public double getImaginary(){
        return Imaginary;}
        
//Add        
    public Complex add(Complex x){
        Complex temp = new Complex();
        temp.setReal(Real + x.getReal());
        temp.setImaginary(Imaginary + x.getImaginary());
        return temp;
        }

//Subtract
 public Complex subtract(Complex x){
        Complex temp = new Complex();
        temp.setReal(Real - x.getReal());
        temp.setImaginary(Imaginary - x.getImaginary());
        return temp;
        }
//Multiply
public Complex multiply(Complex x){
        Complex temp = new Complex();
        temp.setReal(Real * x.getReal());
        temp.setImaginary(Imaginary * x.getImaginary());
        return temp;
        }
//Divide
public Complex divide(Complex x){
        Complex temp = new Complex();
        temp.setReal(Real / x.getReal());
        temp.setImaginary(Imaginary / x.getImaginary());
        return temp;
        }
//conjugate 
public Complex conjugate(){
        Complex temp = new Complex();
        temp.setReal(Real);
        temp.setImaginary(-Imaginary);
        return temp;
        }
//absolute
public Complex absolute(){
        Complex temp = new Complex();
        temp.setReal(Real * Real);
        temp.setImaginary(Imaginary * Imaginary);
        return temp;
        }
//reciprocal
public Complex reciprocal(){
        Complex temp = new Complex();
        temp.setReal(Real / (Real * Real) + (Imaginary * Imaginary));
        temp.setImaginary(Imaginary / (Real * Real) + (Imaginary * Imaginary));
        return temp;
        }
//scalarAdd
public Complex scalarAdd(double r){ 
        Complex temp = new Complex();
        temp.setReal(r + Real);
        temp.setImaginary(Imaginary);
        return temp;
        }  
//scalarSubtract
public Complex scalarSubtract (double r){ 
        Complex temp = new Complex();
        temp.setReal(r - Real);
        temp.setImaginary(Imaginary);
        return temp;
        } 
//scalarMultiply
public Complex scalarMulitply (double r){ 
        Complex temp = new Complex();
        temp.setReal(r * Real);
        temp.setImaginary(r * Imaginary);
        return temp;
        } 
//scalarDivide
public Complex scalarDivide(double r){
        Complex temp = new Complex();
        temp.setReal(r * Real / (Real * Real) + (Imaginary * Imaginary));
        temp.setImaginary(r * Imaginary / (Real * Real) + (Imaginary * Imaginary));
        return temp;
        }

    public String toString(){
          return "" + Real + "+" + Imaginary + " i ";
    }
}


