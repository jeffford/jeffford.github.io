// Author: Sayuri Ichida
// the date completed: 2/12/2006
// the date submitted: 2/13/2006
// Lab 4, question 2 (4.2)
// Purpose: support the use of complex numbers

public class Complex
{
  // instance variables to describe object attributes
  double real;             // real part of an imaginary number
  double img;              // imaginary part of an imaginary number

  // Complex(): default constructor
  public Complex() {
    real = 1.0;       // initialize the real to be 1.0
    img = 1.0;        // initialize the img to be 1.0
  }

  // setReal(): real mutator
  public void setReal(double r) {
      real = r;
  }
  
  // setImg(): img mutator
  public void setImg(double i) {
      img = i;
  }
  
  // getReal(): real accessor
  public double getReal() {
    return real;
  }
  
  // getImg(): img accessor
  public double getImg() {
    return img;
  }

  // Add (Complex x): add a complex number and x
  public Complex Add (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real + x.getReal());
    temp.setImg(img + x.getImg());
    return temp;
  }

  // Subtract (Complex x): subtract a complex number and x
  public Complex Subtract (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real - x.getReal());
    temp.setImg(img - x.getImg());
    return temp;
  }

  // Multiply (Complex x): multiply a complex number and x
  public Complex Multiply (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real * x.getReal() - img * x.getImg());
    temp.setImg(img * x.getReal() + real * x.getImg());
    return temp;
  }

  // Divide (Complex x): divide a complex number and x
  public Complex Divide (Complex x) {
    Complex temp = new Complex();
    temp.setReal((real * x.getReal() + img * x.getImg())
                                  / (x.getReal() * x.getReal() + x.getImg() * x.getImg()));
    temp.setImg((-real * x.getImg() + img * x.getReal())
                                  / (x.getReal() * x.getReal() + x.getImg() * x.getImg()));
    return temp;
  }
  
  // Conjugate (): provide the conjugate of the complex number
  public Complex Conjugate () {
      Complex temp = new Complex();
      temp.setReal(real);
      temp.setImg(-img);
      return temp;
  }
  
  // AbsoluteValue (Complex): provide the magnitude of the complex number
  public double AbsoluteValue () {
      return Math.sqrt (real*real + img*img);
  }
  
  // Reciprocal (): provide the reciprocal of the complex number
  public Complex Reciprocal () {
      Complex temp = new Complex();
      temp.setReal(real / (real * real + img * img));
      temp.setImg(-img / (real * real + img * img));
      return temp;
  }
  
  // scalarAdd (Complex x): add a real number r and x
  public Complex scalarAdd (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real + x.getReal());
    temp.setImg(x.getImg());
    return temp;
  }

  // scalarSubtract (Complex x): subtract a real number r and x
  public Complex scalarSubtract (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real - x.getReal());
    temp.setImg(x.getImg());
    return temp;
  }

  // scalarMultiply (Complex x): multiply a real number r and x
  public Complex scalarMultiply (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real * x.getReal());
    temp.setImg(real * x.getImg());
    return temp;
  }

  // scalarDivide (Complex x): divide a real number r and x
  public Complex scalarDivide (Complex x) {
    Complex temp = new Complex();
    temp.setReal(real * x.getReal() / (x.getReal() * x.getReal() + x.getImg() * x.getImg()));
    temp.setImg(-real * x.getImg() / (x.getReal() * x.getReal() + x.getImg() * x.getImg()));
    return temp;
  }
  
  // toString(): convert a complex number to a string suitable for output
  public String toString () {
    return real + " + "  + "(" + img + ")" + "i";
  }

} 
