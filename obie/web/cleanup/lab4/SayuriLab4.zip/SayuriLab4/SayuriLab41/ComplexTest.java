// Author: Sayuri Ichida
// the date completed: 2/12/2006
// the date submitted: 2/13/2006
// Lab 4, question 3 (4.3)
// Purpose: demonstrate use of Complex class

import java.util.*;

public class ComplexTest {
  // main(): application entry point
  public static void main (String [] args) {
      
    // setup scanner
    Scanner stdin = new Scanner(System.in);
    System.out.println();
    
    // input values for real part and imaginary part
    // of complex number z1 and set its variables
    Complex z1 = new Complex();
    Complex AdditiveInverseZ1 = new Complex();
    System.out.print("Enter a real part of an imaginary number: ");
    double a = stdin.nextDouble();
    
    System.out.print("Enter an imaginary part of an imaginary number: ");
    double b = stdin.nextDouble();
    
    z1.setReal(a);
    z1.setImg(b);
    
    AdditiveInverseZ1.setReal(-a);
    AdditiveInverseZ1.setImg(-b);
    
    System.out.println();
    
    // input values for real part and imaginary part
    // of complex number z2 and set its variables
    Complex z2 = new Complex();
    System.out.print("Enter a real part of an imaginary number: ");
    double c = stdin.nextDouble();
    
    System.out.print("Enter an imaginary part of an imaginary number: ");
    double d = stdin.nextDouble();
    
    z2.setReal(c);
    z2.setImg(d);
    
    System.out.println();
    
    // input values for real part and imaginary part
    // of complex number z3 and set its variables
    Complex z3 = new Complex();
    System.out.print("Enter a real part of an imaginary number: ");
    double e = stdin.nextDouble();
    
    System.out.print("Enter an imaginary part of an imaginary number: ");
    double f = stdin.nextDouble();
    
    z3.setReal(e);
    z3.setImg(f);
    
    System.out.println();
    
    // input a value for real number r and set its variables
    Complex r = new Complex();
    System.out.print("Enter a real number: ");
    double g = stdin.nextDouble();
    
    r.setReal(g);
    r.setImg(0.0);
    
    System.out.println();
    
    // perform operations on z1 and z2
    Complex sum = z1.Add(z2);
    Complex difference = z1.Subtract(z2);
    Complex product = z1.Multiply(z2);
    Complex quotient = z1.Divide(z2);
    Complex c1 = z1.Conjugate();
    double magnitude1 = z1.AbsoluteValue();
    Complex r1 = z1.Reciprocal();
    Complex c2 = z2.Conjugate();
    double magnitude2 = z2.AbsoluteValue();
    Complex r2 = z2.Reciprocal();
    
    // perform operations on z1, z2, and z3
    Complex expression = z1.Add(z2.Add(z3));         // Add
    Complex ex1 = z1.Add(z2);
    Complex ex2 = ex1.Add(z3);
    
    Complex dif = z1.Subtract(z2).Subtract(z3);     // Subtract
    Complex di1 = z1.Subtract(z2);
    Complex di2 = di1.Subtract(z3);
    
    Complex pro = z1.Multiply(z2).Multiply(z3);     // Multiply
    Complex pro1 = z1.Multiply(z2);
    Complex pro2 = pro1.Multiply(z3);
    
    Complex quo = z1.Divide(z2).Divide(z3);     // Divide
    Complex quo1 = z1.Divide(z2);
    Complex quo2 = quo1.Divide(z3);
    
     // perform operations on r and z1
    Complex scalarsum = r.scalarAdd(z1);
    Complex scalardifference = r.scalarSubtract(z1);
    Complex scalarproduct = r.scalarMultiply(z1);
    Complex scalarquotient = r.scalarDivide(z1);
    
    // question #4 in lab manual
    Complex test1 = z1.Add(AdditiveInverseZ1);
    Complex test2 = z1.Multiply(r1);
    
    // display operation results for z1 and z2
    System.out.println("For z1 = " + z1.toString() + " and z2 = " + z2.toString());
    System.out.println("    z1 + z2 = " + sum.toString());
    System.out.println("    z1 - z2 = " + difference.toString());
    System.out.println("    z1 * z2 = " + product.toString());
    System.out.println("    z1 / z2 = " + quotient.toString());
    System.out.println("    The conjugate of z1 = " + c1.toString());
    System.out.println("    The absolute value of z1 = " + magnitude1);
    System.out.println("    The reciprocal of z1 = " + r1.toString());
    System.out.println("    The conjugate of z2 = " + c2.toString());
    System.out.println("    The absolute value of z2 = " + magnitude2);
    System.out.println("    The reciprocal of z2 = " + r2.toString());
    System.out.println();
    System.out.println("    Lab manual #4");
    System.out.println("    z1 + (additive inverse of z1, " + AdditiveInverseZ1.toString() + ") = " + test1.toString());
    System.out.println("    z1 * (reciprocal of z1, " + r1.toString() + ") = " + test2.toString());
    System.out.println();
    
    // display operation results for z1, z2, and z3
    System.out.println("For z1 = " + z1.toString() + ", z2 = " + z2.toString()
                                                     + " and z3 = " + z3.toString());
    System.out.println("    By using z1.Add(z2.Add(z3): z1 + z2 + z3 = " + expression.toString());
    System.out.println("    By using z1.Add(z2): z1 + z2 = " + ex1.toString());
    System.out.println("    By using ex1.Add(z3); z1 + z2 + z3 = " + ex2.toString());
    System.out.println();
    System.out.println("    By using z1.Subtract(z2).Subtract(z3): z1 - z2 - z3 = " + dif.toString());
    System.out.println("    By using z1.Subtract(z2): z1 - z2 = " + di1.toString());
    System.out.println("    By using di1.Subtract(z3); z1 + z2 + z3 = " + di2.toString());
    System.out.println();
    System.out.println("    By using z1.Multiply(z2).Multiply(z3): z1 * z2 * z3 = " + pro.toString());
    System.out.println("    By using z1.Multiply(z2): z1 * z2 = " + pro1.toString());
    System.out.println("    By using pro1.Multiply(z3); z1 * z2 * z3 = " + pro2.toString());
    System.out.println();
    System.out.println("    By using z1.Dividet(z2).Divide(z3): z1 / z2 / z3 = " + quo.toString());
    System.out.println("    By using z1.Divide(z2): z1 / z2 = " + quo1.toString());
    System.out.println("    By using quo1.Divide(z3); z1 / z2 / z3 = " + quo2.toString());
    System.out.println();
    
    // display operation results for z1 and r
    System.out.println("For imaginary number z1 = " + z1.toString() + " and real number r = " + r.toString());
    System.out.println("    r + z1 = " + scalarsum.toString());
    System.out.println("    r - z1 = " + scalardifference.toString());
    System.out.println("    r * z1 = " + scalarproduct.toString());
    System.out.println("    r / z1 = " + scalarquotient.toString());
    
    System.out.println();
    }
}

