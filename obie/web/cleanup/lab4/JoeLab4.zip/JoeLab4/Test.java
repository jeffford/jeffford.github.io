//Author:  Joe Moeller
//Purpose:  To allow user input for 3 complex numbers
//z1, z2, and z3, along with input r to output the result of 
//the inputs after put through a series of functions.  

import java.util.*;

public class Test {
    public static void main(String[] args) {
    //creation of new Complex classes    
    Complex z1 = new Complex ();
    Complex z2 = new Complex ();
    Complex z3 = new Complex ();
    Complex s = new Complex ();

    //Print statements accept a value for specified input,
    //and set it to the value in the Complex class so we can call it later
    Scanner stdin = new Scanner(System.in);
    System.out.print("Input a value for r for the scalars: ");
    double r = stdin.nextDouble();
    s.setReal(r);
    
    System.out.println("Input for z1");
    System.out.print("  Input a value for x: ");
    double x = stdin.nextDouble();
    z1.setFirst(x);
    
    
    System.out.print("  Input a value for y: ");
    double y = stdin.nextDouble();
    z1.setSecond(y);
    

    System.out.println("Input for z2");
    System.out.print("  Input a value for u: ");
    double u = stdin.nextDouble();
    z2.setFirst(u);
    
    System.out.print("  Input a value for v: ");
    double v = stdin.nextDouble();
    z2.setSecond(v);
    
    System.out.println("Input for z3");
    System.out.print("  Input a value for a: ");
    double a = stdin.nextDouble();
    z3.setFirst(a);
    
    System.out.print("  Input a value for b: ");
    double b = stdin.nextDouble();
    z3.setSecond(b);
    
    //operations on z1 and z2
    Complex sum = z1.sum(z2);
    Complex difference = z1.difference(z2);
    Complex product = z1.multiply(z2);
    Complex quotient = z1.divide(z2);
    
    //scalar operations between r and z1
    Complex scalarAdd = z1.scalarAdd(r);
    Complex scalarSubtract = z1.scalarSubtract(r);
    Complex scalarMultiply = z1.scalarMultiply(r);
    Complex scalarDivide = z1.scalarDivide(r);
    
    //Complex expression of z1 + z2 + z3
    Complex expression = z1.sum(z2.sum(z3));
    
    //Other useful functions on complex number z1
    Complex conjugate = z1.conjugate(z1);
    Complex absoluteValue = z1.absoluteValue(z1);
    Complex reciprocal = z1.reciprocal(z1);
    
    //final 2 functions 
    Complex additiveInverse = z1.additiveInverse(z1);
    Complex nonZeroMultiply = z1.nonZeroMultiply(z1);
    
    //display the operation results
    System.out.println("For z1 = " + z1.toString() + " and z2 = " + z2.toString());
    System.out.println("     z1 + z2 = " + sum.toString());
    System.out.println("     z1 - z2 = " + difference.toString());
    System.out.println("     z1 * z2 = " + product.toString());
    System.out.println("     z1 / z2 = " + quotient.toString());
    System.out.println();
    
    //output for 3 other useful operations
    System.out.println("Other useful operations: ");
    System.out.println("     The Conjugate of z1 is: " + conjugate);
    System.out.println("     The absolute value of z1 is: " + absoluteValue);
    System.out.println("     The reciprocal of z1 is: " + reciprocal.toString());
    System.out.println();
    //Output for the scalar equations
    System.out.println("Scalars (Operations between complex and real numbers)");
    System.out.println("     scalarAdd (r + z1) = " + scalarAdd.scalarToString());
    System.out.println("     scalarSubtract (r - z1) = " + scalarSubtract.scalarToString());
    System.out.println("     scalarMultiply (r * z1) = " + scalarMultiply.scalarToString());
    System.out.println("     scalarDivide (r / z1) = " + scalarDivide.scalarToString());
    System.out.println();
    //Complex expression z1 + z2 + z3
    System.out.println("Complex expressions: ");
    System.out.println("     expression z1 + z2 + z3: " + expression);
    System.out.println();
    //Output for the two final functions 
    System.out.println("Complex number z1 added to its additive inverse is: " + additiveInverse.toString());
    System.out.println("Non-zero complex number z1 multiplied by its reciprocal equals the complex number 1: " + nonZeroMultiply.toString());
}
}