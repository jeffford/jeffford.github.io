//Author: Joe Moeller
//Purpose:  To take input and run it through the given equations and 
//functions.  
import java.util.*;

public class Complex {
    
    //initiation of variables
    double x, y, r, i;
    
    //Instance variables are given a default value
    public Complex(){
        x = 1;
        y = 1;
        r = 1;
        i = 1;
}

    //Mutators and accessors are placed for the 
    //variables to make them available in the test main().
    public void setFirst( double first) {
        x = first;}
    
    public double getFirst(){
        return x;}
        
    public void setSecond( double second) {
        y = second;}
        
    public double getSecond(){
        return y;}
        
    public void setReal (double real) {
        r = real;}
        
    public double getReal() {
        return r;}
     
    public void setImag( double img){
        i = img;}
    
    public double getImag() {
        return i;}
        

   //Methods of different operations are created to be called upon by the main program     
   public Complex sum (Complex a) {
       Complex temp = new Complex();
       temp.setFirst(a.getFirst() + x);
       temp.setSecond(a.getSecond() + y);
       return temp;
   }
   
   public Complex scalarAdd (double a) {
       Complex temp = new Complex();    //constructor
       temp.setReal(a + x);
       temp.setImag(y);
       return temp;
    }
   
   public Complex difference (Complex a) {
       Complex temp = new Complex();  //constructor
       temp.setFirst(x - a.getFirst());
       temp.setSecond(y - a.getSecond());
       return temp; 
   }
   
   public Complex scalarSubtract (double a) {
       Complex temp = new Complex();  //constructor
       temp.setReal(a - x);
       temp.setImag(y);
       return temp;
    }

   public Complex multiply (Complex a) {
       Complex temp = new Complex();  //constructor
       temp.setFirst(x * a.getFirst() - y * a.getSecond());
       temp.setSecond(y * a.getFirst() + x * a.getSecond());
       return temp;
   }
   
   public Complex scalarMultiply (double a) {
       Complex temp = new Complex();  //constructor
       temp.setReal(a * x);
       temp.setImag(a * y);
       return temp;
    }
    
   public Complex divide (Complex a) {
       Complex temp = new Complex();  //constructor
       temp.setFirst((x * a.getFirst() + y * a.getSecond()) / (a.getFirst() * a.getFirst() + a.getSecond() * a.getSecond()));
       temp.setSecond((-x * a.getSecond() + y * a.getFirst()) / (a.getFirst() * a.getFirst() + a.getSecond() * a.getSecond()));
       return temp;
   }
   
   public Complex scalarDivide (double a) {
       Complex temp = new Complex();  //constructor
       temp.setReal(a * x / (x * x + y * y));
       temp.setImag(-a * y / (x * x + y * y));
       return temp;
    }
    public Complex conjugate (Complex a) {
        Complex temp = new Complex();  //constructor
        temp.setFirst(a.getFirst());
        temp.setSecond(- a.getSecond());
        return temp;
    }
    public Complex absoluteValue (Complex a) {
        Complex temp = new Complex();  //constructor
        temp.setFirst(a.getFirst() * a.getFirst());
        temp.setSecond(a.getSecond() * a.getSecond());
        return temp;
    }
    public Complex reciprocal (Complex a) {
        Complex temp = new Complex();  //constructor
        temp.setFirst(a.getFirst() / (a.getFirst() * a.getFirst() + a.getSecond() * a.getSecond()));
        temp.setSecond(- a.getSecond() / (a.getFirst() * a.getFirst() + a.getSecond() * a.getSecond()));
        return temp;
    }
   
   
   public Complex additiveInverse (Complex a) {
       Complex temp = new Complex();  //constructor
       temp.setFirst(x - x);
       temp.setSecond(y - y);
       return temp;
    }
    
    public Complex nonZeroMultiply (Complex a) {
        Complex temp = new Complex();   //constructor
        temp.setFirst(x / ((x * x) + (y * y)));
        temp.setSecond(- y / ((x * x) + (y * y)));
        return temp;
    }
   
    //allow the complex numbers to be put together by a string so they
   //can be ready to be output.
   public String toString() {
       String temp =  x + " + " + y + "i" ;
       return temp;
    }
   //Allow the scalar numbers to be printed properly, by calling 
   //the methods set equal to r and i
   public String scalarToString() {
       String temp =  r + " + " + i + "i";
       return temp;
   }
   }
   



