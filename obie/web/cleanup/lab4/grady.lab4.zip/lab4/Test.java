// Kris Grady
// Febuary 12, 2006
// Test for lab 4.  Calls the methods of the Complex class.


import java.util.*;

public class Test {
    public static void main (String[] args){


        // initialize input
        Scanner stdin = new Scanner(System.in);

        // double
        double x, y, u, v, r;

        // collect input variables
        System.out.print("The value of x is:");
        x = stdin.nextDouble();
        System.out.print("The value of y is:");
        y = stdin.nextDouble();
        System.out.print("The value of u is:");
        u = stdin.nextDouble();
        System.out.print("The value of v is:");
        v = stdin.nextDouble();
        System.out.print("The value of r is:");
        r = stdin.nextDouble();

        // call add
        Complex addition = new Complex();
        addition.add(x, y, v, u);
        
        // call subtract
        Complex subtraction = new Complex();
        subtraction.subtract(x, y, v, u);
        
        // call multiply
        Complex multiplication = new Complex();
        multiplication.multiply(x, y, v, u);
        
        // call divide
        Complex division = new Complex();
        division.divide(x, y, v, u);
        
        // call conjuagate
        Complex conjuagation = new Complex();
        conjuagation.conjuagate(x, y);
        
        // call absolute
        Complex absoluteValue = new Complex();
        absoluteValue.absolute(x, y);
        
        // call reciprocal
        Complex reciprocation = new Complex();
        reciprocation.reciprocal(x, y);
        
        
        // call scalarAdd
        Complex scalarAddition = new Complex();
        scalarAddition.scalarAdd(x, y, r);
        
        // call scalarSubtract
        Complex scalarSubtraction = new Complex();
        scalarAddition.scalarSubtract(x, y, r);
        
        // call scalarMultiply
        Complex scalarMultiplication = new Complex();
        scalarMultiplication.scalarMultiply(x, y, r);
        
        // call scalarDivide
        Complex scalarDivision = new Complex();
        scalarDivision.scalarDivide(x, y, r);
        
        
        
    }
}