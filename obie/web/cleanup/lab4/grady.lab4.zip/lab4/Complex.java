// Kris Grady
// Febuary 12, 2006
// program for lab 4.  Performing math functions.

import java.util.*;

public class Complex {
    public Complex() {
        
        // declare varialbes
        double z, x, y, u, v, r;   
    }
    
        // add operation
        public void add (double x, double y, double v, double u)
        {
        double addz1 = x + y;
        double addz2 = u + v;
        System.out.println("The output for adding Z1 and Z2 is: " + addz1 + " + " + addz1 + "i");
    }
    
        // subtract operation
        public void subtract (double x, double y, double v, double u)
        {
        double subz1 = x - y;
        double subz2 = u - v;
        System.out.println("The output for subtracting Z1 and Z2 is: " + subz1 + " - " + subz2 + "i");
    }
    
        // multiply operation
        public void multiply (double x, double y, double v, double u)
        {
        double mulz1 = (x * u) - (y * v);
        double mulz2 = (y * u) - (x * v);
        System.out.println("The output for multipling Z1 and Z2 is: " + mulz1 + " * " + mulz2 + "i");
    }
    
        // divide operation
        public void divide (double x, double y, double v, double u)
        {
        double divz1 = ((x * u) + (y * v)) / ((u * u) + (v * v));
        double divz2 = ((-x * u) + (y * u)) / ((u * u) + (v * v));
        System.out.println("The output for divideing Z1 and Z2 is: " + divz1 + " / " + divz2 + "i");
    }
    
        // conjuagate operation
        public void conjuagate (double x, double y)
        {
        double conx = x;
        double cony = y;
        System.out.println("The conjuagate x + yi is: " + conx + " - " + cony + "i");
    }
        
        // absolute value operation
        public void absolute (double x, double y)
        {
        double abx = x * x;
        double aby = y * y;
        System.out.println("The absolute value x + yi is: " + abx + " + " + aby + "i");
    }
    
        // reciprocal operation
        public void reciprocal (double x, double y)
        {
        double recx = (x) / ((x * x) + (y * y));
        double recy = (- y) / ((x * x) + (y * y));
        System.out.println("The reciprocal x + yi is: " + recx + " + " + recy + "i");
    }
    
        // scalarAdd operation
        public void scalarAdd (double x, double y, double r)
        {
        double saddr = (r + x);
        double saddz = y;
        System.out.println("The scalar add r + z is: " + saddr + " + " + saddz + "i");
    }
    
        // scalarSubtract operation
        public void scalarSubtract (double x, double y, double r)
        {
        double ssubr = (r - x);
        double ssubz = y;
        System.out.println("The scalar subtract r - z is: " + ssubr + " - " + ssubz + "i");
    }
    
        // scalarMultiply operation
        public void scalarMultiply (double x, double y, double r)
        {
        double smulr = r * x;
        double smulz = r * y;
        System.out.println("The scalar multiply r * z is: " + smulr + " * " + smulz + "i");
    }
    
        // scalarDivide operation
        public void scalarDivide (double x, double y, double r)
        {
        double sdivr = (r * x) / ((x * x) + (y * y));
        double sdivz = (- r * x) / ((x * x) + (y * y));
        System.out.println("The scalar divide r / z is: " + sdivr + " / " + sdivz + "i");
        
    }
}