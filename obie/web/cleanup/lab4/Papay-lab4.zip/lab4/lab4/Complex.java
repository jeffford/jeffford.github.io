
/**
 * This class operates on complex numbers 
 * @author (Ty Papay) 
 * 
 */
import java.util.*;

public class Complex
{
    public static double x,y,u,v,r;
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        System.out.print("Enter z1 = x+yi where x= ");
        x = stdin.nextDouble();
        System.out.print("and y= ");
        y = stdin.nextDouble();
        System.out.print("And enter z2 = u+vi where u= ");
        u = stdin.nextDouble();
        System.out.print("and v= ");
        v = stdin.nextDouble();
        System.out.print("and a scalar r= ");
        r = stdin.nextDouble();
        if(y<0)
            System.out.println("\nz1="+ x + y +"i");
        else
            System.out.println("\nz1="+ x +"+"+ y +"i");
        if(v<0)
            System.out.println("z2="+ u + v +"i\n");
        else
            System.out.println("z2="+ u +"+"+ v +"i\n");
        
        
                
        complexAdd();
        complexSub();
        complexMult();
        complexDiv();
        conjugate();
        absoluteValue();
        reciprical();
        scalarAdd();
        scalarSubtract();
        scalarMultiply();
        scalarDivide();
    }

    public static void complexAdd() {
        double a = x+u;
        double b = y+v;
        if(b<0)
            System.out.println("z1+z2="+ a + b +"i");
        else
            System.out.println("z1+z2="+ a +"+"+ b +"i");
    }
    
    public static void complexSub() {
        double a = x-u;
        double b = y-v;
        if(b<0)
            System.out.println("z1-z2="+ a + b +"i");
        else
            System.out.println("z1-z2="+ a +"+"+ b +"i");
    }
    public static void complexMult() {
        double a = (x*u - y*v);
        double b = (y*u + x*v);
        if(b<0)
            System.out.println("z1*z2="+ a + b +"i");
        else
            System.out.println("z1*z2="+ a +"+"+ b +"i");
    }
     public static void complexDiv() {
        double a = (x*u + y*v)/( u*u + v*v);
        double b = (-x*v + y*u)/(u*u + v*v);
        if(b<0)
            System.out.println("z1/z2="+ a + b +"i");
        else
            System.out.println("z1/z2="+ a +"+"+ b +"i");
    }
    public static void conjugate() {
        double a = -y;
        double b = -v;
        if(a<0)
            System.out.println("z1*="+ x + a +"i");
        else
            System.out.println("z1*="+ x +"+"+ a +"i");
        if(b<0)
            System.out.println("z2*="+ u + b +"i\n");
        else
            System.out.println("z2*="+ u +"+"+ b +"i\n");
    }
    public static void absoluteValue() {
        double a = x*x;
        double b = y*y;
        double c = u*u;
        double d = v*v;
        System.out.println("|z1|="+ a +"+"+ b);
        System.out.println("|z2|="+ c +"+"+ d);
    }
    public static void reciprical() {
        double a = x/((x*x)+(y*y));
        double b = -y/((x*x)+(y*y));
        double c = u/((u*u)+(v*v));
        double d = -v/((u*u)+(v*v));
        if(b<0)
            System.out.println("1/z1*="+ a + b +"i");
        else
            System.out.println("1/z1*="+ a +"+"+ b +"i");
        if(d<0)
            System.out.println("1/z2*="+ c + d +"i\n");
        else
            System.out.println("1/z2*="+ c +"+"+ d +"i\n");
     }
   public static void scalarAdd(){
       double a = r+x;
       double b = r+u;
       if(y<0)
            System.out.println("\nr+z1="+ a + y +"i");
        else
            System.out.println("\nr+z1="+ a +"+"+ y +"i");
        if(v<0)
            System.out.println("r+z2="+ b + v +"i\n");
        else
            System.out.println("r+z2="+ b +"+"+ v +"i\n");
    }  
    public static void scalarSubtract(){
       double a = r-x;
       double b = r-u;
       if(y<0)
            System.out.println("r-z1="+ a + y +"i");
        else
            System.out.println("r-z1="+ a +"+"+ y +"i");
        if(v<0)
            System.out.println("r-z2="+ b + v +"i\n");
        else
            System.out.println("r-z2="+ b +"+"+ v +"i\n");
    }   
    public static void scalarMultiply(){
        double a = r*x;
        double b = r*y;
        double c = r*u;
        double d = r*v;
        if(b<0)
            System.out.println("r*z1="+ a + b +"i");
        else
            System.out.println("r*z1="+ a +"+"+ b +"i");
        if(d<0)
            System.out.println("r*z2="+ c + d +"i\n");
        else
            System.out.println("r*z2="+ c +"+"+ d +"i\n");
   }
   public static void scalarDivide(){
       double a = (r*x)/(x*x + y*y);
       double b = (-r*y)/(x*x + y*y);
       double c = (r*u)/(u*u + v*v);
       double d = (-r*v)/(u*u + v*v);
       if(b<0)
            System.out.println("r/z1="+ a + b +"i");
        else
            System.out.println("r/z1="+ a +"+"+ b +"i");
        if(d<0)
            System.out.println("r/z2="+ c + d +"i\n");
        else
            System.out.println("r/z2="+ c +"+"+ d +"i\n");
   }
}

