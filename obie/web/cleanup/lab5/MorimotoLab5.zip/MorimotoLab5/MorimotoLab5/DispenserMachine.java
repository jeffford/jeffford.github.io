public class DispenserMachine{

  //instance variable tp describe the objext
    private int TotalCoke;
    private int TotalFanta;
    private int TotalSprite;
    private int TotalWater;
    private int TotalDietCoke;
    
    private int TotalMoney;
    private int ChangeNickel;
    private int ChangeDime;
    private int ChangeQuarter;
    
    final int NICKEL = 5;
    final int DIME = 10;
    final int QUARTER = 25;
    
  //default constructer CokeMachine()
    public DispenserMachine(){
         TotalCoke = 0;
         TotalSprite = 0;
         TotalFanta = 0;
         TotalWater = 0;
         TotalDietCoke = 0;
         
         TotalMoney = 0;
         ChangeNickel = 0;
         ChangeDime = 0;
         ChangeQuarter = 0;
     }
     
  //setCan():mutator
    public void setCoke(int x){
        TotalCoke = x;
    }

  //setCan():mutator
    public void setSprite(int x){
        TotalSprite = x;
    }

  //setCan():mutator
    public void setFanta(int x){
        TotalFanta = x;
    }

  //setCan():mutator
    public void setWater(int x){
        TotalWater = x;
    }

  //setCan():mutator
    public void setDietCoke(int x){
        TotalDietCoke = x;
    }

  //setMoney():mutator
    public void setMoney(int x){
        TotalMoney = x;
    }

  //setNickle():mutator
    public void setNickel(int y){
        ChangeNickel = y;
    }

  //setDime():mutator
    public void setDime(int y){
        ChangeDime = y;
    }

  //setQuarter():mutator
    public void setQuarter(int y){
        ChangeQuarter = y;
    }

  //getCan:accessor
   public int getCoke(){
       return TotalCoke;
   }
   
   //getCan:accessor
   public int getSprite(){
       return TotalSprite;
   }
   
     //getCan:accessor
   public int getFanta(){
       return TotalFanta;
   }
   
     //getCan:accessor
   public int getWater(){
       return TotalWater;
   }
   
     //getCan:accessor
   public int getDietCoke(){
       return TotalDietCoke;
   }
    
  //getMoney:accessor
   public int getMoney(){
       return TotalMoney;
   }
   
   //getDime:accessor
   public int getDime(){
       return ChangeDime;
   }
   
   //getNickel:accessor
   public int getNickel(){
      return ChangeNickel;
   }  
   
   //getQuarter:accessor
   public int getQuarter(){
       return ChangeQuarter;
   }
   
   //specific constructer CokeMachine()
   public DispenserMachine(int v, int w, int x, int y, int z){
     setCoke(v);   
     setSprite(w);
     setFanta(x);
     setWater(y);
     setDietCoke(z);
     setMoney(0);  
   }
   
   //AddCan(int x):add cans
   public void AddCan(DispenserMachine m, int x, int y){
       switch(x){
           case 1: m.setCoke(TotalCoke + y);
                   break;
           case 2: m.setSprite(TotalSprite + y);
                   break;
           case 3: m.setFanta(TotalFanta + y);
                   break;
           case 4: m.setWater(TotalWater + x);
                   break;
           case 5: m.setDietCoke(TotalDietCoke + x);
                   break;       
           default: System.exit(0);
        }
   }
   
   //InsertMoney(int x):insert money
   public DispenserMachine InsertMoney(DispenserMachine m, int a, int b, int c){
       m.setMoney(TotalMoney + NICKEL * a + DIME * b + QUARTER * c);
       return m;
   }
   
   //DispenserMachine(int x, int y): dipence a wanted drink and subrract money to the price of the drink
   public DispenserMachine BuyCan(DispenserMachine m, int x, int y){
       switch(x){
           case 1: m.setCoke(TotalCoke  - 1);
                   break;
           case 2: m.setSprite(TotalSprite - 1);
                   break;
           case 3: m.setFanta(TotalFanta - 1);
                   break;
           case 4: m.setWater(TotalWater  - 1);
                   break;
           case 5: m.setDietCoke(TotalDietCoke - 1);
                   break;       
           default: System.out.print("ERROR"); System.exit(0); return null;
   }
       m.setMoney(TotalMoney - y);
       return m;
   }
   
   //calculate changes
   public void Change(DispenserMachine m){
       int i = 0;
       int j = 0;
       int k = 0;
       while(TotalMoney >= QUARTER){
           ++i;
           TotalMoney = TotalMoney - QUARTER;
       }
       m.setQuarter(i);
       while(TotalMoney >= DIME){
           ++j;
           TotalMoney = TotalMoney - DIME;
       }
       m.setDime(j);
        while(TotalMoney >= NICKEL){
           ++k;
           TotalMoney = TotalMoney - NICKEL;
       }
       m.setNickel(k);
   }
   
   //display the machine situation
   public void display(DispenserMachine m)
   {
       System.out.println("Now machine has "); 
       System.out.println("inserted money is " + m.getMoney()); 
       System.out.println("The reamining number of Coke is " + m.getCoke());
       System.out.println("The reamining number of Sprite is " + m.getSprite());
       System.out.println("The reamining number of Fanta is " + m.getFanta());
       System.out.println("The reamining number of Water is " + m.getWater());
       System.out.println("The reamining number of DietCoke is " + m.getDietCoke());

    }
   //:check
   //public boolean Checking(int x, int y){
   //    if(insertToken < x){
   //        System.out.println("WARNING! You don't have enough token. You can buy " + insertToken +" cokes at max");
   //        return true;
   //    }
   //    else if(0 > x){
   //        System.out.println("PLEASE enter the positive number");
   //        return true;
   //    }
   //    else if(TotalCan < x){
   //        System.out.println("SORRY! The remained cokes are " + TotalCan);
   //        return true;
   //    }
   //    else return false;

  // }
       
    //convert to string
  //  public String toString(){
  //      return  TotalCan + " / " + TotalToken ;
  //   }
}
