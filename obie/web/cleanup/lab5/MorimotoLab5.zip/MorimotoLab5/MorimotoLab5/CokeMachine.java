//Hiroki Morimoto
//This program is for coke machine

public class CokeMachine{

  //instance variable tp describe the objext
    private int TotalCan; //hold how many cokes are in the machine 
    private int TotalToken; //hold how many token are in machine (profit)
    private int insertToken;//hold how many tokens are inserted at one time
    
  //default constructer CokeMachine()
    public CokeMachine(){
         TotalCan = 0;
         TotalToken = 0;
         insertToken = 0;
     }
     
  //setCan():mutator
    public void setCan(int x){
        TotalCan = x;
    }

  //setToken():mutator
    public void setToken(int y){
        TotalToken = y;
    }

  //setInsertToken():mutator
    public void setInsertToken(int z){
        insertToken = z;
    }

  //getCan:accessor
   public int getCan(){
       return TotalCan;
   }
   
  //getToken:accessor
   public int getToken(){
       return TotalToken;
   }
   
   //getInsertToken:accessor
   public int getInsertToken(){
       return insertToken;
   }
   
   //specific constructer CokeMachine()
   public CokeMachine(int x, int y){
     setCan(x);   
     setToken(y);
   }
   
   //AddCan(CokeMachine n, int x):add cans
   public void AddCan(CokeMachine n ,int x){
       n.setCan(TotalCan + x);
   }
   
   //AddCToken(CokeMachine n, int x):add token
   public void AddToken(CokeMachine n, int x){
       n.setInsertToken(insertToken + x);
   }
   
   //Buy(int x):subtract total cans and add total token and then make changes
   public CokeMachine Buy(int x){
       CokeMachine temp = new CokeMachine();
       temp.setCan(TotalCan - x);
       temp.setToken(TotalToken + x);
       temp.setInsertToken(insertToken - x);
       return temp;
   }
   
  
   //:check
   public boolean Check(int x){
       if(insertToken < x){
           System.out.println("WARNING! You don't have enough token. You can buy " + insertToken +" cokes at max");
           return true;
       }
       else if(0 > x){
           System.out.println("PLEASE enter the positive number");
           return true;
       }
       else if(TotalCan < x){
           System.out.println("SORRY! The remained cokes are " + TotalCan);
           return true;
       }
       else return false;

   }
       
    //convert to string
    public String toString(){
        return  TotalCan + " / " + TotalToken ;
     }
}

   