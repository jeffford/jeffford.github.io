import java.util.*;
import java.io.*;

public class MachineTest{

   public static void main(String[] args){
       
       Scanner stdin = new Scanner(System.in);

       //create a machine with 10 coke and no token
       System.out.print("create machine with how many coke :" ); 
       int x = stdin.nextInt();
       CokeMachine test = new CokeMachine(x,0);;
       
       //add 10 more cokoes to the machine       
       System.out.print("How many cokes add :" ); 
       x = stdin.nextInt();
       test.AddCan(test, x);
        
       //insert tokens in the machine
       System.out.print("How many tokens insert :" ); 
       int y = stdin.nextInt();
       test.AddToken(test, y);
       
       System.out.println();
       System.out.println("Now machine has "); 
       
       //print our the number of token inerted
       System.out.print("inserted token= " + test.getInsertToken()); 
       System.out.println();
       
       //print our the number of cans in the machine
       System.out.print("total cans = " + test.getCan()); 
       System.out.println();
       
       //get a coke
       do{
       System.out.print("How many cokes do you buy :" ); 
       x = stdin.nextInt();
       }while (test.Check(x));
       
       test = test.Buy(x);
       System.out.println();
       System.out.println("'You got " + x + " cokes'");
       
       System.out.println();
       System.out.println("Now machine has "); 
       //print out remain cans
       System.out.println("The remaining numbe of cokes is " + test.getCan());
       
       //print out changes
       System.out.println("The changes are " + ( test.getInsertToken()));
       
       //print out total token in the machine
       System.out.println("The machine has " + test.getToken() + " tokens");
       
       System.out.println();
   }
}