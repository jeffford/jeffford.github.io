import java.util.*;
import java.io.*;

public class MachineTest2{

   public static void main(String[] args){
       
       final int COKE = 75; 
       final int SPRITE =  100; 
       final int FANTA= 125; 
       final int WATER = 50; 
       final int DIETCOKE= 75; 
       
       Scanner stdin = new Scanner(System.in);

       //create a machine with 10 coke and no token
       System.out.print("create machine with how many coke :" ); 
       int v = stdin.nextInt();
       System.out.print("create machine with how many sprite :" ); 
       int w = stdin.nextInt();
       System.out.print("create machine with how many Fanta :" ); 
       int x = stdin.nextInt();
       System.out.print("create machine with how many Water :" ); 
       int y = stdin.nextInt();
       System.out.print("create machine with how many DietCoke :" ); 
       int z = stdin.nextInt();
       
       DispenserMachine test = new DispenserMachine(v,w,x,y,z);
       
       //add cans to the machine
       System.out.println("Which can do you add Coke(1), Sprite(2), Fanta(3), Water(4) or DietCoke(5)" );
       System.out.print("put the number of what you want :");
       int a = stdin.nextInt();
       System.out.print("How many do you add :" ); 
       int b = stdin.nextInt();
       test.AddCan(test, a, b);
       
       //insert tokens in the machine
       System.out.println();
       System.out.println("Now you need to insert money!" ); 
       System.out.print("How much Nickle insert :" ); 
       int num1 = stdin.nextInt();
       System.out.print("How much Dime insert :" ); 
       int num2 = stdin.nextInt();
       System.out.print("How much Quarter insert :" ); 
       int num3 = stdin.nextInt();
       test = test.InsertMoney(test, num1, num2, num3);
       
       System.out.println();   
       //print our the number of token inerted
       //print our the number of cans in the machine
       test.display(test);
       System.out.println();
       
       
       //get a coke
       //char cap;
       boolean ans;
       int n = 0;
       int m = 0;
       do{
             
              System.out.println("Which one do you want to buy" ); 
              System.out.println("Coke(1) | Sprite(2) | Fanta(3) | Water(4) | DietCoke(5)");
              System.out.println("  75    |    100    |   125    |    50    |     75     ");
              System.out.print("put the number of what you want :");
              m = stdin.nextInt();
              switch(m){
                  case 1: n = COKE; break;
                  case 2: n = SPRITE; break;
                  case 3: n = FANTA; break;
                  case 4: n = WATER; break;
                  case 5: n = DIETCOKE; break;
                  default: System.out.println("ERROR"); System.exit(0);
              }
       
       test = test.BuyCan(test, m, n);
       System.out.println();
       //System.out.println("'You got " + x + " cokes'");
       
       System.out.println();
       //print out remain cans
       test.display(test);
       System.out.println();
       
       System.out.println();
       System.out.println("Do you continue to buy? Y(1) or N(0)");
       int as = stdin.nextInt();
       if(as == 1) ans = true;
       else ans = false;
       //ans = ans.trim();
       //cap = ans.charAt(1); 
       System.out.println();
       }while (ans);
       
       //print out changes
       System.out.println("The changes are " + ( test.getMoney()));
       test.Change(test);
       System.out.println("Nickel(" + test.getNickel() + ") + Dime(" + test.getDime() + ") + Quarter("+ test.getQuarter() + ")");
       
       System.out.println();
   }
}