import java.util.*; 

//A class to test the MachineTest class.
 
public class MachineTest
{

//Tests the methods of the MachineTest class.

 
 public static void main(String[] args)
 {  
     coke_machine machine = new coke_machine(10);
      
     machine.Refills(10);
     machine.CanCount();
     machine.insertToken();
     machine.insertToken();
     machine.insertToken();
     machine.TokenCount(); 
     machine.insertToken();
     
     System.out.println("The remaining number of cokes is " + machine.CanCountReturn());
     
     System.out.println("Input tokens: ");
        Scanner stdin = new Scanner(System.in);
        int tokens = stdin.nextInt();
        for(int d = 0; d < tokens; d++){
            machine.insertToken();
        }
        
    System.out.println("The remaining number of cokes is " + machine.CanCountReturn());
    
}}
