

 // A Coke Machine that takes Tokens instead of money. 
 // One Token one coke 

public class coke_machine
{
// instance variables - replace the example below with your own
    private int tokens;
    private int cans;
    private int TokenCount;
    private int CanCount;
    private int refills;
 
    

    
    

    
//Constructs the coke_machine with zero tokens, 5 cans and 10 refills 
    
    public coke_machine()
    {
// initialinstance variables
        tokens = 0;    //initial number of tokens  
        cans = 5;      //initial number of cans in the coke machine
        refills = 10;  //the number of refills
    }
    
// Gives a new number of how many cans should be in the Coke Machine
// newcans the number of cans that the Coke Machine should start with.
      
    public coke_machine(int newcans)
    {
        cans = newcans;  // cans becomes newcans
    }
   
// The insertion of the Token in the Coke Machine, and  adding the Token in the Machine and subtracting a can from it.
    
    public void insertToken()
    {
        if(cans <= 0)   
        {
            System.out.println("Sorry!! The Coke Machine is out of stock");
            System.out.println("Don't forget to take your token");
        }
    else
    {
        tokens = tokens + 1;
        cans = cans - 1;
      
        System.out.println("You just bought one can");
    }
    }
        
   
// current number of Cans that are in Coke Machine
     
      
    public void CanCount()
    {
        if(cans == 1)
        {
            System.out.println("There is one can left in the Coke Machine");
        }
        else 
        {
            System.out.println("There are " + cans + " cans left in the Coke Machine");
        }
    }
     
//current number of Cans in the Coke Machine
// return the current number of Cans
      
     public int CanCountReturn()
     {
         return cans;
     }
     
//Gets the current number of Tokens that are inside the Coke Machine
      
     public void TokenCount()
     {
         if(tokens == 1)
         {
             System.out.println("There is one token in the Coke Machine");
         }
         else
         {
             System.out.println("There are "+ tokens + " tokens in the Coke Machine");
         }
    }
   
// Adds cans on the top of the current number of cans in the Coke Machine 
// refills the number of refills that are added in the Coke Machine.
   
    public void Refills (int refills)
    {
        cans = cans + refills;

    }
    
}