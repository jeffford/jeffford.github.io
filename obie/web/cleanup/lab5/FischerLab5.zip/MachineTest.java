//A class to test the CokeMachine class.
//import library for i/o

import java.util.*;
public class MachineTest
{

//tests the CokeMachine class
 public static void main(String[] args)
 {  
     Scanner stdin = new Scanner(System.in);
     System.out.println("How many cokes are in the machine:");
     int cokes=stdin.nextInt();
     CokeMachine bob = new CokeMachine(cokes);
//Loop of purchasing
int buy = 1;
while(buy == 1){
        System.out.println("Press 1 if you wish to buy a coke, or press 2 if not");
            buy= stdin.nextInt();
            if ( buy==1){
                bob.insertToken();
            }
            else{
        System.out.println("Step away from the coke machine so that paying costumers may use it");
    }
}         
     bob.countCans();
     bob.countTokens();
     System.out.println("How many more cokes do you wish to add to the machine:");
     int moreCokes=stdin.nextInt();
     bob.refill(moreCokes);
     buy = 1;
while(buy == 1){
        System.out.println("Press 1 if you wish to buy a coke, or press 2 if not");
            buy= stdin.nextInt();
            if ( buy==1){
                bob.insertToken();
            }
            else{
        System.out.println("Step away from the coke machine so that paying costumers may use it.");
    }
}
        System.out.println("The number of cokes left is: " + bob.returnCans());
        System.out.println("The number of tokens is: " + bob.returnTokens());
    
}}
