//This class defines a coke machine that takes tokens.
//Written by Rebecca Fischer

public class CokeMachine{
// instance variables
    private int tokens;
    private int cans;
    
//contruct the coke machine with 0 cans, and no tokens
    
    public CokeMachine(){
        cans = 0; 
        tokens = 0;           
    }
    
// define a constructor that allows the user to set the number of cans when constructing a coke machine
      
    public CokeMachine(int x){
        cans = x;
        tokens = 0;
    }
//define an accessor that returns the number of cans. 
      
     public int returnCans(){
         return cans;
     } 
     
// define an accessor that returns the number of tokens. 
    public int returnTokens(){
        return tokens;
    }
// define a method to refill the machine 

  public void refill(int x){
      cans=cans+x;
    }
   
//define a method that allows the user to purchase the coke 
    
    public void insertToken(){
        if(cans<=0){
            System.out.println("There is no more coke, you should have come earlier.");
        }
    else{
        cans=cans-1;
        tokens=tokens+1;
            System.out.println("You have bought your coke, you may leave now or purchase more coke.");
    }}
        
//tell the user how many tokens are in the machine
      
     public void countTokens(){
             System.out.println("The number of tokens in the machine is : " + tokens);
         }
   
// tell the user how many cans are left      
    public void countCans()
    {
            System.out.println("The number of cans left in the machine is: " + cans);
        }
    }