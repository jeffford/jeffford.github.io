// Author: Sayuri Ichida
// the date completed: 2/21/2006
// the date submitted: 2/22/2006
// Lab 5
// Purpose: develop a class for a simplified coke machine

public class Coke
{
  // instance variables to describe the object attributes
  private int can;              // number of cokes
  private int token;            // number of tokens

  // Coke(): default constructor
  public Coke() {
      can = 0;
      token = 0;
  }
     
  // Coke(): specific constructor
  //               which indicate how many cans and tokens the machine starts out with
  public Coke(int coke, int money) {
      setMachine(1, coke);
      setMachine(2, money);
  }
  
  // setMachine(): machine mutator
  public void setMachine(int i, int value) {
      switch (i) {
          case 1: can = value; return;
          case 2: token = value; return;
          default:
            System.err.println("Machine: bad get; " + i);
            System.exit(i);
            return;
      }
  }
  
  // getMachine(): machine accessor
  public int getMachine(int i) {
    switch (i) {
        case 1: return can;
        case 2: return token;
        default:
            System.err.println("Machine: bad get; " + i);
            System.exit(i);
            return i;
    }
  }
  
  // clone(): duplicte facilitator
  //               to set the numbers of cans and tokens the machine starts out with
  public Object clone() {
      int coke = getMachine(1);
      int money = getMachine(2);      
      return new Coke(coke, money);
  }
  
  // AddCan (Machine x): add more cokes to the machine
  public Coke AddCan (Coke x) {
    Coke temp = new Coke();
    if (x.getMachine(1) > 0) {
        temp.setMachine(1, can + x.getMachine(1));
    }
    else {
        temp.setMachine(1, can);
    }
    temp.setMachine(2, token);
    return temp;    
  }
  
  // Purchase (): insert tokens and get cokes
  public Coke Purchase (Coke x) {
    Coke temp = new Coke();
    
    // when the user inserts less than or equal to zero tokens
    if (x.getMachine(2) <= 0)  {
        temp.setMachine(1, can);
        temp.setMachine(2, token);
    }
    
    // when the user inserts one token
    else if (x.getMachine(2) == 1) {
        temp.setMachine(1, -- can);
        temp.setMachine(2, token + x.getMachine(2));
    }
    
    // when the user inserts more than one token
    // but smaller number of tokens than the number of cans in machine
    else if (x.getMachine(2) > 1 && x.getMachine(2) <= x.getMachine(1)) {
        for (int j = 1; j <= x.getMachine(2); ++j) {
            temp.setMachine(1, --can);
            temp.setMachine(2, ++token);
        }       
    }
    
    // when the user inserts greater number of tokens than the number of cans in the machine 
    else {
        do {
            temp.setMachine(1, --can);
            temp.setMachine(2, ++token);
        } while (temp.getMachine(1) != 0);
    }

    return temp;
  }
  
  // toStringCan(): convert the number of cans in the machine to a string suitable for output
  public String toStringCan () {
      int coke = getMachine(1);
      return coke + "";
  }
  
  // toStringToken(): convert the number of tokens in the machine to a string suitable for output
  public String toStringToken(){
      int money = getMachine(2);
      return money + " tokens";
  }
  
} 
