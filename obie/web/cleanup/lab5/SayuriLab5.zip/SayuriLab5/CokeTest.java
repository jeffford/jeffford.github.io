// Author: Sayuri Ichida
// the date completed: 2/21/2006
// the date submitted: 2/22/2006
// Lab 5
// Purpose: demonstrate use of CokeMachine class

import java.util.*;

public class CokeTest {
  // main(): application entry point
  public static void main (String [] args) {
      
    // setup scanner
    Scanner stdin = new Scanner(System.in);
    System.out.println();
    
    // initialize the number of coke cans and tokes in the vending machine
    Coke initial = new Coke(10,7);
    
    // display the number of cokes and tokens the machine starts out with
    System.out.print("There are "+ initial.toStringToken() +" and ");
    System.out.println(initial.toStringCan() + " cans of coke in the vending machine.");
    System.out.println();
    
    // input the number of cans to add to the machine
    Coke add = new Coke();
    System.out.println("Would you like to fill the vending machine with more cokes?");
    System.out.print("Please enter the number of cokes you would like to fill it with: ");
    int a = stdin.nextInt();
    
    add.setMachine(1, a);
    
    System.out.println();
    
    // perform AddCan() method
    Coke fill = initial.AddCan(add);
    
    // when the user enters a negative number for the number of cans to be added
    if (a < 0) {
        System.out.println("You can't enter negative numbers.");
        System.out.println("Since you entered the negative number, no coke will be added to the machine.");
        // print out the number of cans in the machine
        System.out.println("The number of cokes in the machine stays the same.");
        System.out.println("There are "+ fill.toStringCan() + " cans in the machine now.");
    }

    // when the user enters zero for the nubmer of cans to be added
    else if (a == 0) {
        System.out.println("Since you enter 0, no coke will be added to the machine.");
        // print out the number of cans in the machine
        System.out.println("The number of cokes in the machine stays the same.");
        System.out.println("There are "+ fill.toStringCan() + " cans in the machine now.");
    }
    
    // when the user enters positive number for the number of cans to be added
    else {
        // print out the number of cokes added
        System.out.println(a + " more cokes are added to the machine.");
        // print out the number of cans in the machine
        System.out.println("There are "+ fill.toStringCan() + " cans in the machine now.");
    }
    
    System.out.println();
    
    // input the numbers of tokens to insert in the machine in order to buy cokes
    Coke inserted_token = new Coke();
    System.out.println("One can costs exactly one token.");
    System.out.print("Please enter the number of tokens you want to insert in the machine: ");
    int b = stdin.nextInt();
    
    inserted_token.setMachine(1, fill.getMachine(1));
    inserted_token.setMachine(2, b);
    
    // print out the number of tokens inserted and the number of cokes the user will get
    System.out.println();
    
    // when the user enters a negative number as the number of tokens to be inserted
    if (b < 0) {
        System.out.println("You can't type negative numbers!");
        System.out.println("You don't get any coke.");
        System.out.println("If you would like to buy cokes, please insert at least one token.");
        System.out.println("(" + b + " tokens droped into the money dispenser.)");
        System.out.println("We return you " + b + " tokens.");
    }
    
    // when the user enters 0 as the number of tokens to be inserted
    else if (b == 0) {
        System.out.println("Since you did not insert any token, you won't get any coke.");
    }
    
    // when the user inserts exactly one token
    else if (b == 1) {
        System.out.println(b + " token was inserted, so you will get " + b + " can.");
    }
    
    // when the user inserts more than one token
    // and the number of tokens is less than or euqual to the number of cokes in the machine
    else if (b > 1 && b <= fill.getMachine(1)) { 
    System.out.println(b + " tokens were inserted, so you will get " + b + " cans.");
    }
    
    // when the user inserts greater number of tokens than the number of cokes in the machine
    //else if (b > fill.getMachine(1)) {
    else {
        int rest = b - fill.getMachine(1);       // calculate the change for the user
        System.out.println("Sorry, we don't have enough cokes.");
        System.out.print("We will give you all of the cokes in the machine, " + fill.toStringCan());
        System.out.println(" cokes, and return you the extra " + rest + " tokens.");
    }
    
    // get a coke
    // when the user inserts one token
    if (b == 1) {
    System.out.println("(A can droped from the can reservoir into the product delivery slot.)");
    System.out.println("Here is your coke!!");
    }
    
    // get a coke
    // when the user inserts more than one tokens and the number of tokens is less than the number of cokes in the machine
    // so that the user will be able to get the same number of cokes as the number of tokens inserted
    else if (b > 1 && b <= fill.getMachine(1)) {
        System.out.println("(" + b + " cans droped from the can reservoir into the product delivery slot.)");
        System.out.println("Here are your " + b + " cokes!!");
    }
    
    // get a coke
    // when the user inserts more tokens than the cans in the machine
    // so that the user won't get the same number of cokes as the number of tokens inserted and the user will get change
    else if (b > fill.getMachine(1)) {
    int rest = b - fill.getMachine(1);        // calculate the extra tokens the user inserted
    System.out.print("(" + fill.toStringCan() + " cans droped from the can reservoir");
    System.out.print(" into the product delivery slot and " + rest);
    System.out.println(" tokens droped into the money dispenser.)");
    System.out.println("Here are your " + fill.toStringCan() + " cokes!!");
    System.out.println("Don't forget your change, " +  rest + " tokens.");
    }
    
    System.out.println();
    
    // perform Purchase() method
    Coke purchase = fill.Purchase(inserted_token);

    // display the number of tokens and cans left in the vending machine    
    System.out.println("The remaining number of cokes is " + purchase.toStringCan() + ".");
    System.out.println("There are " + purchase.toStringToken() + " in the vending machine.");           
    System.out.println();
  }
}
