
/**
 * Write a description of class MachineTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MachineTest  
{
	static public void main(String args[]){
	    
	    cokeMachine machine = new cokeMachine();
	    machine.fillMachine(10);
	    machine.insertToken(3);
	    machine.tokenCount();
	    machine.cokeCount();
	    
	}
}