
/**
 * Write a description of class CokeMachine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class cokeMachine  
{
    // instance variables
    private int cokes_in_machine;
    private int tokens_in_machine;
    private int totaltokens;

    /**
     * Constructor for objects of class CokeMachine
     */
    public cokeMachine()
    {
        // initialise instance variables
        cokes_in_machine = 0;
        tokens_in_machine = 0;
        
    
    
    
    
    
    }

    
    public void fillMachine(int fill)
    {
        cokes_in_machine = cokes_in_machine + fill;
        if(cokes_in_machine > 100){ //can only hold 100 cokes
            cokes_in_machine = 100;
            System.out.println("The machine can't hold anymore cokes.");
        }
    }
    
    public void insertToken(int token)
    {
        totaltokens += token; //total tokens inserted in machine
        tokens_in_machine++; //tokens actually in machine
        if(token>1){           
           returnChange(token);
           distributeCoke();
       }
    }
   
    public void returnChange(int token)
    {
        int x;
        x=token-1;
        System.out.println("You have inserted " + token + " tokens, only 1 is required, " + x + " have been returned.");
    
    }
    
    public void distributeCoke()
    {
        if(cokes_in_machine>0){
            System.out.println("One coke has been distributed.");
            cokes_in_machine--;
        }
        else
            System.out.println("Machine is empty");
    }
    
    public void cokeCount()
    {
        System.out.println("There are " + cokes_in_machine + " cokes in the machine.");
    }
    
    public void tokenCount()
    {
        System.out.println("There are " + tokens_in_machine + " tokens in the machine.");
    }
}
    
