//Purpose: A program that represents a coke machine
//Author: Kyli Foltz    Date: 2/13/06

public class CokeMachine
{
    // instance variables that describe a coke machine
    private int tokens;
    private int cans;

    // CokeMachine(): default constructor
    public CokeMachine() {
        tokens = 0;
        cans = 0;
    }
    
    // setTokens(): tokens mutator
    public void setTokens(int t) {
        tokens = t;
    }
    
    // setCans(): cans mutator
    public void setCans(int c) {
        cans = c;
    }
    
    // getTokens(): tokens accessor
    public int getTokens() {
        return tokens;
    }
    
    // getCans(): cans accessor
    public int getCans() {
        return cans;
    }
    
    // CokeMachine(): specific constructor
    public CokeMachine(int t, int c) {
        setTokens(t);
        setCans(c);
    }
    
    // insert a token method 
    public void insertToken(int n) {
        tokens = tokens + n;
    }
    
    // dispense a coke method
    public void dispenseCans(int m) {
        cans = cans - m;
    }
    
    // insert cans method
    public void insertCans() {
        cans = cans + 10;
    }
}
