//Purpose: Exercise the Coke Machine Class
//Author: Kyli Foltz        2/16/2006

import java.util.*;

public class CokeMachineDemo {
    public static void main(String[] args) {
        System.out.println("Thank you for choosing this coke machine!");
        System.out.println();
        CokeMachine r = new CokeMachine(0, 10);
        System.out.println("This machine has " + r.getCans() + " cans and " + r.getTokens() + " tokens.");
        Scanner stdin = new Scanner(System.in);
        System.out.print("How many cokes would you like to purchase? (1 token = 1 coke): ");
        int number = stdin.nextInt();
        if (number > r.getCans()) {
            System.out.println("There are only " + r.getCans() + " cans in this machine.");
            System.out.print("Please enter a new number of cokes: ");
            number = stdin.nextInt();
        }
        System.out.println("You inserted " + number + " tokens.");
        r.insertToken(number);
        r.dispenseCans(number);
        System.out.println("Enjoy!  Thank you for purchasing " + number + " cokes.");
        System.out.println("Now the machine has " + r.getCans() + " cans and " + r.getTokens() + " tokens.");
        if (r.getCans() == 0) {
            System.out.println("This machine needs refilled.");
            r.insertCans();
            System.out.println("The machine has been refilled and now has " + r.getCans() + " and " + r.getTokens() + ".");
        }
    }
}