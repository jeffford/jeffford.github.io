//Author: Joe Moeller
//Purpose:  Hold methods that will aid in the creation
//of the coke machine

import java.util.*;

public class CokeMachine {

    //initiation of variables
    int tokens, cans;
    
    //Constructor to give the instance variables
    //a defalut value of zero
    public CokeMachine() {
        tokens = 0;
        cans = 0;
 }
    //another constructor allowing a coke machine
    //to be created with any given number of cans.
    public CokeMachine(int a) {
        cans = a;
        tokens = 0; 
    }
    //sets the inserted tokens as the number of 
    //tokens 
    public void setToken(int a) {
        tokens = a;
       
    }
    //adds 1 to tokens so a count could be kept
    //of the total number of tokens in the 
    //machine
    public void insertToken() {
        tokens++;
    }
    
    //returns the value of tokens to the test 
    //program
    public int getToken() {
        return tokens;
    }
    //sets the number of cans input by the user
    //as the number of cans in the machine
    public void setCoke(int a) {
        cans = a;
   }
   //subtracts 1 can from the initial number
   //of cans after one is dispensed
   public void dispenseCoke() {
       --cans;
    }
    
    //returns the number of cans in the machine
    //to the test class
    public int getCoke() {
        return cans;
}
    //adds an additional amount of cans to 
    //the already existing number of cans in 
    //the machine
    public void fillMachine(int a) {
        cans = cans + a;
    }
    } 
        