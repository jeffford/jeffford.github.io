//Author:  Joe Moeller
//Purpose:  To simulate a coke machine; dispense 
//a coke when a token is
//inserted.  It will display error message when too 
//many tokens are input,
//reject extra tokens, and keep track of the
// number of tokens and cans in the machine. 


import java.util.*;

public class MachineTest {
    public static void main(String[] args) {
        //create a new CokeMachine named coke
        CokeMachine coke = new CokeMachine ();
       
        //creation of the scanner object
        Scanner stdin = new Scanner(System.in);
        //prompt user to load the machine with a certain number of cans
        System.out.print("Enter the number of cans in this machine: ");
        int n = stdin.nextInt();
        //set users input as setCoke (number of cokes in machine)
        coke.setCoke(n);
        
        //prompt user to add more cans to the first number of cans 
        //in the machine
        System.out.print("Insert a number to fill the machine with more cans: ");
        int f = stdin.nextInt();
        //sets users input as fillMachine, adding this input to the first input
        coke.fillMachine(f);
       
        //output statement telling number of cans in the machine
        System.out.println("The number of cokes in this machine is: " + coke.getCoke());
        
        
        //while loop that will end when the machine is out of cokes
   while (coke.getCoke() > 0) {
        
        System.out.println();
        //prompt user to insert a number of tokens
        System.out.print("Please insert a number of tokens: ");
        int input = stdin.nextInt();
        //if statement that is executed when the user inserts too many tokens
        if (input > 1) {
           int extras = input - 1;
            System.out.println("You have inserted too many coins!  Your extra " + extras + " coin(s) have been rejected.");
        }
        System.out.println();

        //if statement that will control the dispensing of coke
        //if at lease one token is inserted then a coke will
        //be dispensed and the machine will accept a token
     if (input >= 1) {
        coke.dispenseCoke();
        coke.insertToken();
        System.out.println("The machine has accepted 1 token.");
        System.out.println("A coke has been dispensed.");
        System.out.println("There are " + coke.getCoke() + " coke cans left in the machine.");
    }
        //if statement that does not dispense a coke if no 
        //tokens are inserted 
     if (input == 0) {
        System.out.println("The machine has accepted 0 tokens.");
        System.out.println("No coke has been dispensed!");
        System.out.println("There are " + coke.getCoke() + " coke cans left in the machine.");
    }
    }
        //final output after while loop is over
        //that tells how many tokens the machine has collected.
        System.out.println("The total number of tokens that the machine has collected is " + coke.getToken() + ".");
        
    }
}