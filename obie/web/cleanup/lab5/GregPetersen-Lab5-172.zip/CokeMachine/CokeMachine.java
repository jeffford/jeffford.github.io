
/**
 * This is a class that creates a coke machine which can produce cokes.  The class allows
 * the user to set the number of cans in the machine and the amount of tokens to be 
 * put in the machine.
 * 
 * @author Greg Petersen 
 * @version 2/18/06
 */

public class CokeMachine
{
  // variables
    /** the number of tokens in the coke machine */
    int tokens;
    /** the number of cans in the coke machine */
    int cans;
    /** the maximum number of cans in the coke machine */
    int maxCans;
    
  // constructors
    /** default constructor that set cans=0, token=0 and maxCans=50. */
    public CokeMachine() {
        tokens = 0;
        cans = 0;
        maxCans = 50;
        }
    
    /** constructor that allows the user to enter the values of the coke machine.
     * the calling order is (Cans, Tokens, Max Cans).
     * if the number of cans exceeds max cans, the value is automatically reduced. */
     public CokeMachine(int can, int tok, int mcan) {
         if(can>mcan) {
            can = mcan;
        }
         cans = can;
         maxCans = mcan;
         tokens = tok;
     }
    
  // methods
    /** adds tokens to the machine, insert number of tokens into brackets, must be int.  
     * i.e. addTokens(8) adds eight tokens.
     * */
    public void addTokens(int n) {
        tokens =+ n;
    }
    
    /** returns the amount of tokens in the coke machine.  returns int. */
    public int getTokens() {
        return tokens;
    }
    
    /** sets the number of tokens in the coke machine to 0. */
    public void returnTokens() {
        System.out.println(tokens + " tokens returned.");
        tokens = 0;
    }
    
    /** adds cans to the coke machine, insert number of cans into brackets, must be int.
     * i.e. addCans(6) adds six cans to coke machine. */
    public void addCans(int n) {
        int temp = cans + n;
        if(temp>maxCans) {
            temp = maxCans - cans;
            cans = maxCans;
            System.out.println("max reached, " + temp + " cans added.");
        } else {
            cans = temp;
            System.out.println(n + " cans added");
        }
    }
    
    /** sets the maximum amount of cans a coke machine can hold.  Max number is placed in
     * brackets, i.e maxCans(50)  creates a coke machine that holds 50 cans. */
    public void maxCans(int n) {
        maxCans = n;
        if(maxCans<cans) {
            int temp = cans - maxCans;
            cans = maxCans;
            System.out.println("Warning! Cans in machine exceeds max cans.  " + temp + " cans removed");
        }
    }
    
    /** displays the number of cans in the coke machine.  returns int. */
    public int getCans() {
        return cans;
    }
    
    /** takes one token from the coke machine and produces a coke. */
    public void vend() {
        if(tokens>0 && cans>0) {
            tokens--;
            cans--;
            System.out.println("You recieved a coke!");
        } else if(cans>0) {
            System.out.println("Not enough tokens!");
        } else 
            System.out.println("Not enough cans!");
    }
}
