
/**
 * a program that tests the CokeMachine class
 * 
 * @author Greg petersen
 * @version 2/19/06
 */
public class MachineTest
{
	public static void Main() {
	    int cans = 10;
	    int tokens = 0;
	    int max = 100;
	    // create a new coke machine called pepsi with 10 cans and 100 max cans
	    CokeMachine pepsi = new CokeMachine(cans, tokens, max);
	    pepsi.addCans(10);
	    pepsi.addTokens(3);
	    System.out.println("There are " + pepsi.getTokens() + " token(s) in the machine.");
	    System.out.println("There are " + pepsi.getCans() + " can(s) in the machine.");
	    pepsi.vend();
	    System.out.println("The remaining number of cokes is " + pepsi.getCans() + ".");
	    pepsi.maxCans(5);
	}
}
