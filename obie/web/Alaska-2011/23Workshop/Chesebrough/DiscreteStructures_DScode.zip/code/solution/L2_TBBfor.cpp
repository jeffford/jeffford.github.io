#include <iostream>
#include "tbb/task_scheduler_init.h"
#include "tbb/blocked_range.h"
#include "tbb/parallel_for.h"

#define NUM 16
#define PRINT 5

using namespace std;
using namespace tbb;

class VecAdd {
   int *arr1, *arr2, *res, len; //fields to know what to do
public:
   VecAdd(int _arr1[], int _arr2[], int _res[], int _num) {
      arr1 = _arr1;
	  arr2 = _arr2;
	  res  = _res;
	  len = _num;
   }

   // vector add serial version
   int add(int lo, int hi) 
   {
       for(int i=lo; i < hi; ++i) {
          res[i] = arr1[i] + arr2[i];
       }
       return 0;
   }
   
   // vector add serial version
   int addparallel(int lo, int hi) 
   {
/*
      parallel_for( blocked_range<size_t>(lo,hi),
        [=](const blocked_range<size_t>& range)
        {
           for( int i=range.begin(); i != range.end(); ++i)
           res[i] = arr1[i] + arr2[i];
        },
        auto_partitioner() );

      parallel_for( blocked_range<size_t>(lo,hi),
                    [=](const blocked_range<size_t>& r) {
                    for(size_t i=r.begin(); i!=r.end(); ++i)
                    res[i] = arr1[i] + arr2[i];  
                    });
*/
      parallel_for (lo, hi,[&](int i) {res[i] = arr1[i] + arr2[i]; }
      );

      return 0;
   }


};


int main()
{


	int * arr1, * arr2, * res;
	arr1 = new int[NUM]; //array ints
	arr2 = new int[NUM]; //array ints
	res  = new int[NUM]; //array ints

	// initialize array input
	cout << "\npreparing array arr1\n";
	for (int i=0; i < NUM; ++i) {
		arr1[i] = i;
		if (i < PRINT) cout << arr1[i] << endl;
	}
	cout << "\npreparing array arr2\n";
	for (int i=0; i < NUM; ++i) {
		arr2[i] = 28 - 3*i;
		if (i < PRINT) cout << arr2[i] << endl;
	}

	cout << "\ncomputing array sequential\n";
	VecAdd *myVectAdd = new VecAdd(arr1, arr2, res, NUM);
	myVectAdd->add(0, NUM);
	for (int i=0; i < NUM; ++i) {
		if (i < PRINT) cout << res[i] << endl;
	}

        task_scheduler_init init;
	cout << "\ncomputing array TBB parallel for\n";
	VecAdd *myVectAddTBB = new VecAdd(arr1, arr2, res, NUM);
	myVectAddTBB->addparallel(0, NUM);
	for (int i=0; i < NUM; ++i) {
		if (i < PRINT) cout << res[i] << endl;
	}
}
